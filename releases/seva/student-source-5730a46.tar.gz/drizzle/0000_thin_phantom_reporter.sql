CREATE TABLE `seva_student_profiles` (
	`owner_id` text PRIMARY KEY NOT NULL,
	`id` text NOT NULL,
	`profile_json` text NOT NULL,
	`version` integer NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `seva_student_profiles_id_unique` ON `seva_student_profiles` (`id`);