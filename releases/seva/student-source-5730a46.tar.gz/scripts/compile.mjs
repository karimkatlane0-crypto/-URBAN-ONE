import fs from 'node:fs';
const model=fs.readFileSync('src/model.js','utf8').replaceAll('export ','');
const studentUI=fs.readFileSync('src/student-ui.js','utf8').replaceAll('export ','');
const studentServer=fs.readFileSync('src/students.js','utf8').replaceAll('export ','');
const app=fs.readFileSync('src/app.js','utf8');
const html=fs.readFileSync('src/index.html','utf8').replace('/*APP*/',model+'\n'+studentUI+'\n'+app);
fs.writeFileSync('worker/index.js','const page='+JSON.stringify(html)+';\n'+studentServer+'\n'+fs.readFileSync('src/server.js','utf8').replace("import {handleStudent} from './students.js';\n",''));
