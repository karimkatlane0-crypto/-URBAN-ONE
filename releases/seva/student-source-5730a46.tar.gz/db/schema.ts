import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const studentProfiles=sqliteTable('seva_student_profiles',{ownerId:text('owner_id').primaryKey(),id:text('id').notNull().unique(),profileJson:text('profile_json').notNull(),version:integer('version').notNull(),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull()});
