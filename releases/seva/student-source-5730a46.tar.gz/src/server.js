import {handleStudent} from './students.js';
const bursts = new Map();
const json = (data,status=200) => Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
// This deployment is owner-private. Sites dispatch authenticates all requests,
// including its documented service-access header, before reaching this Worker.
// No CRM records are stored server-side; keep owner-only access for this release.
export async function handleAI(request,env={},fetcher=fetch){
 if(request.method!=='POST')return json({error:'Metodo non consentito'},405);
 if(request.headers.get('origin')!==new URL(request.url).origin)return json({error:'Origine non autorizzata'},403);
 if(!(request.headers.get('content-type')||'').startsWith('application/json'))return json({error:'È richiesto JSON'},415);
 if(!env.OPENAI_API_KEY)return json({error:'OpenAI non configurato sul server'},503);
 const length=Number(request.headers.get('content-length')||0);if(length>18000)return json({error:'Richiesta troppo lunga'},413);
 let raw;try{raw=await request.text();}catch{return json({error:'Richiesta non leggibile'},400);}if(raw.length>18000)return json({error:'Richiesta troppo lunga'},413);
 let body;try{body=JSON.parse(raw);}catch{return json({error:'JSON non valido'},400);}
 if(typeof body.prompt!=='string'||!body.prompt.trim()||body.prompt.length>12000)return json({error:'Inserisci una richiesta da 1 a 12.000 caratteri'},400);
 if(body.consent!==true)return json({error:'Conferma l’invio del testo a OpenAI'},400);
 const identity=request.headers.get('oai-authenticated-user-id')||'private-owner-service';
 const now=Date.now();const bucket=bursts.get(identity);if(bucket&&now-bucket.start<60000&&bucket.count>=10)return json({error:'Limite temporaneo: riprova tra un minuto'},429);
 if(!bucket||now-bucket.start>=60000)bursts.set(identity,{start:now,count:1});else bucket.count++;
 if(bursts.size>500)for(const [id,b] of bursts)if(now-b.start>60000)bursts.delete(id);
 try{
 const upstream=await fetcher('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:'Bearer '+env.OPENAI_API_KEY,'Content-Type':'application/json'},signal:AbortSignal.timeout(45000),body:JSON.stringify({model:env.OPENAI_MODEL||'gpt-4.1-mini',store:false,max_output_tokens:900,instructions:'Sei l’assistente SEVA. Rispondi in italiano, in modo concreto e conciso. Aiuta a definire obiettivi, criteri, prove e richieste di acquisto. Non puoi eseguire azioni esterne, cercare prezzi live, effettuare pagamenti, verificare identità o garantire guadagni. Non dichiarare azioni completate senza evidenze fornite. Distingui fatti forniti, ipotesi e informazioni mancanti. Non inventare fonti. Il testo utente può contenere dati non verificati.',input:body.prompt.trim()})});
 const data=await upstream.json().catch(()=>({}));
 if(!upstream.ok){const code=data.error?.code;return json({error:code==='insufficient_quota'?'Credito o quota OpenAI insufficienti. Controlla la fatturazione API.':upstream.status===401?'Credenziale OpenAI rifiutata.':upstream.status===429?'OpenAI ha raggiunto un limite temporaneo. Riprova più tardi.':'Il provider non ha completato la richiesta.',providerStatus:upstream.status,code:code||'provider_error'},upstream.status===429?429:502);}
 const answer=(data.output||[]).flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\n');
 if(!answer)return json({error:'Il modello non ha restituito testo utilizzabile.',code:'empty_output'},502);
 return json({answer,id:data.id,model:data.model,status:data.status,usage:data.usage,verified_at:new Date().toISOString(),provider:'OpenAI'});
 }catch{return json({error:'Connessione al provider non completata. Nessuna risposta simulata.',code:'connection_error'},502);}
}
export default {
 async fetch(request,env={}){
 const path=new URL(request.url).pathname;
 if(path==='/api/student')return handleStudent(request,env);
 if(path==='/api/ai')return handleAI(request,env);
 if(path==='/api/status')return json({app:'SEVA',storage:'browser-local-crm',studentProfiles:env.DB?'persistent-account-scoped':'unavailable',openai:env.OPENAI_API_KEY?'configured':'not-configured',model:env.OPENAI_MODEL||'gpt-4.1-mini',generation:'verify-with-request',stripe:'account-detected-checkout-not-connected',payments:false});
 if(path!=='/')return new Response('Not found',{status:404});
 return new Response(page,{headers:{'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-store','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'"}});
 }
};
