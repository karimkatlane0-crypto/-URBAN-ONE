# SEVA
Private initial workspace, separate from URBAN ONE and KKUBERA. Browser-local CRM; no centralized customer data or payments processing.

## Run and verify
`npm test` — model and Worker tests.
`npm run build` — compile frontend into Worker and build artifact.
`node scripts/validate-artifact.mjs` — validate ESM entrypoint.
`npm run dev -- --port 4173` — development server.

## Features
Voluntary intent cards with local photos and contact, revocation/deletion, manual product catalog, explicit sponsorship, goal tree (root + three sublevels), criterion/evidence/status gating, local AI briefs, JSON import/export and CSV/TXT export, financial scenario calculator. Load the SEVA launch plan in Plan & AI.

## Verified external configuration 2026-10-25
Stripe account Katlane Karim: acct_1UQI83RzfcoKq6cn (live).
Inactive product prod_VVXXVGhdpIodLC; default price price_1UUWSlRzfcoKq6cnfB1elOxQ: EUR 500.00 yearly. Tax behavior unspecified pending review. No checkout, subscription, customer charge, payout or webhook created.

## Incomplete gates
OpenAI key creation authorized but secure destination confirmation outstanding. No AI authenticated response verified. Claude/Gemini/xAI not configured. PayPal and marketplace/Connect payouts not configured. No university verification. No transaction-based rewards. No shared server CRM, tenant isolation or production merchant onboarding yet. UI/data logic is an initial release, not a complete commercial marketplace.

## Security and data
No credentials in browser or repository. No background transmission of intents, photos or contacts. Browser data is not encrypted by SEVA; use only an appropriate personal device and export carefully. Local audit is not tamper-proof. Specific recipients and permission needed before external sharing. Third-party API billing separate. Sponsored visibility must be labelled.

## Acceptance gates
Before charging customers: complete IAM and owned server records; verify restricted Stripe credentials, signed idempotent webhook and paid entitlements; confirm VAT treatment and service terms; test sandbox success/failure/refund/duplicate events; prove real service delivery. Before shopper rewards: merchant contract, eligible payout provider, funded reserve, identity requirements and return/chargeback controls. No free-product or income guarantee.

## OpenAI integration update
The owner authorized reusing the SEVA key for this app. `OPENAI_API_KEY` is configured as a Sites runtime secret; `OPENAI_MODEL` selects gpt-4.1-mini. `/api/ai` uses the Responses API with store=false and 900 output tokens maximum. Only the text expressly submitted in Assistente AI is sent. The route relies on this Site's confirmed owner-private platform authentication, additionally checks same-origin JSON requests, bounds inputs, and applies a best-effort per-isolate burst limit (not a durable billing quota). Keep the Site owner-private. No third-party tool execution is available to the model. Provider errors never become simulated answers. The UI displays response ID, timestamp, model and token usage, and offers receipt download.

## SEVA Campus update — 2026-10-26
Student profile server storage, account isolation and optimistic versioning are implemented. See docs/STUDENT-BACKEND.md for exact verified scope and remaining gates. Other CRM records remain browser-local on this hosted Site. Student academic status remains self-declared.
