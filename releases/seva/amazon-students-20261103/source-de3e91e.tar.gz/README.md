# SEVA

An independent project of Karim Katlane: a public introduction and authenticated personal workspace for goals, voluntary needs, a manual catalog and service improvement. This repository belongs to the existing SEVA Site, separate from URBAN ONE and KKUBERA.

## Current release — 2 November 2026

The public landing is available in Italian and English. `/app` requires ChatGPT sign-in and preserves the chosen community, business or support destination through the sign-in redirect. The workspace interface remains Italian. No paid purchase is offered.

Omnibus Omnia accepts private proposals to the owner. Business and support inquiries use the same account-owned inbox. Users can read replies, export their requests and delete them. The owner can reply; other users cannot read or change the requests. This is an in-app channel, not a public chat, member directory, email campaign or emergency service. No response deadline is promised.

The AI screen prepares a brief to copy or download and opens the user's own provider. TXT/Markdown source files can be appended locally to the brief (64 KB per file, 12,000 characters total). URL-only files are explicitly labeled as references whose page contents have not been acquired. The draft stays in memory until downloaded or copied. ChatGPT and Gemini open through separate links; no text is included in those URLs. Submission and bringing the answer back are manual. Provider plans, limits and any charges belong to the user's provider account. SEVA does not collect API keys and does not automatically call a provider. The public `/api/ai` route cannot consume the owner's existing secret, regardless of runtime billing-mode settings. Historical provider code remains covered by isolated tests only. Earlier owner-private API checks returned `credit_balance_exhausted`; this release does not claim that API billing was restored.

Sharing is initiated by the visitor through native sharing or link copying. Metadata, a canonical URL, robots rules and a sitemap support discovery; no search indexing, worldwide reach, campaign delivery, adoption or revenue has been verified. No athlete, NBA or OpenAI endorsement is claimed.

## Features and data

- Three editable starter plans: personal goal, shop and service improvement; five-level goal trees with criteria, evidence and status gating.
- Ten thousand deterministic prompt combinations, with search and pagination. These are templates, not bulk AI calls.
- Voluntary intent cards, optional local photos/contacts, manual products, exports and a reward scenario calculator. No financial reward is paid.
- Explicit goal sync, student profiles and private service records in account-owned D1 rows. Service closure requires evidence. Student status is self-declared.
- New private inquiries in `seva_inquiries`, migration `0003_orange_viper`. Earlier migrations remain unchanged.

Trusted Sites authentication headers establish the account. Personal APIs require that identity and a browser workspace scope matching the current session. A stale browser tab cannot write its previous account's data into a different account. Browser storage and sync metadata are namespaced per authenticated account. Only the authenticated owner may import the legacy unscoped browser workspace. Sign-in is supplied by Sites; no custom password handling exists.

Writes validate same-origin JSON, consent, payload bounds and revisions. Inquiry retries use stable IDs, and each user is limited to 50 stored inquiries. The owner inbox displays the latest 200. Personal API responses are not cached. `/api/release` is owner-only; `/api/status` exposes readiness, not private records. Local browser data is not encrypted by SEVA; use a suitable personal device and keep exports safe.

## Payments — integrated TEST checkout; LIVE offers remain drafts

The owner has three Stripe TEST subscription checkouts under `/app?section=billing`: Enterprise €50/month, Acquisti €50/year, E-commerce €500/year, matching the existing sandbox catalog. Other users see availability and support only. LIVE purchasing is explicitly unavailable in the handler; changing an environment flag cannot open it.

Payment Links receive an opaque server-created account binding with a 24-hour issuance window. A signed checkout event binds the subscription. Paid access status requires an eligible subscription and a paid, price-matched invoice period. The redirect grants nothing. TEST entitlements never grant commercial features. They do not buy OpenAI credit or unlock AI provider usage.

`/api/billing/webhook/test` validates HMAC-SHA256, five-minute timestamp tolerance, mode and account context. D1 batches atomically apply effects and receipts; duplicated and out-of-order events are supported. Refunds and disputes hold matching periods for merchant review. Failed renewals do not extend access. Cancellation at period end preserves the already paid period; final cancellation blocks stale active events.

Secrets use Sites runtime variables `STRIPE_WEBHOOK_SECRET_TEST` and `SEVA_BILLING_CONFIG`, separate from source and browser. No Stripe API key or card data is stored by SEVA. The customer portal uses Stripe email login for TEST invoices, method updates and cancellation. Refunds are performed in the merchant Stripe Dashboard; no refund or payout is initiated by this app.

Production mode has no enabled checkout or merchant webhook configuration in this release. Before LIVE activation, specify and verify delivery of the paid service, finalize sale terms and product tax behavior, and replace reusable Payment Links with one-session checkout or enforce a supported single-use purchase design. Current links are for owner testing only and must not be shared. Live products remain inactive with unresolved fulfillment/tax metadata.

Provider verification on 2 November 2026: merchant charges/payouts enabled, no currently due requirements; company VAT ID is eventually due. Available methods include card, Apple Pay, Link, Satispay and regional methods; SEPA debit, customer-balance transfers, Google Pay and PayPal were unavailable in the connected default configuration. Availability does not guarantee eligibility for every subscription, device, currency or customer.

Hosted TEST verification on 2 November 2026: authenticated owner opened Enterprise checkout, selected EUR, and completed a simulated €50 card subscription. Stripe confirmed `complete` / `paid` with `livemode:false`; SEVA displayed the verified period ending 2 December 2026. A connector-initiated cancellation at period end reached SEVA as “rinnovo disattivato”, retaining the paid test period. Relevant payment and subscription notifications had `pending_webhooks:0`. No real money moved. The email-login customer portal is configured but was not exercised. Apple Pay and Satispay were offered by checkout but were not used. The other two plans are configured but have not completed an end-to-end payment test. See `docs/payments-test-20261102.json` and its screenshot for the observed evidence.

Validation: 84 automated tests including 14 billing suites; SQL migrations, Worker ESM and public/non-owner browser view. The hosted card payment and test entitlement are verified; delivery of a defined commercial service is still a separate release gate.

## Run and verify

`npm test` runs model, HTTP, SQL isolation and asynchronous UI-state checks.

`npm run build` compiles the frontend and Worker, including schema-only migrations in the deployment output.

`npm run validate` verifies the generated ESM Worker entrypoint. For managed browser preview use `sites-preview start <checkout>`.

95 automated tests pass. Local browser QA verifies the landing, English toggle, Community navigation, inquiry creation and persistence after reload. Existing service create/reload/evidence checks passed in the preceding private release. The local HTTP preview cannot exercise the secure-context UUID method used by goal sync. Production owner sign-in and TEST payment are verified; production multi-account browser login, physical devices and offsite restore have not been certified.

Source is committed and pushed using the Sites source-workflow helper. Publication uses the exact pushed commit and its generated archive. Access expansion is a separate, explicitly requested Sites operation after deploying the authenticated workspace protections.

## Source import verification — 2 November 2026

Six new automated checks cover append semantics, URL-only detection, file and length bounds, passive treatment of markup, editing during a read and navigation during a read. Local browser QA with a synthetic account imported the supplied Gemini TXT, displayed the link-only warning, retained the draft across in-app navigation and downloaded the matching TXT. No external Gemini conversation was retrieved and no AI inference was performed. The Google Drive files named “Google Gemini psd2” were inspected through the task connector; no live Drive connector was added to the Site because Sites plugin eligibility discovery is unavailable in this session. Private Drive contents are not embedded in the public build.

## Public legal and international pages — 2 November 2026

Public, bilingual IT/EN pages: `/terms`, `/privacy`, `/cookies`, `/partners`, `/developers`, `/press`. Each has a table of contents, text download and print layout. The homepage provides a fuller onboarding path, links to these pages and accurate availability. Public discovery includes a 26-entry sitemap and `/llms.txt`; neither proves search indexing or audience reach.

The privacy and terms describe the current free service. Proposal enquiries do not become paid orders. Commercial LIVE sales remain unavailable pending actual service scope, seller/tax details, consumer terms and fulfillment. See `docs/PUBLIC_LEGAL_RELEASE_2026-11-02.md` for primary references and missing inputs.

Local deletion clears only the active account’s workspace, sync baseline and conflict backup; owner deletion additionally removes the legacy workspace to prevent reimport. It does not erase other users or online records. No real user records were deleted during validation.

Current validation: 99 tests pass. Browser preview verified English navigation, terms, privacy text download, partner enquiry entry and the linked privacy notice. Physical-device testing, provider contract audit and worldwide distribution remain unverified.


## Campus, universities and media — 2 November 2026

Public IT/EN `/students`, `/broadcast` and `/alerts` connect study goals, the existing private student profile, media scripts and university pilot proposals. The public `/alerts.xml` RSS feed has a shared editorial source with the readable announcements, stable entry IDs and no access to private profiles. It supports GET/HEAD, language selection and RSS discovery. Copy controls expose a selectable URL if clipboard access is unavailable. No email or push subscription is created; readers choose their notification settings.

Oxford and Cambridge links point to official collaboration and media channels, not to SEVA partners. No external messages were sent. The internal student ID remains self-declared and account-private; SPID and academic verification are unavailable. No real student data was changed. See `docs/CAMPUS_MEDIA_RELEASE_2026-11-02.md` for sources, scope and limits.

Validation: 92 passing automated tests, IT/EN RSS parsed as XML, successful build and ESM validation. Browser preview checked English homepage links, the student guide, availability labels, the copy-link fallback, media layout and TXT download. Clipboard success on public HTTPS and publication are verified separately at handoff; physical devices, RSS-client delivery and institutional identity integrations are not claimed.


## Creators and launch planner — 2 November 2026

`/creators` and `/campaigns` serve Italian and English pathways for musicians, artists, independent campus communities and shops. The planner uses browser-only templates to produce nested goals, criteria, four weeks of actions and three draft messages. Users can copy or download TXT. Inputs stay in page memory; edits invalidate the previous result. No server persistence, AI request, analytics, campaign sending or platform publishing is introduced.

Official Spotify distribution/Shopify-merch and Amazon seller links explain separate provider pathways. The existing RSS feed announces the planner. No plan was purchased, real product published, music uploaded or external message sent. Private connected-store details are excluded from public pages.

Validation: 95 passing automated tests, successful build and Worker ESM validation. Preview browser QA generated Italian campus and English music drafts, downloaded a plan, confirmed edit invalidation and reviewed the creator page. A pre-existing billing test clock race was resolved with a fixed test clock; production billing code is unchanged. See `docs/CREATOR_LAUNCH_RELEASE_2026-11-02.md`.


## Sport and collaboration workflow — 2 November 2026

`/sports` adds public Italian/English pathways for football, basketball and merchants, with official Lega Serie A and NBA contact sources. `/campaigns` supports football and basketball drafts. Homepage, partner page, sitemap, public facts and RSS link the new paths.

`/app?section=partnerships` is authenticated and creates 13 editable goal nodes across four stages: contact, proposal/response, agreement/rights, and pilot outcomes. All start as `Da fare` with empty evidence. Plans reuse account-scoped local storage and existing optional goal synchronization/export; no new database, external messaging or automatic partnership verification is introduced. User-recorded completion is not provider certification.

Validation: 99 passing tests, build and Worker ESM validation. Browser preview checked synthetic plan creation, local persistence after reload, sports IT/EN and an English football campaign. Production-scale capacity, rights, partner agreements, campaign delivery and millions of users are not claimed. See `docs/SPORTS_COLLABORATION_RELEASE_2026-11-02.md`.

## Growth, candidate network and Site MCP — 2 November 2026

`/growth` calculates editable EUR funnel and margin scenarios, including creator share, merchant proceeds, processing/other costs, work value, CAC and economic break-even. The cumulative activated-user target is separate from monthly active users. Wilson 95% intervals work from supplied aggregate counts. These are hypothetical inputs, not SEVA analytics or sales.

`/network` has seven official candidate/resource references with restrictions and allowlisted private-plan presets. No agreement, message, affiliate relationship or commercial availability is claimed. `/payments` separates historical TEST evidence from disabled LIVE checkout and absent seller routing. Stripe account verification is currently blocked by reauthentication.

The hosting manifest declares MCP. `/mcp` provides three stateless read-only calculation/readiness tools. No database, Stripe account or private workspace access; no charges, subscriptions, transfers or sending. Publishing provisions the owner's private Site plugin, not a public marketplace listing. Privacy and developer pages explain the data flow.

107 tests pass, including model arithmetic and failure paths, Wilson intervals, MCP protocol and input limits, no private database access, public routes and preset allowlisting. Preview browser verified calculations, stale-result invalidation, statistics, preset form and synthetic local plan/source evidence. See `docs/GROWTH_PLUGIN_RELEASE_2026-11-02.md`.

## Omnibus Omnia Community · Entry — 2 November 2026

Owner-confirmed proposal: EUR 50/month per account across individuals, students, creators, merchants and businesses. Homepage and payment information show the proposal and its unavailable-to-buy status. Current free access remains unchanged; no account is automatically subscribed. Included service, VAT treatment, renewal/cancellation terms and provider readiness remain prerequisites. No Stripe configuration or charge was changed.

The growth model now has monthly paying subscribers, monthly price, subscription refunds and subscriber service cost. Default 100 subscribers is illustrative: EUR 5,000 gross subscriptions, EUR 100 assumed processing and EUR 200 service cost. Combined with the previous merchant scenario, assumed total revenue after refunds is EUR 5,228 and partial economic margin EUR 4,407.60 before VAT, taxes and excluded costs. Zero subscribers reproduces the original EUR -292.40 merchant-only margin. Subscriber count is independent of the funnel and includes assumed renewals; no churn or LTV is estimated. Shared costs are subtracted once.

109 tests pass. Preview verified Italian/English proposal, default combined calculation, stale-result clearing and zero-subscriber recalculation. Three MCP tools remain read-only and do not sell digital subscriptions.


Community Entry: prezzo proposto 50 €/mese per account IVA inclusa. Prezzo e prodotto Stripe creati e verificati inattivi in TEST; LIVE non abilitato. Calcolatore con scorporo IVA illustrativo. Evidenze e limiti: [VAT_AND_WALLETS_2026-11-02.md](docs/VAT_AND_WALLETS_2026-11-02.md).
