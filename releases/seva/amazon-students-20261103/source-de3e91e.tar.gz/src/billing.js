// Payment Links keep payment credentials on Stripe. This release exposes only
// owner-only TEST checkout. LIVE sales stay closed until fulfillment is defined.
import {requestIdentity} from './identity.js';
const billingJSON=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const stripeId=value=>typeof value==='string'?value:value?.id;
const stripePrice=line=>stripeId(line?.price)||stripeId(line?.pricing?.price_details?.price);
export function billingConfig(env={}){
 let c;try{c=JSON.parse(env.SEVA_BILLING_CONFIG||'{}');}catch{return {plans:[]};}
 return {...c,plans:Array.isArray(c.plans)?c.plans.filter(p=>['test','live'].includes(p.mode)&&typeof p.id==='string'&&typeof p.priceId==='string'&&Number.isSafeInteger(p.amount)&&p.amount>0&&p.currency==='eur'):[]};
}
export async function verifyBillingSignature(raw,header,secret,now=Date.now()){
 if(!secret||!header)throw Error('signature');
 const parts=header.split(',').map(p=>p.trim().split('='));const t=parts.find(p=>p[0]==='t')?.[1];
 if(!/^\d+$/.test(t||'')||Math.abs(now/1000-Number(t))>300)throw Error('signature');
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['verify']);
 const payload=new TextEncoder().encode(t+'.'+raw);let valid=false;
 for(const [kind,value]of parts)if(kind==='v1'&&/^[a-f\d]{64}$/i.test(value||'')){
  const bytes=Uint8Array.from(value.match(/../g),s=>parseInt(s,16));
  if(await crypto.subtle.verify('HMAC',key,bytes,payload))valid=true;
 }
 if(!valid)throw Error('signature');
 const event=JSON.parse(raw);
 if(!/^evt_/.test(event.id||'')||!Number.isInteger(event.created)||!event.data?.object||typeof event.type!=='string')throw Error('event');
 return event;
}
export async function applyBillingEvent(DB,event,env,mode){
 const c=billingConfig(env),account=mode==='test'?c.testAccount:c.liveAccount;
 if(event.livemode!==(mode==='live')||(event.account&&event.account!==account))throw Error('context');
 if(await DB.prepare('SELECT id FROM seva_billing_events WHERE id=?').bind(event.id).first())return {received:true,duplicate:true};
 const obj=event.data.object,plans=c.plans.filter(p=>p.mode===mode),statements=[];
 const q=(sql,...args)=>DB.prepare(sql).bind(...args);
 if(['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type)){
  const intent=await q('SELECT * FROM seva_billing_intents WHERE token=? AND mode=?',obj.client_reference_id||'',mode).first();
  if(intent&&stripeId(obj.payment_link)===intent.link_id&&obj.mode==='subscription'&&obj.status==='complete'&&obj.currency===intent.currency&&obj.amount_subtotal===intent.amount&&stripeId(obj.subscription)&&stripeId(obj.customer)&&Number.isInteger(obj.created)&&obj.created>=intent.created_at&&obj.created<=intent.expires_at){
   // Binding is immutable: a replay or a reused link cannot transfer ownership.
   statements.push(q(`INSERT INTO seva_billing_subscriptions(id,mode,owner_id,customer_id,price_id)
    SELECT ?,mode,owner_id,?,price_id FROM seva_billing_intents WHERE token=? AND (session_id IS NULL OR session_id=?)
    ON CONFLICT(id) DO UPDATE SET owner_id=excluded.owner_id,customer_id=excluded.customer_id
    WHERE seva_billing_subscriptions.mode=excluded.mode AND (seva_billing_subscriptions.owner_id IS NULL OR seva_billing_subscriptions.owner_id=excluded.owner_id)`,stripeId(obj.subscription),stripeId(obj.customer),intent.token,obj.id));
   statements.push(q('UPDATE seva_billing_intents SET session_id=?,subscription_id=? WHERE token=? AND (session_id IS NULL OR session_id=?)',obj.id,stripeId(obj.subscription),intent.token,obj.id));
  }
 }else if(['customer.subscription.created','customer.subscription.updated','customer.subscription.deleted'].includes(event.type)){
  const items=obj.items?.data||[],plan=items.length===1&&!obj.items?.has_more&&items[0].quantity===1?plans.find(p=>p.priceId===stripePrice(items[0])):null;
  const exists=await q('SELECT id FROM seva_billing_subscriptions WHERE id=? AND mode=?',obj.id,mode).first();
  if(plan||exists){
   const canceled=event.type==='customer.subscription.deleted'||obj.status==='canceled';
   statements.push(q(`INSERT INTO seva_billing_subscriptions(id,mode,customer_id,price_id,status,eligible,updated_at,canceled,cancel_at_period_end)
    VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
    price_id=CASE WHEN excluded.updated_at>seva_billing_subscriptions.updated_at THEN excluded.price_id ELSE seva_billing_subscriptions.price_id END,
    status=CASE WHEN excluded.updated_at>seva_billing_subscriptions.updated_at OR (excluded.updated_at=seva_billing_subscriptions.updated_at AND excluded.status!='active') THEN excluded.status ELSE seva_billing_subscriptions.status END,
    eligible=CASE WHEN excluded.updated_at>seva_billing_subscriptions.updated_at THEN excluded.eligible WHEN excluded.updated_at=seva_billing_subscriptions.updated_at THEN MIN(seva_billing_subscriptions.eligible,excluded.eligible) ELSE seva_billing_subscriptions.eligible END,
    updated_at=MAX(seva_billing_subscriptions.updated_at,excluded.updated_at),canceled=MAX(seva_billing_subscriptions.canceled,excluded.canceled),
    cancel_at_period_end=CASE WHEN excluded.updated_at>=seva_billing_subscriptions.updated_at THEN excluded.cancel_at_period_end ELSE seva_billing_subscriptions.cancel_at_period_end END
    WHERE seva_billing_subscriptions.mode=excluded.mode`,obj.id,mode,stripeId(obj.customer)||'',plan?.priceId||'',obj.status||'pending',plan?1:0,event.created,canceled?1:0,obj.cancel_at_period_end?1:0));
  }
 }else if(event.type==='invoice.paid'){
  const sub=stripeId(obj.subscription)||stripeId(obj.parent?.subscription_details?.subscription),lines=obj.lines?.data||[];
  const line=lines.length===1&&!obj.lines?.has_more?lines[0]:null,plan=plans.find(p=>p.priceId===stripePrice(line));
  if(sub&&plan&&line.quantity===1&&!line.proration&&obj.status==='paid'&&obj.paid===true&&obj.paid_out_of_band!==true&&obj.amount_paid>=plan.amount&&obj.amount_remaining===0&&obj.currency===plan.currency&&Number.isInteger(line.period?.start)&&Number.isInteger(line.period?.end)&&line.period.end>line.period.start){
   statements.push(q(`INSERT OR IGNORE INTO seva_billing_periods(invoice_id,mode,subscription_id,price_id,period_start,period_end,payment_intent_id,amount,currency) VALUES(?,?,?,?,?,?,?,?,?)`,obj.id,mode,sub,plan.priceId,line.period.start,line.period.end,stripeId(obj.payment_intent)||'',obj.amount_paid,obj.currency));
  }
 }else if(event.type==='charge.refunded'&&obj.amount_refunded>0){
  statements.push(q('INSERT OR IGNORE INTO seva_billing_reversals(id,mode,invoice_id,payment_intent_id,kind) VALUES(?,?,?,?,?)',obj.id,mode,stripeId(obj.invoice)||'',stripeId(obj.payment_intent)||'','refund_review'));
 }else if(event.type==='charge.dispute.created'){
  // Disputes stay on hold until merchant reconciliation, even if a later event says won.
  statements.push(q('INSERT OR IGNORE INTO seva_billing_reversals(id,mode,invoice_id,payment_intent_id,kind) VALUES(?,?,?,?,?)',obj.id,mode,'',stripeId(obj.payment_intent)||'','dispute_review'));
 }
 // Failure notifications never create paid periods. Expired periods cannot grant access.
 statements.push(q('INSERT OR IGNORE INTO seva_billing_events(id,mode,type,created_at) VALUES(?,?,?,?)',event.id,mode,event.type,event.created));
 await DB.batch(statements);
 return {received:true};
}
export async function billingEntitlements(DB,owner,mode,now=Date.now()){
 const time=Math.floor(now/1000);
 const r=await DB.prepare(`SELECT s.id,s.price_id,s.cancel_at_period_end,p.period_end FROM seva_billing_subscriptions s
  JOIN seva_billing_periods p ON p.subscription_id=s.id AND p.mode=s.mode AND p.price_id=s.price_id
  WHERE s.owner_id=? AND s.mode=? AND s.eligible=1 AND s.canceled=0 AND s.status IN ('active','past_due')
  AND p.period_start<=? AND p.period_end>? AND NOT EXISTS
  (SELECT 1 FROM seva_billing_reversals r WHERE r.mode=p.mode AND ((r.invoice_id!='' AND r.invoice_id=p.invoice_id) OR (r.payment_intent_id!='' AND r.payment_intent_id=p.payment_intent_id)))
  ORDER BY p.period_end DESC LIMIT 20`).bind(owner,mode,time,time).all();
 return r.results||[];
}
export async function handleBillingWebhook(request,env,mode){
 if(request.method!=='POST')return billingJSON({error:'Metodo non consentito'},405);
 const secret=mode==='test'?env.STRIPE_WEBHOOK_SECRET_TEST:env.STRIPE_WEBHOOK_SECRET_LIVE;
 if(!env.DB||!secret)return billingJSON({error:'Webhook non configurato'},503);
 if(Number(request.headers.get('content-length')||0)>262144)return billingJSON({error:'Payload troppo grande'},413);
 let raw;try{raw=await request.text();}catch{return billingJSON({error:'Payload non leggibile'},400);}
 if(raw.length>262144)return billingJSON({error:'Payload troppo grande'},413);
 let event;try{event=await verifyBillingSignature(raw,request.headers.get('stripe-signature'),secret);}catch{return billingJSON({error:'Firma non valida'},400);}
 try{return billingJSON(await applyBillingEvent(env.DB,event,env,mode));}catch(e){return billingJSON({error:e.message==='context'?'Contesto non valido':'Registrazione non completata'},e.message==='context'?400:503);}
}
export async function handleBilling(request,env={}){
 const identity=requestIdentity(request);if(!identity)return billingJSON({error:'Accedi con ChatGPT.'},401);
 const c=billingConfig(env),path=new URL(request.url).pathname;
 if(!env.DB)return billingJSON({error:'Archivio pagamenti non disponibile'},503);
 try{
  if(path==='/api/billing/status'&&request.method==='GET'){
   const active=await billingEntitlements(env.DB,identity.id,'live');
   const result={liveEnabled:false,active:active.map(x=>({plan:c.plans.find(p=>p.priceId===x.price_id)?.id,until:x.period_end})),message:'Le offerte SEVA a pagamento sono in preparazione. Nessun acquisto reale disponibile.'};
   if(identity.isOwner){
    const testActive=await billingEntitlements(env.DB,identity.id,'test');
    const counts=await env.DB.prepare('SELECT mode,COUNT(*) AS count FROM seva_billing_events GROUP BY mode').all();
    Object.assign(result,{owner:true,testReady:!!env.STRIPE_WEBHOOK_SECRET_TEST&&c.testEnabled===true,testPlans:c.plans.filter(p=>p.mode==='test').map(p=>({id:p.id,label:p.label,amount:p.amount,currency:p.currency,interval:p.interval})),testActive:testActive.map(x=>({plan:c.plans.find(p=>p.priceId===x.price_id)?.id,until:x.period_end,cancelAtPeriodEnd:!!x.cancel_at_period_end})),portalUrl:c.testPortalUrl||null,events:counts.results,webhookLiveConfigured:!!env.STRIPE_WEBHOOK_SECRET_LIVE,blockers:['Servizio incluso in ciascun piano e consegna effettiva','Termini di vendita e trattamento IVA dei tre piani','Prova di consegna del servizio commerciale incluso nei piani','Passaggio a checkout LIVE e collaudo del rilascio']});
   }
   return billingJSON(result);
  }
  if(path==='/api/billing/checkout'&&request.method==='POST'){
   // Hard boundary: public customers cannot start test or live purchases.
   if(!identity.isOwner)return billingJSON({error:'Collaudo riservato al titolare'},403);
   if(request.headers.get('origin')!==new URL(request.url).origin)return billingJSON({error:'Origine non autorizzata'},403);
   if(!request.headers.get('content-type')?.startsWith('application/json'))return billingJSON({error:'È richiesto JSON'},415);
   const raw=await request.text();if(raw.length>2000)return billingJSON({error:'Richiesta troppo grande'},413);
   let b;try{b=JSON.parse(raw);}catch{return billingJSON({error:'JSON non valido'},400);}
   if(b.mode!=='test'||b.consent!==true||!/^[a-f\d-]{36}$/.test(b.operationId||'')||Object.keys(b).some(k=>!['plan','mode','consent','operationId'].includes(k)))return billingJSON({error:'Conferma il collaudo TEST'},400);
   const plan=c.plans.find(p=>p.mode==='test'&&p.id===b.plan);
   if(!plan||!c.testEnabled||!env.STRIPE_WEBHOOK_SECRET_TEST)return billingJSON({error:'Checkout TEST non configurato'},503);
   const url=new URL(plan.url);if(url.origin!=='https://buy.stripe.com'||!url.pathname.startsWith('/test_')||url.username||url.password)throw Error('configuration');
   const now=Math.floor(Date.now()/1000);
   let intent=await env.DB.prepare('SELECT * FROM seva_billing_intents WHERE owner_id=? AND operation_id=?').bind(identity.id,b.operationId).first();
   if(intent&&(intent.plan_id!==plan.id||intent.expires_at<now||intent.session_id))return billingJSON({error:'Tentativo concluso o scaduto. Aggiorna lo stato.'},409);
   if((await billingEntitlements(env.DB,identity.id,'test')).some(x=>x.price_id===plan.priceId))return billingJSON({error:'Questo piano TEST è già attivo. Gestiscilo nel portale Stripe.'},409);
   if(!intent){
    const count=await env.DB.prepare('SELECT COUNT(*) AS count FROM seva_billing_intents WHERE owner_id=? AND created_at>?').bind(identity.id,now-3600).first();
    if(count.count>=10)return billingJSON({error:'Limite di collaudo raggiunto. Riprova tra un’ora.'},429);
    const token=crypto.randomUUID().replaceAll('-','');
    await env.DB.prepare('INSERT OR IGNORE INTO seva_billing_intents(token,owner_id,operation_id,plan_id,mode,price_id,link_id,amount,currency,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(token,identity.id,b.operationId,plan.id,'test',plan.priceId,plan.linkId,plan.amount,plan.currency,now,now+86400).run();
    intent=await env.DB.prepare('SELECT * FROM seva_billing_intents WHERE owner_id=? AND operation_id=?').bind(identity.id,b.operationId).first();
   }
   if(intent.plan_id!==plan.id)return billingJSON({error:'Richiesta di collaudo già usata per un altro piano'},409);
   url.searchParams.set('client_reference_id',intent.token);
   return billingJSON({mode:'test',url:url.href,reference:intent.token});
  }
  return billingJSON({error:'Metodo non consentito'},405);
 }catch{return billingJSON({error:'Servizio pagamenti temporaneamente non disponibile'},503);}
}
