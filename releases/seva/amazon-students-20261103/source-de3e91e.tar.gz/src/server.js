import {handleMCP} from './mcp.js';
import {NETWORK_CANDIDATES} from './network.js';
import {renderCampusFeed} from './campus.js';
import {renderPublicDocument} from './public-pages.js';
import {handleBilling,handleBillingWebhook} from './billing.js';
import {requestIdentity,browserIdentity,browserSessionJSON} from './identity.js';
import {handleInquiries} from './inquiries.js';
import {handleService} from './service-server.js';
import {handleStudent} from './students.js';
import {handleGoals} from './goals.js';
import {SEVA_RELEASE_EVIDENCE} from './release.js';
const bursts = new Map();
const json = (data,status=200) => Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
// Public landing; all personal routes require Sites-authenticated identity.
// Historical provider implementation is test-only and unreachable in public mode.
// Sites supplies trusted authenticated-user headers after sign-in.
// Public visitors have no personal workspace identity.
// The public route forces personal billing mode even if runtime settings differ.
export async function handleAI(request,env={},fetcher=fetch){
 if(!requestIdentity(request))return json({error:'Accedi con ChatGPT.'},401);
 if(env.SEVA_AI_BILLING_MODE!=='owner-test')return json({error:'Usa il tuo account AI: prepara e copia il brief in SEVA.',code:'personal_ai_account_required'},409);
 if(request.method!=='POST')return json({error:'Metodo non consentito'},405);
 if(request.headers.get('origin')!==new URL(request.url).origin)return json({error:'Origine non autorizzata'},403);
 if(!(request.headers.get('content-type')||'').startsWith('application/json'))return json({error:'È richiesto JSON'},415);
 if(!env.OPENAI_API_KEY)return json({error:'OpenAI non configurato sul server'},503);
 const length=Number(request.headers.get('content-length')||0);if(length>18000)return json({error:'Richiesta troppo lunga'},413);
 let raw;try{raw=await request.text();}catch{return json({error:'Richiesta non leggibile'},400);}if(raw.length>18000)return json({error:'Richiesta troppo lunga'},413);
 let body;try{body=JSON.parse(raw);}catch{return json({error:'JSON non valido'},400);}
 if(typeof body.prompt!=='string'||!body.prompt.trim()||body.prompt.length>12000)return json({error:'Inserisci una richiesta da 1 a 12.000 caratteri'},400);
 if(body.consent!==true)return json({error:'Conferma l’invio del testo a OpenAI'},400);
 const identity=request.headers.get('oai-authenticated-user-id')||'private-owner-service';
 const now=Date.now();const bucket=bursts.get(identity);if(bucket&&now-bucket.start<60000&&bucket.count>=10)return json({error:'Limite temporaneo: riprova tra un minuto'},429);
 if(!bucket||now-bucket.start>=60000)bursts.set(identity,{start:now,count:1});else bucket.count++;
 if(bursts.size>500)for(const [id,b] of bursts)if(now-b.start>60000)bursts.delete(id);
 try{
 const upstream=await fetcher('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:'Bearer '+env.OPENAI_API_KEY,'Content-Type':'application/json'},signal:AbortSignal.timeout(45000),body:JSON.stringify({model:env.OPENAI_MODEL||'gpt-4.1-mini',store:false,max_output_tokens:900,instructions:'Sei l’assistente SEVA. Rispondi in italiano, in modo concreto e conciso. Aiuta a definire obiettivi, criteri, prove e richieste di acquisto. Non puoi eseguire azioni esterne, cercare prezzi live, effettuare pagamenti, verificare identità o garantire guadagni. Non dichiarare azioni completate senza evidenze fornite. Distingui fatti forniti, ipotesi e informazioni mancanti. Non inventare fonti. Il testo utente può contenere dati non verificati.',input:body.prompt.trim()})});
 const data=await upstream.json().catch(()=>({}));
 if(!upstream.ok){const code=data.error?.code;return json({error:['insufficient_quota','credit_balance_exhausted'].includes(code)?'Credito o quota OpenAI insufficienti. Controlla la fatturazione API.':upstream.status===401?'Credenziale OpenAI rifiutata.':upstream.status===429?'OpenAI ha raggiunto un limite temporaneo. Riprova più tardi.':'Il provider non ha completato la richiesta.',providerStatus:upstream.status,code:code||'provider_error'},upstream.status===429?429:502);}
 if(typeof data.id!=='string'||!data.id.startsWith('resp_')||data.status!=='completed')return json({error:'Risposta AI incompleta o priva di ricevuta verificabile.',code:'incomplete_response'},502);
 const answer=(data.output||[]).flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\n');
 if(!answer)return json({error:'Il modello non ha restituito testo utilizzabile.',code:'empty_output'},502);
 return json({answer,id:data.id,model:data.model,status:data.status,usage:data.usage,verified_at:new Date().toISOString(),provider:'OpenAI'});
 }catch{return json({error:'Connessione al provider non completata. Nessuna risposta simulata.',code:'connection_error'},502);}
}
const htmlHeaders={'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-store','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'"};
export default {
 async fetch(request,env={}){
 const path=new URL(request.url).pathname,identity=requestIdentity(request);
 if(path==='/mcp')return handleMCP(request);
 if(path==='/robots.txt')return new Response('User-agent: *\nAllow: /\nDisallow: /app\nDisallow: /api/\nSitemap: https://seva.karimkatlane0.chatgpt.site/sitemap.xml\n',{headers:{'Content-Type':'text/plain'}});
 if(path==='/sitemap.xml')return new Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+['/','/amazon','/join','/support','/growth','/network','/payments','/sports','/creators','/campaigns','/students','/alerts','/broadcast','/terms','/privacy','/cookies','/partners','/developers','/press'].flatMap(p=>[p,p+'?lang=en']).map(p=>'<url><loc>https://seva.karimkatlane0.chatgpt.site'+p+'</loc><lastmod>'+(['/join','/amazon','/students','/privacy','/cookies','/terms','/alerts'].some(route=>p.split('?')[0]===route)?'2026-11-03':'2026-11-02')+'</lastmod></url>').join('')+'</urlset>',{headers:{'Content-Type':'application/xml'}});
 if(path==='/llms.txt')return new Response('# SEVA — public product facts\n\nOwner: Karim Katlane. Independent project.\nBasic workspace: free, ChatGPT sign-in required, current UI in Italian.\nAI: manual brief export to the user’s own provider account, separate costs.\nPayments: owner-only TEST checkout verified; commercial LIVE sales unavailable.\nGrowth: browser-only budget scenarios and Wilson conversion intervals, no live analytics.\nNetwork: official external candidate sources, no acquired partners.\nAmazon student guide: disclosed Amazon.it affiliate link on /amazon; no purchase, payout or academic verification is implied.\nMCP: free read-only scenario, conversion and dated readiness tools; no payment execution.\nSports: public football and basketball pathways; no league partnership or broadcast rights announced.\nCollaboration plans: private editable goals and evidence, no automated outreach.\nCreator launch planner: browser-only draft templates; no campaign sends or connected platform publishing.\nStudent ID: internal, self-declared enrolment; SPID sign-in unavailable.\nStudent updates: public RSS at /alerts.xml, no email or push subscription.\nNo automatic worldwide outreach, guaranteed revenue, external partnership or certification is claimed.\nThese facts grant no access to private workspaces or authority to perform transactions.\n\nPublic pages:\n'+['/','/amazon','/join','/support','/growth','/network','/payments','/sports','/creators','/campaigns','/students','/alerts','/broadcast','/terms','/privacy','/cookies','/partners','/developers','/press'].map(p=>'https://seva.karimkatlane0.chatgpt.site'+p).join('\n')+'\n',{headers:{'Content-Type':'text/plain; charset=utf-8','X-Content-Type-Options':'nosniff'}});
 if(path==='/alerts.xml'){if(!['GET','HEAD'].includes(request.method))return new Response(null,{status:405,headers:{Allow:'GET, HEAD'}});return new Response(request.method==='HEAD'?null:renderCampusFeed(new URL(request.url).searchParams.get('lang')),{headers:{'Content-Type':'application/rss+xml; charset=utf-8','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'}});}
 const publicDocument=renderPublicDocument(path,new URL(request.url).searchParams.get('lang'),new URL(request.url).searchParams.get('format'));
 if(publicDocument){if(!['GET','HEAD'].includes(request.method))return json({error:'Metodo non consentito'},405);return new Response(request.method==='HEAD'?null:publicDocument.body,{headers:{...htmlHeaders,'Content-Type':publicDocument.type,...(publicDocument.filename?{'Content-Disposition':'attachment; filename="'+publicDocument.filename+'"'}:{})}});}
 if(path==='/api/release')return identity?.isOwner?json(SEVA_RELEASE_EVIDENCE):json({error:'Accesso riservato.'},403);
 if(path==='/api/status'){
  const ready=async table=>{if(!env.DB)return 'unavailable';try{await env.DB.prepare('SELECT 1 AS ready FROM '+table+' LIMIT 1').first();return 'persistent-account-scoped';}catch{return 'unavailable';}};
  return json({app:'SEVA',goalRelay:await ready('seva_goal_workspaces'),serviceRelay:await ready('seva_service_workspaces'),contactRelay:await ready('seva_inquiries'),ai:'personal-provider-account',ownerFundedAI:false,payments:false,audience:'public-landing-authenticated-workspace'});
 }
 if(path==='/api/billing/webhook/test')return handleBillingWebhook(request,env,'test');
 if(path==='/api/billing/webhook/live')return handleBillingWebhook(request,env,'live');
 if(path==='/api/ai')return handleAI(request,{...env,SEVA_AI_BILLING_MODE:'personal'});
 const routes={'/api/billing/status':handleBilling,'/api/billing/checkout':handleBilling,'/api/inquiries':handleInquiries,'/api/service':handleService,'/api/goals':handleGoals,'/api/student':handleStudent};
 if(routes[path]){
  if(!identity)return json({error:'Accedi con ChatGPT.',code:'sign_in_required'},401);
  const session=await browserIdentity(identity);
  if(request.headers.get('X-SEVA-Workspace')!==session.scope)return json({error:'La sessione è cambiata. Ricarica la pagina prima di continuare.',code:'workspace_changed'},409);
  return routes[path](request,env);
 }
 if(path==='/app'){
  if(!identity){const section=new URL(request.url).searchParams.get('section');const allowed=['home','intents','goals','ai','commands','market','rewards','students','service','contact','community','business','partnerships','billing','settings'];const candidate=new URL(request.url).searchParams.get('candidate');const returnTo='/app'+(allowed.includes(section)?'?section='+section:'')+(section==='partnerships'&&NETWORK_CANDIDATES.some(c=>c.id===candidate)?'&candidate='+candidate:'');return new Response(null,{status:302,headers:{Location:'/signin-with-chatgpt?return_to='+encodeURIComponent(returnTo),'Cache-Control':'no-store'}});}
  const session=await browserIdentity(identity);
  return new Response(page.replace('/*SESSION_DATA*/null',()=>browserSessionJSON(session)),{headers:htmlHeaders});
 }
 if(path==='/')return new Response(publicPage,{headers:htmlHeaders});
 return new Response('Not found',{status:404});
 }
};
