// This is a dated application release assessment, never a live Stripe API response.
export function paymentReadiness(){return {
 checkedOn:'2026-11-02',source:'SEVA application release assessment',liveCheckoutEnabled:false,sellerRoutingEnabled:false,
 merchantProviderStatus:'live-account-capabilities-verified-checkout-unavailable'
, currentLiveCheck:{checkedOn:'2026-11-02',chargesEnabled:true,payoutsEnabled:true,immediateRequirements:0,futureTaxInformationRequired:true,taxRegistrations:0,applePayConfigured:true,googlePayAvailable:false,sepaDebitAvailable:false,walletPaymentTested:false,payoutDestinationVerified:false},
 currentTestCheck:{chargesEnabled:true,payoutsEnabled:true,immediateRequirements:0,futureTaxInformationRequired:true,taxRegistrations:0,applePayConfigured:true,googlePayAvailable:false,walletPaymentTested:false},
 communityEntry:{monthlyEUR:50,taxBehavior:'inclusive',billingUnit:'account',stripePriceVerified:true,stripeProductActive:false,stripePriceActive:false,mode:'test',applicableTaxRateVerified:false},
 historicalTest:{verifiedOn:'2026-11-02',mode:'test',checkout:true,signedWebhook:true,entitlement:true,realFunds:false},
 blockers:['Conto Stripe LIVE letto: incassi e accrediti risultano abilitati lato provider. Verificare la destinazione di accredito e completare il checkout commerciale SEVA; questi controlli non sono ancora conclusi.','Definire servizio incluso, consegna, resi, classificazione fiscale e registrazioni applicabili; il prezzo proposto di 50 € al mese include IVA.','Per venditori terzi: scegliere chi vende al cliente e chi gestisce rimborsi e contestazioni; completare onboarding Connect dei singoli venditori.','Collaudare ordine, pagamento, webhook, attribuzione al venditore, rimborso e riconciliazione prima di dichiarare operativi i flussi.'],
 chatgptPlugin:{purpose:'Free planning, calculations and public readiness information',paymentExecution:false,digitalSubscriptionSales:false,physicalGoodsCheckout:'Separate eligible merchant checkout required; none enabled by this plugin'},
 issuingTestCapture:'The Stripe Issuing test-helper capture simulates issued-card authorizations. It does not enable SEVA merchant checkout or real payouts.',
 sources:['https://developers.openai.com/plugins/plugin-guidelines','https://developers.openai.com/plugins/build/monetization','https://docs.stripe.com/api/issuing/authorizations/test_mode_capture']
};}
