// Local QA only: synthetic identity and a separate database, never deployed.
import http from 'node:http';import fs from 'node:fs';import {execFileSync} from 'node:child_process';import {DatabaseSync} from 'node:sqlite';
execFileSync('node',['scripts/compile.mjs']);
const {default:worker}=await import('../worker/index.js');
fs.mkdirSync('.wrangler',{recursive:true});const sql=new DatabaseSync('.wrangler/student-preview.sqlite');
for(const file of fs.readdirSync('drizzle').filter(f=>f.endsWith('.sql'))){sql.exec(fs.readFileSync('drizzle/'+file,'utf8').replaceAll('CREATE TABLE ','CREATE TABLE IF NOT EXISTS ').replaceAll('CREATE UNIQUE INDEX ','CREATE UNIQUE INDEX IF NOT EXISTS ').replaceAll('CREATE INDEX ','CREATE INDEX IF NOT EXISTS '));}
const DB={prepare(q){const s=sql.prepare(q);const bound=(args)=>({async first(){return s.get(...args)||null;},async all(){return {results:s.all(...args)};},async run(){return {meta:{changes:Number(s.run(...args).changes)}};}});return {...bound([]),bind(...args){return bound(args);}};}};
http.createServer(async(req,res)=>{try{
 const chunks=[];for await(const chunk of req)chunks.push(chunk);
 const headers=new Headers(req.headers);headers.set('oai-authenticated-user-id','seva-local-qa-student');
 const method=req.method||'GET';const request=new Request('http://'+req.headers.host+req.url,{method,headers,body:['GET','HEAD'].includes(method)?undefined:Buffer.concat(chunks)});
 const out=await worker.fetch(request,{DB});let data=Buffer.from(await out.arrayBuffer());
 if(out.headers.get('content-type')?.includes('text/html'))data=Buffer.from(data.toString().replace('<body>','<body><div style="background:#fcf0dc;padding:8px;text-align:center">Anteprima locale · account sintetico di collaudo · nessun profilo reale</div>'));
 res.writeHead(out.status,Object.fromEntries(out.headers));res.end(data);
 }catch{res.writeHead(500);res.end('Preview error');}
}).listen(Number(process.env.PORT||process.argv[process.argv.indexOf('--port')+1]||3000),'0.0.0.0');
