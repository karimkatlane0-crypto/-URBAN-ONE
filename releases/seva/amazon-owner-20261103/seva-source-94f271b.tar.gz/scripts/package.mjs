import {readFile,stat} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const output=resolve(process.argv[2]||resolve(root,'site.tar.gz'));
for(const folder of ['dist','drizzle'])if(output.startsWith(resolve(root,folder)+'/'))throw Error('Archive output must be outside deployment inputs');
const manifest=JSON.parse(await readFile(resolve(root,'.openai/hosting.json'),'utf8'));
if(!manifest.project_id)throw Error('Site identity missing');
await stat(resolve(root,'dist/server/index.js'));
const journal=JSON.parse(await readFile(resolve(root,'drizzle/meta/_journal.json'),'utf8'));
for(const entry of journal.entries)await stat(resolve(root,'drizzle',entry.tag+'.sql'));
// Sites reads schema migrations from the archive root. Keep them beside dist,
// even when a build also retains a copy under dist for inspection.
const result=spawnSync('tar',['-czf',output,'.openai/hosting.json','dist','drizzle'],{cwd:root,stdio:'inherit'});
if(result.status!==0)process.exit(result.status||1);
console.log(JSON.stringify({archive:output,bytes:(await stat(output)).size,migrations:journal.entries.length,project_id:manifest.project_id}));
