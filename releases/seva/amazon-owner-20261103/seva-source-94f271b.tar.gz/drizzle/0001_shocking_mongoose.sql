CREATE TABLE `seva_goal_workspaces` (
	`owner_id` text PRIMARY KEY NOT NULL,
	`revision` integer NOT NULL,
	`goals_json` text NOT NULL,
	`updated_at` text NOT NULL,
	`operation_id` text NOT NULL,
	`payload_hash` text NOT NULL
);
