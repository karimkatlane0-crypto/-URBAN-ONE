CREATE TABLE `seva_inquiries` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`category` text NOT NULL,
	`name` text NOT NULL,
	`message` text NOT NULL,
	`response` text NOT NULL,
	`status` text NOT NULL,
	`revision` integer NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
