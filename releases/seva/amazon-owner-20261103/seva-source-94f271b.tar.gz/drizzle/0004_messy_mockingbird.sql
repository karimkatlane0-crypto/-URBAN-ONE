CREATE TABLE `seva_billing_events` (
	`id` text PRIMARY KEY NOT NULL,
	`mode` text NOT NULL,
	`type` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `seva_billing_intents` (
	`token` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`operation_id` text NOT NULL,
	`plan_id` text NOT NULL,
	`mode` text NOT NULL,
	`price_id` text NOT NULL,
	`link_id` text NOT NULL,
	`amount` integer NOT NULL,
	`currency` text NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`session_id` text,
	`subscription_id` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `seva_billing_intent_operation` ON `seva_billing_intents` (`owner_id`,`operation_id`);--> statement-breakpoint
CREATE TABLE `seva_billing_periods` (
	`invoice_id` text PRIMARY KEY NOT NULL,
	`mode` text NOT NULL,
	`subscription_id` text NOT NULL,
	`price_id` text NOT NULL,
	`period_start` integer NOT NULL,
	`period_end` integer NOT NULL,
	`payment_intent_id` text DEFAULT '' NOT NULL,
	`amount` integer NOT NULL,
	`currency` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `seva_billing_period_sub` ON `seva_billing_periods` (`subscription_id`,`mode`);--> statement-breakpoint
CREATE TABLE `seva_billing_reversals` (
	`id` text PRIMARY KEY NOT NULL,
	`mode` text NOT NULL,
	`invoice_id` text DEFAULT '' NOT NULL,
	`payment_intent_id` text DEFAULT '' NOT NULL,
	`kind` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `seva_billing_subscriptions` (
	`id` text PRIMARY KEY NOT NULL,
	`mode` text NOT NULL,
	`owner_id` text,
	`customer_id` text DEFAULT '' NOT NULL,
	`price_id` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`eligible` integer DEFAULT 0 NOT NULL,
	`updated_at` integer DEFAULT 0 NOT NULL,
	`canceled` integer DEFAULT 0 NOT NULL,
	`cancel_at_period_end` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `seva_billing_sub_owner` ON `seva_billing_subscriptions` (`owner_id`,`mode`);