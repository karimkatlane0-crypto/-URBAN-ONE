export const COMMAND_DOMAINS=['Strategia','Prodotto','Sviluppo software','DevSecOps','Dati e analisi','Ricerca','Operazioni','Clienti e servizi','Scenari economici','Formazione'];
export const COMMAND_ACTIONS=['Definisci un obiettivo','Scomponi il lavoro','Analizza il problema','Confronta le opzioni','Prepara un piano','Verifica le evidenze','Revisiona una proposta','Definisci le misure','Documenta una decisione','Prepara la prossima iterazione'];
export const COMMAND_METHODS=['Ampiezza: valuta tutti i rami','Profondità: completa un ramo','Avanti: dai requisiti al risultato','Indietro: dal risultato ai prerequisiti','Esplicita le ipotesi','Valuta rischi e incertezze','Analizza le cause','Ordina le priorità','Confronta gli scenari','Definisci criteri di accettazione'];
export const COMMAND_FORMATS=['Piano a cinque livelli','Checklist verificabile','Tabella di confronto','Registro della decisione','Sintesi executive','Piano di collaudo','Runbook operativo','Registro delle fonti','Piano di iterazione','Domande da risolvere'];
export const COMMAND_COUNT=10000;
export function commandAt(index){
 if(!Number.isInteger(index)||index<0||index>=COMMAND_COUNT)throw Error('Comando non valido');
 const domain=Math.floor(index/1000),action=Math.floor(index/100)%10,method=Math.floor(index/10)%10,format=index%10;
 return {id:'SEVA-C'+String(index+1).padStart(5,'0'),index,domain,action,method,format,title:COMMAND_ACTIONS[action]+' · '+COMMAND_DOMAINS[domain],methodLabel:COMMAND_METHODS[method],formatLabel:COMMAND_FORMATS[format]};
}
export function findCommands({query='',domain='',offset=0,limit=20}={}){
 if(typeof query!=='string'||query.length>200||!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<1||limit>50||domain!==''&&(!Number.isInteger(Number(domain))||Number(domain)<0||Number(domain)>9))throw Error('Filtri non validi');
 const fold=s=>s.normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase(),needle=fold(query.trim());
 const items=[];let total=0;
 for(let i=0;i<COMMAND_COUNT;i++){
  const c=commandAt(i);
  if(domain!==''&&c.domain!==Number(domain)||needle&&!fold([c.id,c.title,c.methodLabel,c.formatLabel].join(' ')).includes(needle))continue;
  if(total>=offset&&items.length<limit)items.push(c);total++;
 }
 return {items,total,offset,nextOffset:offset+items.length<total?offset+items.length:null};
}
export function commandPrompt(index,context=''){
 if(typeof context!=='string'||context.length>6000)throw Error('Contesto massimo 6.000 caratteri');
 const c=commandAt(index);
 return ['SEVA · '+c.id,'Ambito: '+COMMAND_DOMAINS[c.domain],'Compito: '+COMMAND_ACTIONS[c.action],'Metodo: '+c.methodLabel,'Formato: '+c.formatLabel,'Contesto fornito dal titolare:',context.trim()||'MANCANTE: chiedi i dati necessari prima di trarre conclusioni.','Istruzioni: distingui fatti, ipotesi e informazioni mancanti. Definisci obiettivo, sotto-obiettivi, criteri, prove e prossimo passo. Indica fonti primarie e date soltanto se disponibili; non inventare citazioni, dati, autorizzazioni o azioni completate. Le raccomandazioni non eseguono acquisti, pagamenti, comunicazioni o modifiche a sistemi.'].join('\n');
}
