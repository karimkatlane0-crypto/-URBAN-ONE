function commandLibraryHTML(){return hero('SEVA · LIBRERIA DI BRIEF','10.000 combinazioni.<br>Un compito alla volta.','Cerca un modello, aggiungi il contesto e aprilo nell’Assistente AI. Copia il brief e invialo dal tuo account del provider, secondo le condizioni del tuo piano.')+`<section class="panel"><div class="two"><div><label for="commandSearch">Cerca per codice o contenuto</label><input id="commandSearch" maxlength="200" placeholder="Es. SEVA-C00001, rischi, collaudo"></div><div><label for="commandDomain">Ambito</label><select id="commandDomain"><option value="">Tutti gli ambiti</option>${COMMAND_DOMAINS.map((d,i)=>`<option value="${i}">${E(d)}</option>`).join('')}</select></div></div><label for="commandContext">Contesto del compito (facoltativo)</label><textarea id="commandContext" maxlength="6000" placeholder="Dati, vincoli, fonti e risultato atteso. Evita dati personali non necessari."></textarea><p class="small">10 ambiti × 10 compiti × 10 metodi × 10 formati. Sono combinazioni di brief, non 10.000 agenti o esecuzioni già avvenute. Nessuna chiamata AI parte dalla ricerca.</p><p id="commandCount" role="status" aria-live="polite"></p><div id="commandResults" class="intent-grid"></div><div class="row" style="margin-top:18px"><button id="commandPrevious">← Precedenti</button><button id="commandNext">Successivi →</button></div></section>`;}
function bindCommandLibrary(){
 let offset=0;
 const search=$('#commandSearch'),domain=$('#commandDomain'),results=$('#commandResults');
 const paint=()=>{
  const page=findCommands({query:search.value,domain:domain.value,offset,limit:20});
  $('#commandCount').textContent=page.total?`${offset+1}–${offset+page.items.length} di ${page.total} combinazioni`:'Nessun comando trovato';
  results.innerHTML=page.items.map(c=>`<article class="intent"><div class="body"><span class="pill">${E(c.id)}</span><h3 style="margin-top:12px">${E(c.title)}</h3><p>${E(c.methodLabel)}</p><p class="small">${E(c.formatLabel)}</p><button type="button" data-open-command="${c.index}">Prepara il brief →</button></div></article>`).join('');
  $('#commandPrevious').disabled=offset===0;$('#commandNext').disabled=page.nextOffset===null;
 };
 search.oninput=domain.onchange=()=>{offset=0;paint();};
 $('#commandPrevious').onclick=()=>{offset=Math.max(0,offset-20);paint();};
 $('#commandNext').onclick=()=>{offset+=20;paint();};
 results.onclick=event=>{const button=event.target.closest('[data-open-command]');if(!button)return;pendingAIPrompt=commandPrompt(Number(button.dataset.openCommand),$('#commandContext').value);go('ai');};
 paint();
}
