// Staged direct Checkout integration. Missing configuration always fails closed.
// Credentials are server-only Sites secrets; the browser never supplies a price,
// customer, account, redirect URL or tax rule.
export const ENTRY_TERMS_VERSION='entry-2026-11-03';
export function liveBillingConfig(env={}){
 let c;try{c=JSON.parse(env.SEVA_LIVE_BILLING_CONFIG||'{}');}catch{c={};}
 const valid=c.accountId==='acct_1UQI83RzfcoKq6cn'&&/^price_[A-Za-z0-9]+$/.test(c.priceId||'')&&/^prod_[A-Za-z0-9]+$/.test(c.productId||'')&&c.amount===5000&&c.currency==='eur'&&c.interval==='month';
 return {...c,valid,enabled:c.enabled===true&&valid,planId:'community_entry',termsVersion:ENTRY_TERMS_VERSION};
}
export function liveBillingPreparation(env={}){
 const c=liveBillingConfig(env),checks={
  catalog:c.valid,
  credential:/^(?:rk|sk)_live_/.test(env.STRIPE_RESTRICTED_KEY_LIVE||''),
  webhook:!!env.STRIPE_WEBHOOK_SECRET_LIVE,
  tax:c.taxVerified===true,
  service:c.fulfillmentVerified===true,
  saleTerms:c.termsPublished===ENTRY_TERMS_VERSION,
  portal:/^bpc_[A-Za-z0-9]+$/.test(c.portalConfiguration||''),
  release:c.enabled===true
 };
 return {ready:Object.values(checks).every(Boolean),checks};
}
const liveReply=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const liveId=v=>typeof v==='string'?v:v?.id;
export class SevaStripeHTTP {
 constructor(env,fetcher=fetch){this.key=env.STRIPE_RESTRICTED_KEY_LIVE;this.fetcher=fetcher;}
 async request(path,{method='GET',body,key}={}){
  if(!/^(?:rk|sk)_live_/.test(this.key||'')||!/^\/v1\/[a-z_\/A-Za-z0-9?=&%\[\].-]+$/.test(path))throw Error('provider');
  const response=await this.fetcher('https://api.stripe.com'+path,{method,redirect:'error',signal:AbortSignal.timeout(15000),headers:{Authorization:'Bearer '+this.key,'Stripe-Version':'2026-10-28.endive',...(body?{'Content-Type':'application/x-www-form-urlencoded'}:{}),...(key?{'Idempotency-Key':key}:{})},...(body?{body:new URLSearchParams(body).toString()}:{})});
  if(!response.ok)throw Error('provider');
  const data=await response.json();if(!data||data.error)throw Error('provider');return data;
 }
}
export async function normalizeLiveBillingEvent(event,env,fetcher=fetch){
 const client=new SevaStripeHTTP(env,fetcher),c=liveBillingConfig(env);
 const account=await client.request('/v1/account');if(!c.valid||account.id!==c.accountId)throw Error('account');
 let obj=event.data.object;
 if(event.type==='invoice.paid'){
  const payments=await client.request('/v1/invoice_payments?invoice='+encodeURIComponent(obj.id)+'&status=paid&limit=100');
  const p=payments.data?.[0];if(payments.has_more||payments.data?.length!==1||p.livemode!==true||p.payment?.type!=='payment_intent'||liveId(p.invoice)!==obj.id||p.amount_paid!==5000||p.currency!=='eur')throw Error('invoice_payment');
  obj={...obj,paid:obj.status==='paid'&&p.status==='paid',payment_intent:liveId(p.payment.payment_intent)};
 }else if(['charge.refunded','charge.dispute.created','radar.early_fraud_warning.created'].includes(event.type)){
  let pi=liveId(obj.payment_intent);
  if(!pi&&liveId(obj.charge)){const charge=await client.request('/v1/charges/'+liveId(obj.charge));if(charge.livemode!==true)throw Error('context');pi=liveId(charge.payment_intent);}
  const invoices=[];let after='';
  if(pi)for(let page=0;page<10;page++){
   const qs=new URLSearchParams({'payment[type]':'payment_intent','payment[payment_intent]':pi,status:'paid',limit:'100',...(after?{starting_after:after}:{})});
   const list=await client.request('/v1/invoice_payments?'+qs.toString());
   for(const p of list.data||[])if(p.livemode===true&&p.status==='paid'&&liveId(p.payment?.payment_intent)===pi)invoices.push(liveId(p.invoice));
   if(!list.has_more)break;if(page===9||!list.data?.length)throw Error('pagination');after=list.data.at(-1).id;
  }
  obj={...obj,payment_intent:pi||'',seva_invoice_ids:[...new Set(invoices.filter(Boolean))]};
 }
 return {...event,data:{...event.data,object:obj}};
}
export function validStripeHostedURL(value,kind){
 try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&u.hostname===(kind==='portal'?'billing.stripe.com':'checkout.stripe.com');}catch{return false;}
}
export async function verifyLiveCatalog(client,c){
 const [account,price,product,tax,registrations,portal]=await Promise.all([
  client.request('/v1/account'),client.request('/v1/prices/'+c.priceId),client.request('/v1/products/'+c.productId),
  client.request('/v1/tax/settings'),client.request('/v1/tax/registrations?status=active&limit=100'),client.request('/v1/billing_portal/configurations/'+c.portalConfiguration)
 ]);
 if(account.id!==c.accountId||account.charges_enabled!==true||account.payouts_enabled!==true)throw Error('account');
 if(price.id!==c.priceId||price.livemode!==true||price.active!==true||liveId(price.product)!==c.productId||price.unit_amount!==5000||price.currency!=='eur'||price.type!=='recurring'||price.recurring?.interval!=='month'||price.recurring.interval_count!==1||price.recurring.usage_type!=='licensed'||price.tax_behavior!=='inclusive')throw Error('catalog');
 if(product.id!==c.productId||product.livemode!==true||product.active!==true||!liveId(product.tax_code))throw Error('catalog');
 if(tax.status!=='active'||!registrations.data?.some(r=>r.status==='active'))throw Error('tax');
 if(portal.active!==true||portal.livemode!==true||portal.features?.subscription_cancel?.enabled!==true||portal.features.subscription_cancel.mode!=='at_period_end')throw Error('portal');
 return true;
}
export async function handleLiveBilling(request,env,identity,fetcher=fetch){
 if(!identity)return liveReply({error:'Accedi con ChatGPT.'},401);
 if(request.method!=='POST')return liveReply({error:'Metodo non consentito'},405);
 if(request.headers.get('origin')!==new URL(request.url).origin)return liveReply({error:'Origine non autorizzata'},403);
 if(!request.headers.get('content-type')?.startsWith('application/json'))return liveReply({error:'È richiesto JSON'},415);
 const raw=await request.text();if(raw.length>2000)return liveReply({error:'Richiesta troppo grande'},413);
 let b;try{b=JSON.parse(raw);}catch{return liveReply({error:'JSON non valido'},400);}
 if(!b||typeof b!=='object'||Array.isArray(b))return liveReply({error:'Richiesta non valida'},400);
 if(!env.DB)return liveReply({error:'Archivio pagamenti non disponibile'},503);
 const c=liveBillingConfig(env),client=new SevaStripeHTTP(env,fetcher),portal=new URL(request.url).pathname==='/api/billing/portal';
 // Billing management remains available even if new sales are paused.
 if(portal){
  if(Object.keys(b).some(k=>k!=='operationId')||!/^[a-f\d-]{36}$/.test(b.operationId||''))return liveReply({error:'Richiesta non valida'},400);
  if(!c.valid||!env.STRIPE_RESTRICTED_KEY_LIVE||!c.portalConfiguration)return liveReply({error:'Gestione abbonamento non configurata. Contatta SEVA.'},503);
  try{
   const row=await env.DB.prepare("SELECT customer_id FROM seva_billing_subscriptions WHERE owner_id=? AND mode='live' AND customer_id!='' ORDER BY updated_at DESC LIMIT 1").bind(identity.id).first();
   if(!row)return liveReply({error:'Nessun abbonamento associato a questo account.'},404);
   const account=await client.request('/v1/account');if(account.id!==c.accountId)throw Error('account');
   const session=await client.request('/v1/billing_portal/sessions',{method:'POST',key:'seva-portal-'+crypto.randomUUID(),body:{customer:row.customer_id,configuration:c.portalConfiguration,return_url:'https://seva.karimkatlane0.chatgpt.site/app?section=billing'}});
   if(!validStripeHostedURL(session.url,'portal'))throw Error('provider');return liveReply({url:session.url});
  }catch{return liveReply({error:'Gestione Stripe temporaneamente non disponibile. Nessun nuovo addebito avviato.'},503);}
 }
 if(Object.keys(b).some(k=>!['operationId','consent','termsVersion'].includes(k))||b.consent!==true||b.termsVersion!==ENTRY_TERMS_VERSION||!/^[a-f\d-]{36}$/.test(b.operationId||''))return liveReply({error:'Conferma prezzo, rinnovo mensile e condizioni prima di procedere.'},400);
 if(!liveBillingPreparation(env).ready)return liveReply({error:'Il piano da 50 € al mese non è ancora acquistabile. La configurazione LIVE è incompleta.'},503);
 try{
  await verifyLiveCatalog(client,c);
  const active=await env.DB.prepare("SELECT id FROM seva_billing_subscriptions WHERE owner_id=? AND mode='live' AND status NOT IN ('canceled','incomplete_expired') LIMIT 1").bind(identity.id).first();
  if(active)return liveReply({error:'Hai già un abbonamento o un pagamento in corso. Usa Gestisci abbonamento.'},409);
  const now=Math.floor(Date.now()/1000);
  // One outstanding intent per owner, even when requests use different UUIDs.
  let intent=await env.DB.prepare("SELECT * FROM seva_billing_intents WHERE owner_id=? AND mode='live' ORDER BY created_at DESC,rowid DESC LIMIT 1").bind(identity.id).first();
  if(intent?.session_id){
   const existing=await client.request('/v1/checkout/sessions/'+intent.session_id);
   if(existing.livemode!==true||existing.client_reference_id!==intent.token||existing.id!==intent.session_id)throw Error('binding');
   let reconciledCancellation=false;
   if(existing.status==='complete'){
    const ended=intent.subscription_id&&await env.DB.prepare("SELECT id FROM seva_billing_subscriptions WHERE id=? AND owner_id=? AND mode='live' AND status='canceled' AND canceled=1").bind(intent.subscription_id,identity.id).first();
    if(!ended)return liveReply({error:'Pagamento già concluso: attendi la conferma del server e aggiorna lo stato.'},409);
    await env.DB.prepare('UPDATE seva_billing_intents SET expires_at=? WHERE token=?').bind(now-1,intent.token).run();
    intent.expires_at=now-1;reconciledCancellation=true;
   }
   if(existing.status==='open'&&existing.expires_at>now&&intent.expires_at>now){
    if(intent.price_id!==c.priceId||!validStripeHostedURL(existing.url,'checkout'))throw Error('binding');
    return liveReply({mode:'live',url:existing.url});
   }
   if(existing.status!=='expired'&&!reconciledCancellation)return liveReply({error:'La precedente sessione deve essere riconciliata prima di riprovare.'},409);
  }
  if(!intent||intent.expires_at<=now){
   const count=await env.DB.prepare("SELECT COUNT(*) count FROM seva_billing_intents WHERE owner_id=? AND mode='live' AND created_at>?").bind(identity.id,now-3600).first();
   if(count.count>=5)return liveReply({error:'Limite di tentativi raggiunto. Riprova più tardi.'},429);
   const token=crypto.randomUUID().replaceAll('-','');
   await env.DB.prepare("INSERT OR IGNORE INTO seva_billing_intents(token,owner_id,operation_id,plan_id,mode,price_id,link_id,amount,currency,created_at,expires_at) SELECT ?,?,?,?,'live',?,'',5000,'eur',?,? WHERE NOT EXISTS (SELECT 1 FROM seva_billing_intents WHERE owner_id=? AND mode='live' AND expires_at>?)").bind(token,identity.id,b.operationId,c.planId,c.priceId,now,now+3600,identity.id,now).run();
   intent=await env.DB.prepare("SELECT * FROM seva_billing_intents WHERE owner_id=? AND mode='live' AND expires_at>? ORDER BY created_at DESC,rowid DESC LIMIT 1").bind(identity.id,now).first();
  }
  if(!intent||intent.price_id!==c.priceId||intent.amount!==5000||intent.expires_at-now<1800)return liveReply({error:'Tentativo in scadenza. Riprova dopo la scadenza della sessione precedente.'},409);
  // Stripe idempotency uses the DB token, not client-controlled parameters.
  const session=await client.request('/v1/checkout/sessions',{method:'POST',key:'seva-entry-'+intent.token,body:{
   mode:'subscription','line_items[0][price]':c.priceId,'line_items[0][quantity]':'1',client_reference_id:intent.token,
   expires_at:String(intent.expires_at),success_url:'https://seva.karimkatlane0.chatgpt.site/app?section=billing&checkout=return',cancel_url:'https://seva.karimkatlane0.chatgpt.site/app?section=billing',
   'automatic_tax[enabled]':'true','tax_id_collection[enabled]':'true','adaptive_pricing[enabled]':'false',
   'consent_collection[terms_of_service]':'required',integration_identifier:'seva_entry_'+intent.token.slice(0,8).replace(/[0-9]/g,n=>String.fromCharCode(97+Number(n)))
  }});
  if(!/^cs_live_/.test(session.id||'')||session.livemode!==true||session.mode!=='subscription'||session.status!=='open'||session.client_reference_id!==intent.token||session.currency!=='eur'||(session.amount_total!==5000&&!(session.amount_total===null&&session.amount_subtotal===5000&&session.automatic_tax?.enabled===true))||session.payment_link||!validStripeHostedURL(session.url,'checkout'))throw Error('provider');
  await env.DB.prepare('UPDATE seva_billing_intents SET session_id=? WHERE token=? AND (session_id IS NULL OR session_id=?)').bind(session.id,intent.token,session.id).run();
  const saved=await env.DB.prepare('SELECT session_id FROM seva_billing_intents WHERE token=?').bind(intent.token).first();if(saved.session_id!==session.id)throw Error('binding');
  return liveReply({mode:'live',url:session.url});
 }catch{return liveReply({error:'Checkout LIVE non disponibile: configurazione o risposta Stripe da verificare. Nessun accesso a pagamento è stato assegnato.'},503);}
}
