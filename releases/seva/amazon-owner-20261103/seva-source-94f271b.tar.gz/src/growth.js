// Deterministic scenarios only. No provider calls, purchases, analytics or persistence.
export const GROWTH_DEFAULTS={monthlySubscribers:100,subscriptionPrice:50,subscriptionVatRate:22,subscriptionRefundRate:0,subscriptionCost:2,visits:10000,targetActiveUsers:10000000,signupRate:8,activationRate:40,purchaseRate:10,ordersPerBuyer:1.5,aov:50,refundRate:5,takeRate:10,creatorRate:3,processingRate:1.5,processingFixed:.25,variableCostPerOrder:.5,marketingCash:0,hours:20,hourCost:15,fixedCost:50,extraPaymentCosts:30,feePayer:'platform'};
export function growthScenario(input={}){
 if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!Object.hasOwn(GROWTH_DEFAULTS,k)))throw Error('Parametri dello scenario non validi.');
 const p={...GROWTH_DEFAULTS,...input};
 for(const [key,value] of Object.entries(p)){
  if(key==='feePayer'){if(!['platform','seller'].includes(value))throw Error('Scegli chi sostiene le commissioni.');continue;}
  const max=key.endsWith('Rate')?100:key==='ordersPerBuyer'?100:1e9;
  if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>max)throw Error('Valore non valido: '+key);
 }
 if(!Number.isInteger(p.visits)||!Number.isInteger(p.targetActiveUsers)||!Number.isInteger(p.monthlySubscribers)||p.ordersPerBuyer<1)throw Error('Visite, obiettivi e abbonati interi; almeno un ordine per acquirente.');
 if(p.creatorRate>p.takeRate)throw Error('La quota creator, qui a carico di SEVA, non può superare la commissione SEVA.');
 const signups=p.visits*p.signupRate/100,activeUsers=signups*p.activationRate/100,buyers=activeUsers*p.purchaseRate/100,orders=buyers*p.ordersPerBuyer;
 const grossVolume=orders*p.aov,netVolume=grossVolume*(1-p.refundRate/100),platformRevenue=netVolume*p.takeRate/100,creatorShare=netVolume*p.creatorRate/100;
 const processingFees=grossVolume*p.processingRate/100+orders*p.processingFixed,platformProcessing=p.feePayer==='platform'?processingFees:0;
 const variableCosts=orders*p.variableCostPerOrder,contribution=platformRevenue-creatorShare-platformProcessing-variableCosts;
 const subscriptionGrossRevenue=p.monthlySubscribers*p.subscriptionPrice,subscriptionAfterRefunds=subscriptionGrossRevenue*(1-p.subscriptionRefundRate/100);
 const subscriptionNetRevenue=subscriptionAfterRefunds/(1+p.subscriptionVatRate/100),subscriptionVat=subscriptionAfterRefunds-subscriptionNetRevenue;
 const subscriptionProcessingFees=subscriptionGrossRevenue*p.processingRate/100+p.monthlySubscribers*p.processingFixed;
 const subscriptionVariableCosts=p.monthlySubscribers*p.subscriptionCost,subscriptionContribution=subscriptionNetRevenue-subscriptionProcessingFees-subscriptionVariableCosts;
 const subscriptionUnitContribution=p.subscriptionPrice*(1-p.subscriptionRefundRate/100)/(1+p.subscriptionVatRate/100)-p.subscriptionPrice*p.processingRate/100-p.processingFixed-p.subscriptionCost;
 const totalRevenue=platformRevenue+subscriptionNetRevenue;
 const workValue=p.hours*p.hourCost,salesOnlyCashMargin=contribution-p.marketingCash-p.fixedCost-p.extraPaymentCosts,salesOnlyEconomicMargin=salesOnlyCashMargin-workValue;
 const cashMargin=salesOnlyCashMargin+subscriptionContribution,economicMargin=cashMargin-workValue;
 const unitContribution=p.aov*(1-p.refundRate/100)*(p.takeRate-p.creatorRate)/100-(p.feePayer==='platform'?p.aov*p.processingRate/100+p.processingFixed:0)-p.variableCostPerOrder;
 const fixedBudget=p.marketingCash+p.fixedCost+p.extraPaymentCosts+workValue;
 return {kind:'illustrative-scenario',period:'one-month',currency:'EUR',inputs:p,signups,activeUsers,buyers,orders,grossVolume,refunds:grossVolume-netVolume,netVolume,platformRevenue,creatorShare,processingFees,platformProcessing,variableCosts,workValue,cashMargin,economicMargin,unitContribution,
  subscriptionGrossRevenue,subscriptionAfterRefunds,subscriptionVat,subscriptionNetRevenue,subscriptionProcessingFees,subscriptionVariableCosts,subscriptionContribution,subscriptionUnitContribution,totalRevenue,salesOnlyCashMargin,salesOnlyEconomicMargin,
  breakEvenSubscribers:subscriptionUnitContribution>0?Math.ceil(Math.max(0,fixedBudget-contribution)/subscriptionUnitContribution):contribution>=fixedBudget?0:null,
  targetVisits:p.signupRate*p.activationRate>0?Math.ceil(p.targetActiveUsers/(p.signupRate*p.activationRate/10000)):null,
  sellerProceedsBeforeOtherCosts:netVolume-platformRevenue-(p.feePayer==='seller'?processingFees:0),
  cacCash:buyers>0?p.marketingCash/buyers:null,cacWithWork:buyers>0?(p.marketingCash+workValue)/buyers:null,
  breakEvenOrders:unitContribution>0?Math.ceil(fixedBudget/unitContribution):null,
  breakEvenVisits:unitContribution>0&&p.signupRate*p.activationRate*p.purchaseRate>0?Math.ceil(Math.ceil(fixedBudget/unitContribution)/(p.signupRate*p.activationRate*p.purchaseRate/1e6*p.ordersPerBuyer)):null,
  limitations:['Ipotesi mensili modificabili, non misure di traffico, vendite o incassi. Tutti gli acquirenti del funnel sono ipotizzati nuovi.','Gli abbonati paganti sono un conteggio separato: non sono automaticamente gli iscritti o gli utenti attivati. Possono comprendere rinnovi; non sommarli agli acquirenti come persone uniche. Il modello non stima abbandono o LTV.','Abbonamenti lordi = account paganti × prezzo IVA inclusa. Ricavo netto IVA = lordo dopo resi / (1 + aliquota / 100). Il 22% iniziale è solo un esempio modificabile, non il regime fiscale verificato di Karim o dei clienti. Stima aggregata: gli arrotondamenti per fattura possono differire. Il valore iniziale di 100 abbonati è un esempio, non un dato SEVA.','GMV è il valore delle vendite dei negozi: non è ricavo SEVA. Commissioni SEVA e creator applicate al volume dopo resi; le percentuali di commissione sono ipotesi nette IVA. IVA sulle commissioni dei negozi e detrazione IVA sui costi non sono modellate.','Quota creator a carico delle sole commissioni di vendita SEVA. Elaborazione su lordo e costi anche sui rimborsi. Le commissioni di abbonamento sono sempre a carico SEVA; la scelta del pagatore vale solo per gli ordini dei negozi.','I costi Connect, payout, Billing, dispute, valuta e altri servizi vanno inseriti in Altri costi pagamenti. Importi predefiniti e 2 € di servizio per abbonato sono ipotesi, non tariffe del tuo account.','Margini parziali dopo lo scorporo IVA ipotizzato sugli abbonamenti, prima di altre imposte e costi non inseriti; nessuna previsione o garanzia di guadagno. Prezzo Entry 50 € IVA inclusa; aliquota, registrazioni e classificazione del servizio da verificare prima della vendita. Pareggio a parametri e capacità invariati.']};
}
export function conversionInterval(input={}){
 if(!input||Object.keys(input).some(k=>!['trials','successes'].includes(k)))throw Error('Parametri statistici non validi.');
 const {trials,successes}=input;
 if(!Number.isSafeInteger(trials)||!Number.isSafeInteger(successes)||trials<0||trials>1e9||successes<0||successes>trials)throw Error('Usa conteggi interi: successi tra zero e totale.');
 if(trials===0)return {trials,successes,rate:null,lower95:null,upper95:null,method:'Wilson 95%',note:'Nessuna osservazione: tasso non misurato, non zero.'};
 const z=1.959963984540054,p=successes/trials,z2=z*z,den=1+z2/trials,center=(p+z2/(2*trials))/den,half=z*Math.sqrt(p*(1-p)/trials+z2/(4*trials*trials))/den;
 return {trials,successes,rate:p,lower95:Math.max(0,center-half),upper95:Math.min(1,center+half),method:'Wilson 95%',note:'Conteggi forniti dall’utente; deduplicare persone e usare la stessa coorte e periodo. Intervallo per osservazioni indipendenti; non prova causalità o risultati futuri.'};
}
export function growthReport(s){
 const n=v=>v===null?'Non definito':new Intl.NumberFormat('it-IT',{maximumFractionDigits:2}).format(v),eur=v=>n(v)+' €';
 return ['SEVA · SCENARIO ILLUSTRATIVO · NON SONO INCASSI REALI',
 'Periodo: un mese','Abbonati paganti ipotizzati: '+n(s.inputs.monthlySubscribers),'Prezzo mensile ipotizzato IVA inclusa: '+eur(s.inputs.subscriptionPrice),
 'Abbonamenti mensili lordi: '+eur(s.subscriptionGrossRevenue),'Abbonamenti dopo resi IVA inclusa: '+eur(s.subscriptionAfterRefunds),'Aliquota IVA abbonamenti ipotizzata: '+n(s.inputs.subscriptionVatRate)+'%','IVA abbonamenti stimata: '+eur(s.subscriptionVat),'Abbonamenti al netto IVA: '+eur(s.subscriptionNetRevenue),'Elaborazione abbonamenti: '+eur(s.subscriptionProcessingFees),'Servizio per abbonati: '+eur(s.subscriptionVariableCosts),'Contributo abbonamenti: '+eur(s.subscriptionContribution),
 'Nuovi iscritti: '+n(s.signups),'Nuovi utenti attivati: '+n(s.activeUsers),'Nuovi acquirenti: '+n(s.buyers),'Ordini attesi: '+n(s.orders),
 'GMV lordo dei venditori: '+eur(s.grossVolume),'Resi ipotizzati: '+eur(s.refunds),'GMV dopo resi: '+eur(s.netVolume),
 'Commissioni SEVA ipotizzate nette IVA: '+eur(s.platformRevenue),'Ricavi SEVA combinati dopo resi e IVA modellata: '+eur(s.totalRevenue),'Quota creator a carico SEVA: '+eur(s.creatorShare),
 'Elaborazione ordini negozi: '+eur(s.processingFees)+' · quota a carico SEVA: '+eur(s.platformProcessing),
 'Costi servizio ordini negozi: '+eur(s.variableCosts),'Valore del lavoro: '+eur(s.workValue),
 'Margine solo commercio dopo lavoro: '+eur(s.salesOnlyEconomicMargin),'Margine combinato parziale di cassa: '+eur(s.cashMargin),'Margine combinato dopo valore del lavoro: '+eur(s.economicMargin),'Abbonati per pareggio con il commercio ipotizzato: '+n(s.breakEvenSubscribers),
 'CAC monetario nuovi acquirenti: '+(s.cacCash===null?'Non definito':eur(s.cacCash)),'CAC nuovi acquirenti con lavoro: '+(s.cacWithWork===null?'Non definito':eur(s.cacWithWork)),
 'Nuovi utenti attivati obiettivo: '+n(s.inputs.targetActiveUsers),'Visite necessarie per tale obiettivo: '+n(s.targetVisits),'Obiettivo cumulativo a tassi invariati; non utenti mensili attivi o capacità verificata.',
 'Contributo per ordine: '+eur(s.unitContribution),'Ordini per pareggio senza abbonamenti: '+n(s.breakEvenOrders),'Visite per pareggio senza abbonamenti: '+n(s.breakEvenVisits),
 '',...s.limitations,'','IPOTESI',...Object.entries(s.inputs).map(([k,v])=>k+': '+v)].join('\n');
}
