export const AI_BRIEF_LIMIT=12000;
export const AI_SOURCE_BYTES=65536;

export function importAISource({name,text,size},current=''){
 if(typeof name!=='string'||!/\.(txt|md)$/i.test(name))throw Error('Scegli un file TXT o Markdown (.md).');
 if(typeof text!=='string'||!text.trim())throw Error('Il file è vuoto.');
 if(!Number.isFinite(size)||size<0||size>AI_SOURCE_BYTES||new TextEncoder().encode(text).length>AI_SOURCE_BYTES)throw Error('File troppo grande: massimo 64 KB.');
 if(text.includes('\u0000')||text.includes('\uFFFD'))throw Error('Il file non è testo UTF-8 leggibile. Esportalo di nuovo come TXT UTF-8.');
 if(typeof current!=='string')throw Error('Brief non valido.');
 const content=text.replace(/^\uFEFF/,'').trim();
 const lines=content.split(/\s+/);
 const linkOnly=lines.every(line=>{try{const url=new URL(line);return ['http:','https:'].includes(url.protocol)&&!url.username&&!url.password;}catch{return false;}});
 const filename=name.replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,160);
 const label=linkOnly?'Riferimenti esterni — contenuto non acquisito':'Materiale di riferimento fornito — da verificare';
 const block=label+'\nFile: '+filename+'\n'+content;
 const brief=(current.trim()?current.trimEnd()+'\n\n':'')+block;
 if(brief.length>AI_BRIEF_LIMIT)throw Error('Il brief supererebbe 12.000 caratteri. Riduci il testo o importa un estratto; nessun contenuto è stato tagliato.');
 return {brief,linkOnly};
}
