import {task,addChild,validateGoals} from './model.js';

export const partnershipSectors={football:'Calcio',basketball:'Basket',commerce:'Venditori e commercio',technology:'Tecnologia',culture:'Cultura e università'};
export function createPartnershipPlan(input={}){
 const clean=(value,max,label)=>{if(typeof value!=='string'||!value.trim()||value.trim().length>max||/[\u0000-\u001f\u007f]/.test(value))throw Error('Controlla '+label+'.');return value.trim();};
 const organization=clean(input.organization,100,'il nome dell’organizzazione'),objective=clean(input.objective,300,'il risultato proposto');
 if(!Object.hasOwn(partnershipSectors,input.sector))throw Error('Scegli un settore.');
 const root=task('Collaborazione · '+organization);
 root.criteria='Ambito: '+partnershipSectors[input.sector]+'. Risultato proposto: '+objective+'. Accordo, autorizzazioni e risultati documentati; stati registrati dall’utente, non certificati da SEVA.';
 const stages=[
  ['1 · Identificare il referente','Organizzazione e canale ufficiale documentati con URL e data.',[
   ['Verificare la fonte primaria','Registrare il sito ufficiale e il reparto pertinente. Un collegamento o accesso OAuth non dimostra una partnership.'],
   ['Definire un bisogno comune','Descrivere il pubblico, il problema e il contributo concreto di ciascuna parte.']]],
  ['2 · Preparare e seguire la proposta','Conservare proposta, destinatario, data di invio effettivo e risposta ricevuta.',[
   ['Scrivere un pilota circoscritto','Definire attività, durata, responsabilità, costi proposti e criterio di successo. Distinguere obiettivi e risultati già osservati.'],
   ['Registrare invio e risposta','Inviare dal canale scelto e annotare la ricevuta reale. Una bozza, il silenzio o un invio non equivalgono ad accettazione.']]],
  ['3 · Verificare l’accordo','Riferimento a conferma della controparte, soggetti, perimetro, durata e autorizzazioni.',[
   ['Confermare termini e ruoli','Registrare il riferimento a un accordo verificabile. Non caricare credenziali o documenti riservati nel piano.'],
   ['Documentare i diritti concessi','Verificare separatamente uso di nomi, marchi, contenuti, immagini e distribuzione. Annotare limiti e scadenze prima della pubblicazione.']]],
  ['4 · Misurare e decidere','Esito del pilota con periodo, fonte e decisione motivata prima di ampliare.',[
   ['Misurare utilizzo e servizio','Registrare partecipanti volontari, utenti attivi unici nel periodo e completamenti. Per i venditori: cataloghi, ordini confermati, consegne e resi. Dati mancanti = non misurati.'],
   ['Decidere il prossimo passo','Confrontare risultato e criterio. Annotare costi, problemi, decisione proseguire/modificare/fermare e responsabile. Milioni di utenti restano un obiettivo fino a misurazione.']]]
 ];
 for(const [title,criteria,steps] of stages){const stage=addChild(root,title);stage.criteria=criteria;for(const [name,criterion] of steps)addChild(stage,name).criteria=criterion;}
 validateGoals([root]);return root;
}
