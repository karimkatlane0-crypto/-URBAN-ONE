export function uid(){return Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');}
export const statuses=['Da fare','In corso','Bloccato','Verificato'];
export function task(title,depth=0){return {id:uid(),title,depth,criteria:'',evidence:'',status:'Da fare',children:[]};}
export function addChild(parent,title){if(parent.depth>=4)throw Error('Massimo quattro sotto-livelli: cinque livelli totali');const child=task(title,parent.depth+1);parent.children.push(child);return child;}
export function setStatus(node,status){if(!statuses.includes(status))throw Error('Stato non valido');if(status==='Verificato'&&(!node.criteria.trim()||!node.evidence.trim()||node.children.some(c=>c.status!=='Verificato')))throw Error('Servono criterio, evidenza e tutti i sotto-obiettivi verificati');node.status=status;}
export function brief(node){return ['SEVA · Compito per AI','Obiettivo: '+node.title,'Livello: '+node.depth,'Criterio di accettazione: '+(node.criteria||'DA DEFINIRE'),'Evidenze disponibili: '+(node.evidence||'Nessuna'),'Stato: '+node.status,'Vincoli: non inventare fonti, prezzi, transazioni o risultati. Non trasmettere contatti o foto senza consenso. Nessun pagamento, messaggio o acquisto esterno senza autorizzazione specifica.','Risultato richiesto: esecuzione documentata; fonti e data; verifica del criterio; blocchi e prossimo passo.'].join('\n');}
export function economics(price,commission,rewardShare,cost){for(const n of [price,commission,rewardShare,cost])if(!Number.isFinite(n)||n<0)throw Error('Valori non validi');if(commission>100||rewardShare>100)throw Error('Percentuali tra 0 e 100');const gross=Math.round(price*commission)/100;const available=Math.max(0,gross-cost);const reward=Math.round(available*rewardShare)/100;return {gross,reward,margin:available-reward,breakEven:reward>0?Math.ceil(price/reward):null};}
export function validateGoals(goals){
 if(!Array.isArray(goals)||goals.length>100)throw Error('Piano troppo grande');
 const ids=new Set();let total=0;
 function check(n,d){
  if(++total>2000||!n||d>4||n.depth!==d||typeof n.id!=='string'||!n.id||n.id.length>100||ids.has(n.id)||typeof n.title!=='string'||!n.title.trim()||n.title.length>2000||typeof n.criteria!=='string'||n.criteria.length>12000||typeof n.evidence!=='string'||n.evidence.length>12000||!statuses.includes(n.status)||!Array.isArray(n.children)||Object.keys(n).some(k=>!['id','title','depth','criteria','evidence','status','children'].includes(k)))throw Error('Obiettivo non valido');
  ids.add(n.id);n.children.forEach(c=>check(c,d+1));
  if(n.status==='Verificato'&&(!n.criteria.trim()||!n.evidence.trim()||n.children.some(c=>c.status!=='Verificato')))throw Error('Verifica senza evidenze');
 }
 goals.forEach(n=>check(n,0));return goals;
}
export function validateState(s){if(!s||s.version!==1||!Array.isArray(s.goals)||!Array.isArray(s.intents)||!Array.isArray(s.products)||!Array.isArray(s.audit))throw Error('Formato piano non valido');if(s.intents.length>500||s.products.length>500)throw Error('Piano troppo grande');validateGoals(s.goals);for(const i of s.intents){if(typeof i.id!=='string'||typeof i.title!=='string'||typeof i.description!=='string'||!Number.isFinite(i.budget)||i.budget<0||typeof i.consent!=='boolean'||typeof i.created!=='string'||typeof i.mode!=='string'||typeof i.contact!=='string'||typeof i.university!=='string'||(i.photo&&!/^data:image\/(png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(i.photo)))throw Error('Lastra non valida');}for(const p of s.products){if(typeof p.id!=='string'||typeof p.name!=='string'||typeof p.description!=='string'||!Number.isFinite(p.price)||p.price<0||typeof p.sponsored!=='boolean'||typeof p.url!=='string')throw Error('Prodotto non valido');if(p.url&&!/^https:\/\//.test(p.url))throw Error('Link prodotto non valido');}return s;}
export function csv(rows){return rows.map(r=>r.map(v=>'"'+String(v??'').replace(/^[\s\uFEFF]*[=+@\-]/,"'$&").replaceAll('"','""')+'"').join(',')).join('\r\n');}
export function flatten(nodes){return nodes.flatMap(n=>[n,...flatten(n.children)]);}

export function goalCanonical(value){if(value===undefined)return 'undefined';if(Array.isArray(value))return '['+value.map(goalCanonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+goalCanonical(value[k])).join(',')+'}';return JSON.stringify(value);}
export function mergeGoalTrees(base,local,remote){
 const b=new Map(base.map(n=>[n.id,n])),l=new Map(local.map(n=>[n.id,n])),r=new Map(remote.map(n=>[n.id,n]));const goals=[],conflicts=[];
 for(const id of new Set([...l.keys(),...r.keys(),...b.keys()])){const bv=b.get(id),lv=l.get(id),rv=r.get(id);let value;
  if(goalCanonical(lv)===goalCanonical(rv))value=lv;else if(goalCanonical(lv)===goalCanonical(bv))value=rv;else if(goalCanonical(rv)===goalCanonical(bv))value=lv;else{conflicts.push({id,local:lv,remote:rv});value=lv;}
  if(value!==undefined)goals.push(structuredClone(value));
 }return {goals,conflicts};
}
export function walkGoalTrees(goals,{strategy='depth',direction='forward'}={}){
 validateGoals(goals);if(!['depth','breadth'].includes(strategy)||!['forward','backward'].includes(direction))throw Error('Ordine non valido');
 const pending=[...goals],result=[];while(pending.length){const n=pending.shift();result.push(n);if(strategy==='depth')pending.unshift(...n.children);else pending.push(...n.children);}return direction==='backward'?result.reverse():result;
}
