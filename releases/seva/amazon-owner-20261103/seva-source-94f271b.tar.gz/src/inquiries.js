import {requestIdentity} from './identity.js';
const inquiryReply=(body,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const inquiryError=(message,status=400)=>Object.assign(Error(message),{inquiryError:true,status});
function inquiryInput(body){
 if(!body||Array.isArray(body)||Object.keys(body).some(k=>!['id','category','name','message','consent'].includes(k))||body.consent!==true||typeof body.id!=='string'||!/^[-A-Za-z0-9]{16,80}$/.test(body.id)||!['Community','Business','Assistenza'].includes(body.category)||typeof body.name!=='string'||!body.name.trim()||body.name.length>120||typeof body.message!=='string'||!body.message.trim()||body.message.length>4000)throw inquiryError('Controlla nome, messaggio e consenso.');
 return {id:body.id,category:body.category,name:body.name.trim(),message:body.message.trim()};
}
export async function handleInquiries(request,env){
 const user=requestIdentity(request);if(!user)return inquiryReply({error:'Accedi con ChatGPT per contattare SEVA.'},401);
 if(!env.DB)return inquiryReply({error:'Servizio temporaneamente non disponibile.'},503);
 try{
  const fields='id,category,name,message,response,status,revision,created_at,updated_at';
  if(request.method==='GET'){
   const statement=user.isOwner?env.DB.prepare('SELECT '+fields+' FROM seva_inquiries ORDER BY updated_at DESC LIMIT 200'):env.DB.prepare('SELECT '+fields+' FROM seva_inquiries WHERE owner_id=? ORDER BY updated_at DESC LIMIT 50').bind(user.id);
   return inquiryReply({items:(await statement.all()).results,isOwner:user.isOwner});
  }
  if(!['POST','PATCH','DELETE'].includes(request.method))return inquiryReply({error:'Metodo non consentito.'},405);
  if(request.headers.get('origin')!==new URL(request.url).origin||request.headers.get('sec-fetch-site')==='cross-site')return inquiryReply({error:'Origine non autorizzata.'},403);
  if(!request.headers.get('content-type')?.startsWith('application/json'))return inquiryReply({error:'È richiesto JSON.'},415);
  const reader=request.body?.getReader();if(!reader)throw inquiryError('Richiesta vuota.');let size=0;const chunks=[];
  for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>24000){await reader.cancel();throw inquiryError('Messaggio troppo lungo.',413);}chunks.push(value);}
  const bytes=new Uint8Array(size);let at=0;for(const c of chunks){bytes.set(c,at);at+=c.length;}let body;try{body=JSON.parse(new TextDecoder().decode(bytes));}catch{throw inquiryError('JSON non valido.');}
  if(request.method==='POST'){
   const data=inquiryInput(body);
   const existing=await env.DB.prepare('SELECT owner_id,category,name,message FROM seva_inquiries WHERE id=?').bind(data.id).first();
   if(existing){if(existing.owner_id!==user.id||existing.category!==data.category||existing.name!==data.name||existing.message!==data.message)throw inquiryError('Richiesta già presente con contenuto diverso.',409);return inquiryReply({saved:true,id:data.id});}
   const now=new Date().toISOString();
   const result=await env.DB.prepare("INSERT OR IGNORE INTO seva_inquiries(id,owner_id,category,name,message,response,status,revision,created_at,updated_at) SELECT ?,?,?,?,?,?,'Aperta',1,?,? WHERE (SELECT COUNT(*) FROM seva_inquiries WHERE owner_id=?)<50").bind(data.id,user.id,data.category,data.name,data.message,'',now,now,user.id).run();
   if(result.meta.changes!==1)throw inquiryError('Limite richieste raggiunto o invio concorrente: aggiorna e riprova.',409);
   return inquiryReply({saved:true,id:data.id},201);
  }
  if(!body||typeof body.id!=='string'||body.id.length>80||!Number.isSafeInteger(body.revision)||body.revision<1)throw inquiryError('Riferimento non valido.');
  if(request.method==='DELETE'){
   if(Object.keys(body).some(k=>!['id','revision'].includes(k)))throw inquiryError('Campi non validi.');
   const r=await env.DB.prepare('DELETE FROM seva_inquiries WHERE id=? AND owner_id=? AND revision=?').bind(body.id,user.id,body.revision).run();
   if(r.meta.changes!==1)throw inquiryError('Richiesta modificata o non disponibile: aggiorna.',409);
   return inquiryReply({deleted:true});
  }
  if(!user.isOwner)throw inquiryError('Operazione riservata al titolare.',403);
  if(Object.keys(body).some(k=>!['id','revision','response','status'].includes(k))||typeof body.response!=='string'||!body.response.trim()||body.response.length>4000||!['In corso','Risposta disponibile'].includes(body.status))throw inquiryError('Inserisci una risposta valida.');
  const r=await env.DB.prepare('UPDATE seva_inquiries SET response=?,status=?,revision=revision+1,updated_at=? WHERE id=? AND revision=?').bind(body.response.trim(),body.status,new Date().toISOString(),body.id,body.revision).run();
  if(r.meta.changes!==1)throw inquiryError('Richiesta modificata: aggiorna.',409);
  return inquiryReply({saved:true});
 }catch(e){return inquiryReply({error:e.inquiryError?e.message:'Servizio temporaneamente non disponibile.'},e.inquiryError?e.status:503);}
}
