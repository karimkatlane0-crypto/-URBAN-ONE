export function clearLocalWorkspace(storage,session){
 if(!session||!/^[a-f0-9]{64}$/.test(session.scope))throw Error('Sessione non valida: ricarica la pagina.');
 const keys=['seva.workspace.v2.','seva.goal-relay.v2.','seva.goal-relay.conflict-backup.'].map(prefix=>prefix+session.scope);
 if(session.isOwner===true)keys.push('seva.workspace.v1');
 for(const key of keys)storage.removeItem(key);
 return keys.length;
}
