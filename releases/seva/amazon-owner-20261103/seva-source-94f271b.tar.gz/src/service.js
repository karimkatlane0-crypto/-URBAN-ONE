export const ticketStatuses=['Aperta','In corso','In attesa','Risolta'];
export function validateTickets(tickets){
 if(!Array.isArray(tickets)||tickets.length>200)throw Error('Massimo 200 richieste');
 const ids=new Set();
 for(const t of tickets){
  if(!t||Object.keys(t).some(k=>!['id','title','category','description','status','resolution','createdAt'].includes(k))||typeof t.id!=='string'||!/^[-a-zA-Z0-9]{1,80}$/.test(t.id)||ids.has(t.id)||typeof t.title!=='string'||!t.title.trim()||t.title.length>200||typeof t.description!=='string'||t.description.length>3000||typeof t.resolution!=='string'||t.resolution.length>3000||!ticketStatuses.includes(t.status)||!['Prodotto','Servizio','Accessibilità','Suggerimento'].includes(t.category)||typeof t.createdAt!=='string'||!Number.isFinite(Date.parse(t.createdAt))||t.createdAt.length>40)throw Error('Richiesta non valida');
  if(t.status==='Risolta'&&!t.resolution.trim())throw Error('Descrivi la soluzione e la prova prima di chiudere la richiesta');
  ids.add(t.id);
 }
 return tickets;
}
export function starterPlan(kind){
 const templates={
  persona:{title:'Il mio prossimo passo',criteria:'Raggiungere un risultato utile entro la scadenza scelta, documentando costi e beneficio',steps:[['Definire il bisogno','Scrivere risultato atteso, budget e data'],['Valutare le alternative','Confrontare almeno due opzioni con fonte, costi e limiti'],['Compiere il prossimo passo','Registrare l’azione effettivamente svolta'],['Misurare il beneficio','Confrontare atteso e ottenuto con una prova datata']]},
  negozio:{title:'Un negozio che crea valore',criteria:'Un cliente pilota completa il percorso e conferma il beneficio; costi e criticità sono documentati',steps:[['Ascoltare un bisogno reale','Registrare il bisogno con consenso, senza dati superflui'],['Rendere chiara l’offerta','Descrivere prodotto, prezzo totale, disponibilità e fonte'],['Provare il servizio','Eseguire un percorso completo con un cliente consenziente'],['Risolvere e migliorare','Registrare le segnalazioni e verificare la soluzione con il cliente']]},
  servizio:{title:'Un servizio clienti migliore',criteria:'Una richiesta pilota viene risolta con evidenza e conferma del risultato',steps:[['Comprendere il problema','Descrivere problema, risultato atteso e contesto minimo'],['Definire il prossimo intervento','Indicare responsabile e tempo di risposta concordato'],['Verificare la soluzione','Ripetere il percorso che causava il problema e documentare l’esito'],['Prevenire la ricorrenza','Aggiornare istruzioni o prodotto e misurare le ricorrenze']]}
 };
 const template=templates[kind];if(!template)throw Error('Percorso non disponibile');
 // Kept independent from the UI: the caller assigns the model's IDs and depth.
 return structuredClone(template);
}
