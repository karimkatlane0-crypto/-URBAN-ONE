import {validateGoals,goalCanonical} from './model.js';
const goalReply=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const goalFailure=(code,status)=>Object.assign(Error(code),{status,goalRequestError:true});
const goalSnapshot=(row,owner)=>({ownerId:owner,revision:row?.revision||0,goals:row?JSON.parse(row.goals_json):[],updatedAt:row?.updated_at||null});
const goalDigest=async text=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),n=>n.toString(16).padStart(2,'0')).join('');
export async function handleGoals(request,env){
 const owner=request.headers.get('oai-authenticated-user-id');
 if(!owner)return goalReply({error:'Accedi con ChatGPT per sincronizzare gli obiettivi.',code:'sign_in_required'},401);
 if(!['GET','POST'].includes(request.method))return goalReply({error:'Metodo non consentito'},405);
 if(!env.DB)return goalReply({error:'Database non disponibile',code:'storage_unavailable'},503);
 try{
  const read=()=>env.DB.prepare('SELECT revision,goals_json,updated_at,operation_id,payload_hash FROM seva_goal_workspaces WHERE owner_id=?').bind(owner).first();
  if(request.method==='GET')return goalReply(goalSnapshot(await read(),owner));
  if(request.headers.get('origin')!==new URL(request.url).origin||request.headers.get('sec-fetch-site')==='cross-site')throw goalFailure('origin_not_allowed',403);
  if(!request.headers.get('content-type')?.startsWith('application/json'))throw goalFailure('json_required',415);
  const reader=request.body?.getReader();if(!reader)throw goalFailure('invalid_request',400);
  const chunks=[];let size=0;
  for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>540000){await reader.cancel();throw goalFailure('payload_too_large',413);}chunks.push(value);}
  const bytes=new Uint8Array(size);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.length;}
  let body;try{body=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{throw goalFailure('invalid_json',400);}
  if(!body||Array.isArray(body)||Object.keys(body).some(k=>!['revision','goals','operationId','consent'].includes(k))||body.consent!==true||!Number.isSafeInteger(body.revision)||body.revision<0||typeof body.operationId!=='string'||!/^[-A-Za-z0-9]{1,80}$/.test(body.operationId))throw goalFailure('invalid_request',400);
  try{validateGoals(body.goals);}catch{throw goalFailure('invalid_goals',400);}
  const serialized=JSON.stringify(body.goals);
  if(new TextEncoder().encode(serialized).byteLength>524288)throw goalFailure('payload_too_large',413);
  const hash=await goalDigest(goalCanonical(body.goals)),current=await read();
  if(current?.operation_id===body.operationId){
   if(current.payload_hash!==hash)return goalReply({error:'Identificativo operazione riutilizzato con dati diversi.',code:'operation_conflict',current:goalSnapshot(current,owner)},409);
   return goalReply(goalSnapshot(current,owner));
  }
  if((current?.revision||0)!==body.revision)return goalReply({error:'Il cloud è cambiato. Confronta le versioni.',code:'revision_conflict',current:goalSnapshot(current,owner)},409);
  const timestamp=new Date().toISOString();
  const result=current?
   await env.DB.prepare('UPDATE seva_goal_workspaces SET revision=revision+1,goals_json=?,updated_at=?,operation_id=?,payload_hash=? WHERE owner_id=? AND revision=?').bind(serialized,timestamp,body.operationId,hash,owner,body.revision).run():
   await env.DB.prepare('INSERT OR IGNORE INTO seva_goal_workspaces(owner_id,revision,goals_json,updated_at,operation_id,payload_hash) VALUES (?,1,?,?,?,?)').bind(owner,serialized,timestamp,body.operationId,hash).run();
  const latest=await read();
  return result.meta.changes===1?goalReply(goalSnapshot(latest,owner)):goalReply({error:'Il cloud è cambiato. Confronta le versioni.',code:'revision_conflict',current:goalSnapshot(latest,owner)},409);
 }catch(error){return goalReply({error:error.goalRequestError?'Richiesta obiettivi non completata.':'Sincronizzazione temporaneamente non disponibile.',code:error.goalRequestError?error.message:'storage_unavailable'},error.goalRequestError?error.status:503);}
}
