import {validateTickets} from './service.js';
import {goalCanonical} from './model.js';
const serviceReply=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const serviceFailure=(code,status)=>Object.assign(Error(code),{status,serviceRequestError:true});
const serviceSnapshot=(row,owner)=>({ownerId:owner,revision:row?.revision||0,tickets:row?JSON.parse(row.tickets_json):[],updatedAt:row?.updated_at||null});
const serviceDigest=async text=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),n=>n.toString(16).padStart(2,'0')).join('');
export async function handleService(request,env){
 const owner=request.headers.get('oai-authenticated-user-id');
 if(!owner)return serviceReply({error:'Accedi con ChatGPT per aprire il registro assistenza.',code:'sign_in_required'},401);
 if(!['GET','POST'].includes(request.method))return serviceReply({error:'Metodo non consentito'},405);
 if(!env.DB)return serviceReply({error:'Database non disponibile',code:'storage_unavailable'},503);
 try{
  const read=()=>env.DB.prepare('SELECT revision,tickets_json,updated_at,operation_id,payload_hash FROM seva_service_workspaces WHERE owner_id=?').bind(owner).first();
  if(request.method==='GET')return serviceReply(serviceSnapshot(await read(),owner));
  if(request.headers.get('origin')!==new URL(request.url).origin||request.headers.get('sec-fetch-site')==='cross-site')throw serviceFailure('origin_not_allowed',403);
  if(!request.headers.get('content-type')?.startsWith('application/json'))throw serviceFailure('json_required',415);
  const reader=request.body?.getReader();if(!reader)throw serviceFailure('invalid_request',400);
  const chunks=[];let size=0;
  for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>280000){await reader.cancel();throw serviceFailure('payload_too_large',413);}chunks.push(value);}
  const bytes=new Uint8Array(size);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.length;}
  let body;try{body=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{throw serviceFailure('invalid_json',400);}
  if(!body||Array.isArray(body)||Object.keys(body).some(k=>!['revision','tickets','operationId','consent'].includes(k))||body.consent!==true||!Number.isSafeInteger(body.revision)||body.revision<0||typeof body.operationId!=='string'||!/^[-A-Za-z0-9]{1,80}$/.test(body.operationId))throw serviceFailure('invalid_request',400);
  try{validateTickets(body.tickets);}catch{throw serviceFailure('invalid_tickets',400);}
  const serialized=JSON.stringify(body.tickets);
  if(new TextEncoder().encode(serialized).byteLength>262144)throw serviceFailure('payload_too_large',413);
  const hash=await serviceDigest(goalCanonical(body.tickets)),current=await read();
  if(current?.operation_id===body.operationId){
   if(current.payload_hash!==hash)return serviceReply({error:'Identificativo operazione riutilizzato con dati diversi.',code:'operation_conflict',current:serviceSnapshot(current,owner)},409);
   return serviceReply(serviceSnapshot(current,owner));
  }
  if((current?.revision||0)!==body.revision)return serviceReply({error:'Il cloud è cambiato. Confronta le versioni.',code:'revision_conflict',current:serviceSnapshot(current,owner)},409);
  const timestamp=new Date().toISOString();
  const result=current?
   await env.DB.prepare('UPDATE seva_service_workspaces SET revision=revision+1,tickets_json=?,updated_at=?,operation_id=?,payload_hash=? WHERE owner_id=? AND revision=?').bind(serialized,timestamp,body.operationId,hash,owner,body.revision).run():
   await env.DB.prepare('INSERT OR IGNORE INTO seva_service_workspaces(owner_id,revision,tickets_json,updated_at,operation_id,payload_hash) VALUES (?,1,?,?,?,?)').bind(owner,serialized,timestamp,body.operationId,hash).run();
  const latest=await read();
  return result.meta.changes===1?serviceReply(serviceSnapshot(latest,owner)):serviceReply({error:'Il cloud è cambiato. Confronta le versioni.',code:'revision_conflict',current:serviceSnapshot(latest,owner)},409);
 }catch(error){return serviceReply({error:error.serviceRequestError?'Richiesta assistenza non valida.':'Registro assistenza temporaneamente non disponibile.',code:error.serviceRequestError?error.message:'storage_unavailable'},error.serviceRequestError?error.status:503);}
}
