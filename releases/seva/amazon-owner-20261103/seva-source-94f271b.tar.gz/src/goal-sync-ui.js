const GOAL_SYNC_KEY='seva.goal-relay.v2.'+window.SEVA_SESSION.scope;
let goalSyncMeta=null,goalSyncBusy=false,goalSyncPending=null,goalSyncConsent=false;
try{const raw=localStorage.getItem(GOAL_SYNC_KEY);if(raw){const m=JSON.parse(raw);validateGoals(m.base);if(typeof m.ownerId==='string'&&Number.isSafeInteger(m.revision)&&m.revision>=0)goalSyncMeta=m;}}catch{}
function goalSyncHTML(){return `<section class="panel"><div class="row between"><h2>DBRELAY · Obiettivi nel cloud privato</h2><button type="button" id="syncGoals">Sincronizza obiettivi</button></div><p>Unisci modifiche a obiettivi distinti e confronta i conflitti prima di scegliere. Gli obiettivi contengono anche le evidenze che hai scritto.</p><label class="check"><input type="checkbox" id="goalSyncConsent" ${goalSyncConsent?'checked':''}><span>Scelgo di sincronizzare gli obiettivi con il mio account. Foto, contatti, prodotti e registro locale restano nel browser.</span></label><p id="goalSyncStatus" role="status" aria-live="polite">${goalSyncMeta?.lastSync?'Ultima sincronizzazione: '+E(new Date(goalSyncMeta.lastSync).toLocaleString('it-IT')):'Il cloud si collega quando scegli Sincronizza obiettivi.'}</p><p class="small">La sincronizzazione richiede connessione e accesso ChatGPT. Le modifiche offline restano locali fino al prossimo invio.</p></section>`;}
async function goalSyncAPI(method='GET',body){
 const response=await sevaFetch('/api/goals',{method,credentials:'same-origin',cache:'no-store',redirect:'error',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(15000)});
 const data=await response.json().catch(()=>({error:'Risposta non leggibile'}));
 if(!response.ok){const error=Error(data.error||'Sincronizzazione non completata');error.status=response.status;error.code=data.code;throw error;}
 validateGoals(data.goals);if(typeof data.ownerId!=='string'||!Number.isSafeInteger(data.revision)||data.revision<0)throw Error('Risposta cloud non valida');return data;
}
function goalSyncMessage(text){const el=$('#goalSyncStatus');if(el)el.textContent=text;}
function goalEditorValues(){return [...document.querySelectorAll('[data-task]')].map(card=>({id:card.dataset.task,values:[...card.querySelector('.task-fields').children].filter(label=>label.tagName==='LABEL').map(label=>label.querySelector('input,textarea,select')?.value??'')}));}
function captureGoalEditors(){
 const nodes=new Map(flatten(state.goals).map(node=>[node.id,node]));let changed=false;
 for(const editor of goalEditorValues()){
  const node=nodes.get(editor.id);if(!node)continue;
  if(goalCanonical(editor.values)!==goalCanonical([node.title,node.criteria,node.evidence,node.status])){capture(editor.id);changed=true;}
 }
 if(changed&&!save('Campi degli obiettivi salvati per la sincronizzazione'))throw Error('Memoria locale piena: esporta il piano prima di sincronizzare.');
}
function goalSyncReview(pending){
 goalSyncPending=pending;
 modal(`<h2>Confronta gli obiettivi modificati</h2><p>Le modifiche indipendenti sono già unite. Scegli una versione per ogni obiettivo in conflitto; entrambe le copie restano disponibili fino alla scelta.</p><form id="goalConflictForm">${pending.conflicts.map((c,i)=>`<fieldset style="margin:14px 0"><legend>${E(c.local?.title||c.remote?.title||c.id)}</legend><label class="check"><input type="radio" name="root-${i}" value="local" required>Questo browser · ${c.local?'obiettivo presente':'eliminato'}</label><label class="check"><input type="radio" name="root-${i}" value="remote" required>Cloud · ${c.remote?'obiettivo presente':'eliminato'}</label><details><summary>Leggi entrambe le versioni</summary><pre>${E(JSON.stringify({browser:c.local??null,cloud:c.remote??null},null,2))}</pre></details></fieldset>`).join('')}<div class="row"><button type="button" id="exportGoalConflict">Esporta entrambe le copie</button><button class="primary">Conserva le scelte</button></div></form>`);
 $('#exportGoalConflict').onclick=()=>download('SEVA-confronto-obiettivi.json',JSON.stringify({browser:pending.local,cloud:pending.remote.goals},null,2));
 $('#goalConflictForm').onsubmit=async event=>{
  event.preventDefault();
  if(goalCanonical(state.goals)!==goalCanonical(pending.local)){$('#dialog').close();goalSyncMessage('Il piano locale è cambiato: sincronizza di nuovo prima di scegliere.');return;}
  const fields=new FormData(event.target),chosen=new Map(pending.goals.map(n=>[n.id,n]));
  for(const [i,c]of pending.conflicts.entries()){const value=c[fields.get('root-'+i)==='remote'?'remote':'local'];if(value)chosen.set(c.id,value);else chosen.delete(c.id);}
  try{
   localStorage.setItem('seva.goal-relay.conflict-backup.'+window.SEVA_SESSION.scope,JSON.stringify({browser:pending.local,cloud:pending.remote.goals,savedAt:new Date().toISOString()}));
   goalSyncMeta={ownerId:pending.remote.ownerId,revision:pending.remote.revision,base:pending.remote.goals,lastSync:goalSyncMeta?.lastSync||null};
   localStorage.setItem(GOAL_SYNC_KEY,JSON.stringify(goalSyncMeta));
   state.goals=[...chosen.values()];if(!save('Conflitto obiettivi risolto'))throw Error('Esporta il piano prima di proseguire: memoria locale piena.');
   goalSyncPending=null;$('#dialog').close();render();await synchronizeGoals();
  }catch(error){goalSyncMessage(error.message);}
 };
}
async function synchronizeGoals(){
 if(goalSyncBusy)return;
 if(!goalSyncConsent){goalSyncMessage('Conferma prima la scelta di salvare gli obiettivi nel cloud privato.');return;}
 if(!navigator.onLine){goalSyncMessage('Sei offline. I dati restano locali: riprova quando la connessione torna disponibile.');return;}
 goalSyncBusy=true;goalSyncMessage('Confronto con il cloud…');const button=$('#syncGoals');if(button)button.disabled=true;
 try{
  const remote=await goalSyncAPI();
  if(page!=='goals')return;
  if(goalSyncMeta&&goalSyncMeta.ownerId!==remote.ownerId)throw Error('Il piano locale è collegato a un altro account. Esporta una copia e accedi con l’account corretto.');
  captureGoalEditors();const editorAtStart=JSON.stringify(goalEditorValues());
  const local=structuredClone(state.goals),base=goalSyncMeta?.base||[];
  const merged=mergeGoalTrees(base,local,remote.goals);
  if(goalSyncMeta&&remote.revision<goalSyncMeta.revision){
   merged.conflicts=[...new Set([...local.map(n=>n.id),...remote.goals.map(n=>n.id)])].map(id=>({id,local:local.find(n=>n.id===id),remote:remote.goals.find(n=>n.id===id)}));
  }
  if(merged.conflicts.length){goalSyncReview({...merged,local,remote});goalSyncMessage('Due versioni da confrontare. Nessun salvataggio cloud eseguito.');return;}
  const accepted=goalCanonical(merged.goals)===goalCanonical(remote.goals)?remote:await goalSyncAPI('POST',{revision:remote.revision,goals:merged.goals,operationId:crypto.randomUUID(),consent:true});
  // A cloud acknowledgement must not redraw over edits still open in a form,
  // or a different page. Keep the old merge base until those edits are saved.
  if(page!=='goals'||JSON.stringify(goalEditorValues())!==editorAtStart){goalSyncMessage('Il cloud ha ricevuto la versione inviata, ma i campi aperti sono stati modificati. Salva i campi e sincronizza ancora per confrontare le versioni.');return;}
  const current=structuredClone(state.goals),after=mergeGoalTrees(local,current,accepted.goals);
  if(after.conflicts.length){goalSyncReview({...after,local:current,remote:accepted});goalSyncMessage('Una modifica durante l’invio richiede un confronto.');return;}
  const meta={ownerId:accepted.ownerId,revision:accepted.revision,base:accepted.goals,lastSync:new Date().toISOString()};
  localStorage.setItem(GOAL_SYNC_KEY,JSON.stringify(meta));goalSyncMeta=meta;
  state.goals=after.goals;if(!save('Obiettivi sincronizzati'))throw Error('La copia cloud è salvata; esporta quella locale perché la memoria del browser è piena.');
  const further=goalCanonical(state.goals)!==goalCanonical(accepted.goals);render();
  goalSyncMessage(further?'Modifiche ulteriori sul browser: sincronizza ancora.':'Sincronizzato · revisione '+accepted.revision+' · '+new Date(meta.lastSync).toLocaleString('it-IT'));
 }catch(error){goalSyncMessage(error.status===401?'Accedi con ChatGPT per sincronizzare.':error.status===409?'Il cloud è cambiato durante l’invio. Le modifiche locali restano disponibili: sincronizza di nuovo.':error.message||'Connessione non disponibile. Riprova senza chiudere il piano.');}
 finally{goalSyncBusy=false;const b=$('#syncGoals');if(b)b.disabled=false;}
}
function bindGoalSync(){
 const consent=$('#goalSyncConsent');if(!consent)return;
 consent.onchange=()=>{goalSyncConsent=consent.checked;};$('#syncGoals').onclick=synchronizeGoals;
}
function goalTraversalHTML(){return `<section class="panel"><h2>Esplora il piano</h2><div class="two"><div><label for="goalWalkStrategy">Ordine</label><select id="goalWalkStrategy"><option value="depth">Un ramo alla volta · profondità</option><option value="breadth">Per livelli · ampiezza</option></select></div><div><label for="goalWalkDirection">Direzione</label><select id="goalWalkDirection"><option value="forward">Obiettivo → dettagli</option><option value="backward">Dettagli → obiettivo</option></select></div></div><p id="goalWalkCount" role="status"></p><div style="max-height:360px;overflow:auto"><table class="status-table"><thead><tr><th>LIVELLO</th><th>OBIETTIVO</th><th>STATO</th></tr></thead><tbody id="goalWalkRows"></tbody></table></div><p class="small">La vista ordinata mostra fino a 100 nodi; il piano completo e l’esportazione rimangono disponibili sotto.</p></section>`;}
function bindGoalTraversal(){
 const renderWalk=()=>{const nodes=walkGoalTrees(state.goals,{strategy:$('#goalWalkStrategy').value,direction:$('#goalWalkDirection').value});$('#goalWalkCount').textContent=`${nodes.length} nodi nel piano · cinque livelli disponibili`;$('#goalWalkRows').innerHTML=nodes.slice(0,100).map(n=>`<tr><td>L${n.depth}</td><td>${E(n.title)}</td><td>${E(n.status)}</td></tr>`).join('');};
 $('#goalWalkStrategy').onchange=$('#goalWalkDirection').onchange=renderWalk;renderWalk();
}
