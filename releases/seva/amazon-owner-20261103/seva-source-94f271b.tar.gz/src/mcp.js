import {growthScenario,conversionInterval} from './growth.js';
import {paymentReadiness} from './payment-readiness.js';
const metricProperties=Object.fromEntries(['monthlySubscribers','subscriptionPrice','subscriptionVatRate','subscriptionRefundRate','subscriptionCost','visits','targetActiveUsers','signupRate','activationRate','purchaseRate','ordersPerBuyer','aov','refundRate','takeRate','creatorRate','processingRate','processingFixed','variableCostPerOrder','marketingCash','hours','hourCost','fixedCost','extraPaymentCosts'].map(k=>[k,{type:'number',minimum:0}]));
export const SEVA_MCP_TOOLS=[
 {name:'seva_growth_scenario',title:'SEVA · Budget e margini',description:'Calcola uno scenario illustrativo di acquisizione e commercio con ipotesi esplicite. Abbonamenti mensili ipotizzati, GMV, ricavi SEVA combinati, quota creator, costi, CAC e pareggio. Non legge analytics, non promette risultati e non esegue pagamenti.',inputSchema:{type:'object',properties:{...metricProperties,feePayer:{type:'string',enum:['platform','seller']}},additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,idempotentHint:true,openWorldHint:false}},
 {name:'seva_conversion_interval',title:'SEVA · Tasso e intervallo statistico',description:'Calcola tasso e intervallo Wilson al 95% da conteggi aggregati forniti dall’utente. Zero osservazioni significa non misurato. Non acquisisce o trasmette dati personali.',inputSchema:{type:'object',properties:{trials:{type:'integer',minimum:0,maximum:1000000000},successes:{type:'integer',minimum:0}},required:['trials','successes'],additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,idempotentHint:true,openWorldHint:false}},
 {name:'seva_payment_readiness',title:'SEVA · Stato del servizio',description:'Legge la verifica datata del software SEVA e i passaggi mancanti per i pagamenti. Non accede a Stripe, non conferma saldi o capacità LIVE e non avvia checkout, abbonamenti o trasferimenti.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,idempotentHint:true,openWorldHint:false}}
];
export async function handleMCP(request){
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
 const send=(data,status=200)=>new Response(JSON.stringify(data),{status,headers});
 if(request.method!=='POST')return new Response(null,{status:405,headers:{...headers,Allow:'POST'}});
 if(!(request.headers.get('content-type')||'').toLowerCase().startsWith('application/json'))return send({error:'JSON required'},415);
 // Reject browser cross-site requests; authenticated server MCP requests have no Origin.
 const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return send({error:'Origin not allowed'},403);
 let body;
 try{const reader=request.body?.getReader();if(!reader)throw Error();let size=0,parts=[];for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>24000){await reader.cancel();return send({error:'Request too large'},413);}parts.push(value);}const bytes=new Uint8Array(size);let at=0;for(const part of parts){bytes.set(part,at);at+=part.length;}body=JSON.parse(new TextDecoder().decode(bytes));}catch{return send({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Invalid JSON'}});}
 const id=body?.id??null,error=(code,message)=>send({jsonrpc:'2.0',id,error:{code,message}}),ok=result=>send({jsonrpc:'2.0',id,result});
 if(!body||Array.isArray(body)||body.jsonrpc!=='2.0'||typeof body.method!=='string'||(id!==null&&typeof id!=='string'&&typeof id!=='number'))return error(-32600,'Invalid request');
 if(body.method==='server/discover')return ok({supportedVersions:['2026-07-28'],capabilities:{tools:{}},serverInfo:{name:'SEVA · Obiettivi e metriche',version:'1.0.0'}});
 if(body.method==='initialize')return ok({protocolVersion:'2025-03-26',capabilities:{tools:{}},serverInfo:{name:'SEVA · Obiettivi e metriche',version:'1.0.0'}});
 if(body.method==='notifications/initialized')return new Response(null,{status:202,headers});
 if(body.method==='ping')return ok({});
 if(body.method==='tools/list')return ok({tools:SEVA_MCP_TOOLS});
 if(body.method!=='tools/call')return error(-32601,'Method not found');
 const name=body.params?.name,args=body.params?.arguments??{};
 if(!SEVA_MCP_TOOLS.some(t=>t.name===name))return error(-32602,'Unknown tool');
 try{
  if(!args||typeof args!=='object'||Array.isArray(args))throw Error('Argomenti non validi.');
  if(name==='seva_payment_readiness'&&Object.keys(args).length)throw Error('Questo strumento non accetta parametri.');
  const data=name==='seva_growth_scenario'?growthScenario(args):name==='seva_conversion_interval'?conversionInterval(args):paymentReadiness();
  return ok({content:[{type:'text',text:JSON.stringify(data)}],structuredContent:data,isError:false});
 }catch(e){return ok({content:[{type:'text',text:e.message}],isError:true});}
}
