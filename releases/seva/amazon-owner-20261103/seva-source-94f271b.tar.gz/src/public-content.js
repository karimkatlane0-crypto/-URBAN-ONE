export const PUBLIC_CONTENT={
  "terms": {
    "it": {
      "title": "Termini e condizioni",
      "tag": "SEVA BASE · VERSIONE 1.0",
      "intro": "Le regole del workspace gratuito e delle richieste di collaborazione. In vigore dal 3 novembre 2026.",
      "sections": [
        [
          "1. Chi offre SEVA",
          "<p>SEVA è un progetto indipendente di Karim Katlane, contattabile a <a href=\"mailto:karimkatlane0@gmail.com\">karimkatlane0@gmail.com</a>. Queste condizioni riguardano il sito, il workspace e gli strumenti gratuiti di calcolo e stato SEVA collegati a ChatGPT o Codex.</p><p>OpenAI, ChatGPT, Codex ed EY sono nomi dei rispettivi titolari. La loro menzione non indica affiliazione, certificazione, rappresentanza o partnership con SEVA.</p>"
        ],
        [
          "2. Cosa puoi usare",
          "<p>SEVA Base è gratuito: organizza obiettivi, criteri ed evidenze; registra richieste e offerte manuali; prepara un brief AI; conserva un registro assistenza; esporta i tuoi dati. Puoi scegliere di sincronizzare gli obiettivi nel tuo account.</p><p>Il registro assistenza personale non invia messaggi ai tuoi clienti. “Contatta SEVA”, Community e Business inviano invece la richiesta al titolare e permettono di leggere la risposta nel workspace.</p>"
        ],
        [
          "3. Accesso e uso responsabile",
          "<p>Il workspace richiede l’accesso tramite ChatGPT. Rispetta le condizioni e i requisiti di età del servizio di accesso; se non hai la capacità di concludere autonomamente un accordo, occorre l’assistenza di chi ne ha titolo. Proteggi il tuo account e usa un dispositivo adeguato.</p><p>Inserisci soltanto contenuti che puoi utilizzare legittimamente. Non caricare password, documenti d’identità, dati sanitari o finanziari di terzi; non utilizzare il servizio per spam, frodi, discriminazione o accessi non autorizzati. Le dichiarazioni accademiche inserite dall’utente non sono verifiche universitarie.</p>"
        ],
        [
          "4. Dati e contenuti",
          "<p>I diritti sui tuoi contenuti restano tuoi. SEVA li tratta per rendere disponibili le funzioni richieste secondo l’<a href=\"/privacy\">informativa privacy</a>. Non vengono concessi diritti di pubblicazione promozionale dei tuoi contenuti o del tuo nome con la sola registrazione.</p><p>Foto, contatti e catalogo manuale rimangono nel browser. Conserva una copia esportata quando ti serve. L’eliminazione locale non cancella i dati salvati online: usa i controlli delle relative sezioni o chiedi assistenza.</p>"
        ],
        [
          "5. AI, modelli ed evidenze",
          "<p>SEVA prepara testo che scegli di copiare o scaricare e inviare al tuo provider AI. Non esegue inferenza automatica nel workspace pubblico, non raccoglie chiavi API e non include abbonamenti o credito ChatGPT, OpenAI o altri provider.</p><p>I 10.000 comandi sono combinazioni di istruzioni da consultare e adattare, non 10.000 agenti autonomi. Verifica le risposte AI e le fonti prima di usarle. Una spunta o un’evidenza inserita dall’utente non costituisce certificazione indipendente.</p>"
        ],
        [
          "6. Prezzi e pagamenti",
          "<p>SEVA Base non prevede addebiti. I checkout Stripe TEST sono riservati al titolare per collaudo: importi e rinnovi sono simulati e non acquistano servizi commerciali.</p><p>Le offerte Enterprise, Acquisti ed E-commerce a pagamento non sono ancora ordinabili online. Una richiesta di preventivo non è un ordine, non autorizza addebiti e non iscrive a rinnovi. Prima di qualsiasi acquisto devono essere comunicati venditore, servizio incluso, prezzo totale, imposte, durata, consegna, assistenza e condizioni applicabili.</p><p>Gli eventuali costi del tuo provider AI sono separati e dipendono dal contratto che hai con quel provider.</p>"
        ],
        [
          "7. Assistenza, modifiche e disponibilità",
          "<p>Puoi scrivere all’indirizzo sopra indicato o utilizzare <a href=\"/app?section=contact\">Contatta SEVA</a>. Non è un servizio di emergenza e non è promesso un tempo di risposta contrattuale. Segnala errori o barriere di accessibilità con il percorso seguito e il risultato atteso, evitando dati riservati.</p><p>Le funzioni possono essere aggiornate. La versione e la data di queste condizioni sono pubblicate qui; le modifiche non trasformano il servizio gratuito in un abbonamento senza una tua scelta espressa. In caso di sospensione per abusi o problemi di sicurezza, sarà fornita una spiegazione quando possibile e compatibile con la sicurezza.</p>"
        ],
        [
          "8. Diritti e controversie",
          "<p>Nessuna clausola limita diritti inderogabili, garanzie previste dalla legge o responsabilità che non possano essere escluse. Non sono promessi guadagni, risultati economici, credito, decisioni professionali o disponibilità continua.</p><p>Il riferimento è la legge italiana, senza privare il consumatore delle tutele inderogabili del proprio paese quando applicabili. Restano ferme le regole di competenza a tutela del consumatore. Per prima cosa puoi inviare un reclamo al contatto SEVA; ciò non limita l’accesso alle autorità o al giudice competente.</p>"
        ],
        [
          "Proposta Community Entry",
          "<p>Omnibus Omnia Community Entry è una proposta di piano da 50 € al mese per account, IVA inclusa, rivolta a tutte le categorie di pubblico. Non è acquistabile. Nessun iscritto attuale viene addebitato, abbonato o trasferito automaticamente. Il servizio gratuito disponibile continua secondo questi termini fino alla definizione e accettazione espressa di una separata offerta a pagamento. Servizi inclusi, dettagli fiscali applicabili, rinnovo e disdetta devono essere pubblicati prima dell’attivazione commerciale.</p>"
        ],
        [
          "Link di affiliazione Amazon",
          "<p>La <a href=\"/amazon\">guida studenti Amazon di SEVA</a> contiene un link pubblicitario di affiliazione, segnalato chiaramente. In qualità di Affiliato Amazon io ricevo un guadagno dagli acquisti idonei. Questo non costituisce un’approvazione o una certificazione Amazon.</p><p>Il link include un codice di affiliazione pubblico e il browser può comunicare l’origine del sito SEVA. SEVA non trasmette profilo, matricola o email tramite questo link e non incorpora script o pixel di tracciamento Amazon. Se scegli di aprire Amazon, si applicano le sue informative privacy e cookie. Amazon gestisce idoneità, abbonamento, pagamento e disdetta. Nessun pagamento Amazon viene elaborato da SEVA.</p>"
        ]
      ]
    },
    "en": {
      "title": "Terms and conditions",
      "tag": "SEVA BASIC · VERSION 1.0",
      "intro": "Rules for the free workspace and collaboration enquiries. Effective 3 November 2026.",
      "sections": [
        [
          "1. Who provides SEVA",
          "<p>SEVA is an independent project by Karim Katlane. Contact: <a href=\"mailto:karimkatlane0@gmail.com\">karimkatlane0@gmail.com</a>. These terms cover the SEVA website, workspace and connected free calculation and readiness tools in ChatGPT or Codex.</p><p>OpenAI, ChatGPT, Codex and EY belong to their respective owners. Mentioning them does not imply affiliation, certification, representation or partnership with SEVA.</p>"
        ],
        [
          "2. Available features",
          "<p>SEVA Basic is free: organize goals, acceptance criteria and evidence; record requests and manually entered offers; prepare an AI brief; keep a service register; export your data. You can choose to sync goals to your account.</p><p>Your personal service register does not message your customers. Contact SEVA, Community and Business enquiries are sent privately to the project owner, with replies available in your workspace.</p>"
        ],
        [
          "3. Access and responsible use",
          "<p>The workspace requires ChatGPT sign-in. Follow the sign-in provider’s terms and age requirements. If you cannot independently enter an agreement, involve an authorized parent or representative. Protect your account and choose a suitable device.</p><p>Only submit content you are entitled to use. Do not submit passwords, identity documents, sensitive health data or third-party financial records. Do not use SEVA for spam, fraud, discrimination or unauthorized access. Student declarations are not university verification.</p>"
        ],
        [
          "4. Your content and data",
          "<p>You retain your rights in your content. Processing is described in the <a href=\"/privacy?lang=en\">privacy notice</a> and supports the features you request. Signing up does not grant permission to publish your name or content for promotion.</p><p>Photos, contacts and your manual catalog remain in your browser. Export a copy when needed. Local deletion does not delete online records: use the relevant section’s controls or request assistance.</p>"
        ],
        [
          "5. AI and evidence",
          "<p>SEVA prepares a brief for you to copy or download and submit to your own AI provider. The public workspace does not run automatic AI inference, collect API keys or include ChatGPT, OpenAI or other provider subscriptions or credit.</p><p>The 10,000 commands are combinations of instructions to consult and adapt, not 10,000 autonomous agents. Check AI answers and sources before relying on them. User-recorded evidence is not independent certification.</p>"
        ],
        [
          "6. Prices and payments",
          "<p>SEVA Basic carries no charge. Stripe TEST checkouts are owner-only trials: amounts and renewals are simulated and do not buy commercial services.</p><p>Paid Enterprise, Purchasing and E-commerce plans are not available to order online. A proposal enquiry is not an order and does not authorize charges or renewals. Any future purchase must first specify the seller, scope, total price, taxes, duration, delivery, support and applicable conditions.</p><p>Your AI provider’s fees are separate and depend on your own provider agreement.</p>"
        ],
        [
          "7. Support and changes",
          "<p>Email the contact above or use <a href=\"/app?section=contact\">Contact SEVA</a>. This is not an emergency service and no contractual response time is offered. Report errors and accessibility barriers with reproduction steps and the expected outcome, without confidential data.</p><p>Features may change. The version and effective date of these terms are displayed here. Changes do not convert free access into a paid subscription without your express choice. Where possible and consistent with security, we will explain suspensions due to abuse or security issues.</p>"
        ],
        [
          "8. Rights and disputes",
          "<p>Nothing here limits mandatory rights, statutory guarantees or liability that cannot lawfully be excluded. SEVA does not promise earnings, economic outcomes, credit, professional decisions or uninterrupted availability.</p><p>Italian law applies without removing any mandatory consumer protections applicable in your country. Mandatory consumer jurisdiction rules remain unaffected. You can raise a complaint with SEVA; this does not restrict recourse to a competent authority or court.</p>"
        ],
        [
          "Proposed Community Entry plan",
          "<p>Omnibus Omnia Community Entry is a proposed €50 monthly plan per account, VAT included across audience categories. It is not available to purchase. No current member is charged, enrolled in a subscription or migrated automatically. The available free service continues under these terms until a separate paid offer is finalized and expressly accepted. Included services, applicable tax details, renewal and cancellation terms must be published before commercial activation.</p>"
        ],
        [
          "Amazon affiliate links",
          "<p>The <a href=\"/amazon?lang=en\">SEVA Amazon student guide</a> contains a clearly labelled advertising affiliate link. As an Amazon Associate I earn from qualifying purchases. This does not constitute an endorsement or certification by Amazon.</p><p>The link includes a public affiliate tag and may send the SEVA website origin through the browser. SEVA does not send your profile, student number or email through this link and embeds no Amazon tracking script or pixel. When you choose to open Amazon, its own privacy and cookie policies apply. Amazon manages offer eligibility, subscription, payment and cancellation. No Amazon payment is processed by SEVA.</p>"
        ]
      ]
    }
  },
  "privacy": {
    "it": {
      "title": "Informativa privacy",
      "tag": "DATI E DIRITTI · VERSIONE 1.0",
      "intro": "Come sono trattati i dati nelle funzioni attualmente disponibili. Aggiornata il 3 novembre 2026.",
      "sections": [
        [
          "Titolare e contatto",
          "<p>Il titolare dei trattamenti effettuati per il progetto SEVA è Karim Katlane. Per domande e diritti privacy scrivi a <a href=\"mailto:karimkatlane0@gmail.com?subject=SEVA%20-%20Privacy\">karimkatlane0@gmail.com</a>. Puoi contattarci anche senza un account ChatGPT. Se usi il workspace, è disponibile <a href=\"/app?section=contact\">Contatta SEVA</a>.</p>"
        ],
        [
          "Dati, finalità e basi giuridiche",
          "<div class=\"table-wrap\"><table><thead><tr><th>Dati</th><th>Uso</th><th>Base</th></tr></thead><tbody><tr><td>Identificativo account e stato di accesso; email per riconoscere il titolare</td><td>Accesso e separazione dei workspace</td><td>Esecuzione del servizio richiesto</td></tr><tr><td>Obiettivi sincronizzati, criteri, evidenze e registro assistenza</td><td>Salvataggio e gestione nel tuo account</td><td>Esecuzione del servizio richiesto</td></tr><tr><td>Nome, messaggio, risposta e date di una richiesta</td><td>Assistenza, proposta commerciale o collaborazione richiesta da te</td><td>Servizio richiesto o misure precontrattuali</td></tr><tr><td>Profilo studente: nome, università, corso, anno; email universitaria e matricola facoltative</td><td>Profilo volontario dichiarato dall’utente</td><td>Consenso, revocabile eliminando il profilo</td></tr><tr><td>Riferimenti Stripe, importi e stato del collaudo riservato al titolare</td><td>Verificare e riconciliare pagamenti TEST e accessi di prova</td><td>Legittimo interesse alla sicurezza e al collaudo del servizio</td></tr></tbody></table></div><p>Il conferimento dei dati minimi è necessario soltanto per la funzione che richiedi. Puoi consultare le pagine pubbliche senza compilare il profilo o inviare richieste. SEVA non usa questi dati per pubblicità comportamentale o vendita di elenchi di contatti.</p>"
        ],
        [
          "Cosa resta nel browser",
          "<p>Richieste personali, foto, contatti, catalogo e piano locale sono conservati nello spazio del browser associato al tuo account. Gli obiettivi vanno sul server quando scegli la sincronizzazione; il registro assistenza, il profilo studente e le richieste al titolare sono online quando li salvi.</p><p>I file TXT/Markdown per il brief AI sono letti localmente. La bozza resta in memoria; non è inviata automaticamente al provider AI. I link inseriti non importano il contenuto delle pagine. Gli export salvati sul tuo dispositivo sono copie sotto il tuo controllo.</p>"
        ],
        [
          "Chi può ricevere i dati",
          "<p>Il titolare può leggere le richieste inviate tramite Contatta SEVA, Community e Business per rispondere. L’accesso amministrativo ai dati tecnici è limitato alla gestione del servizio; la separazione per account non equivale a cifratura end-to-end.</p><p>La piattaforma ChatGPT Sites e l’infrastruttura Cloudflare supportano accesso, hosting e archivio. Stripe tratta le informazioni inserite nel checkout TEST; SEVA conserva riferimenti e stato, non numeri completi di carta o CVC. Nessun pagamento reale è disponibile in questa versione.</p><p>Per i servizi propri dei fornitori valgono anche le loro informative: <a href=\"https://openai.com/it-IT/policies/eu-privacy-policy/\">OpenAI</a>, <a href=\"https://www.cloudflare.com/privacypolicy/\">Cloudflare</a>, <a href=\"https://stripe.com/privacy\">Stripe</a>. Aprire un provider AI e inviarvi un brief è una scelta distinta dell’utente.</p>"
        ],
        [
          "Conservazione e cancellazione",
          "<p>I dati locali rimangono fino alla loro eliminazione tramite SEVA o le impostazioni del browser. In Connessioni puoi eliminare il workspace locale dell’account corrente, comprese le copie locali di sincronizzazione. Gli altri account sul dispositivo non vengono cancellati.</p><p>I record online restano per rendere disponibile la funzione richiesta finché li mantieni nel workspace. Puoi eliminare profilo studente e richieste nelle rispettive sezioni; per gli obiettivi rimuovi le voci e sincronizza la modifica, per il registro assistenza usa i suoi controlli. Non è attivo un termine automatico di scadenza per tutti i record. Per cessazione dell’uso o cancellazione completa contatta il titolare.</p><p>Eventuali dati necessari a gestire una contestazione o un obbligo di legge possono essere conservati limitatamente a tale necessità. Copie tecniche e log di piattaforma seguono i cicli e le informative dei fornitori; SEVA non promette una cancellazione istantanea di tali copie.</p>"
        ],
        [
          "Infrastruttura e trasferimenti",
          "<p>L’infrastruttura può comportare trattamenti fuori dallo Spazio economico europeo. OpenAI descrive nelle proprie condizioni i meccanismi di adeguatezza e le clausole contrattuali tipo; gli altri fornitori pubblicano le proprie misure e informative. Per informazioni sulle garanzie applicabili al tuo caso puoi contattare il titolare e i fornitori attraverso i link sopra.</p><p>SEVA non dichiara una residenza esclusivamente europea dei dati né una certificazione di conformità. Nessun contenuto del workspace è trasmesso automaticamente da SEVA a un modello AI pubblico.</p>"
        ],
        [
          "I tuoi diritti",
          "<p>Nei casi previsti puoi chiedere accesso, rettifica, cancellazione, limitazione e portabilità, opporti ai trattamenti basati sul legittimo interesse e revocare un consenso senza incidere sul trattamento precedente. Puoi presentare reclamo al <a href=\"https://www.garanteprivacy.it/\">Garante per la protezione dei dati personali</a> o all’autorità competente.</p><p>Le richieste ricevono riscontro entro i termini previsti dal GDPR, normalmente un mese, con comunicazione di eventuali proroghe motivate. Potrebbero servire informazioni proporzionate per identificare il record corretto: non inviare documenti d’identità senza una richiesta specifica e un canale adeguato.</p><p>SEVA non prende decisioni automatizzate con effetti giuridici o analogamente significativi, né certifica identità, merito creditizio o iscrizioni universitarie.</p>"
        ],
        [
          "Cookie e aggiornamenti",
          "<p>Consulta la <a href=\"/cookies\">pagina cookie e memoria locale</a>. L’uso del servizio non comporta consenso marketing. La versione aggiornata dell’informativa è disponibile su questa pagina e può essere scaricata.</p>"
        ],
        [
          "Strumenti SEVA in ChatGPT",
          "<p>Gli strumenti facoltativi SEVA ricevono ipotesi numeriche o conteggi aggregati forniti nella conversazione. Calcolano e restituiscono risultati senza salvarli nel database SEVA. Non leggono spazi privati, account Stripe o dati bancari e non eseguono pagamenti. ChatGPT tratta conversazione e connessione secondo le proprie informative. Inserisci solo dati aggregati e non riservati. L’hosting del sito può conservare log tecnici delle richieste.</p>"
        ],
        [
          "Link di affiliazione Amazon",
          "<p>La <a href=\"/amazon\">guida studenti Amazon di SEVA</a> contiene un link pubblicitario di affiliazione, segnalato chiaramente. In qualità di Affiliato Amazon io ricevo un guadagno dagli acquisti idonei. Questo non costituisce un’approvazione o una certificazione Amazon.</p><p>Il link include un codice di affiliazione pubblico e il browser può comunicare l’origine del sito SEVA. SEVA non trasmette profilo, matricola o email tramite questo link e non incorpora script o pixel di tracciamento Amazon. Se scegli di aprire Amazon, si applicano le sue informative privacy e cookie. Amazon gestisce idoneità, abbonamento, pagamento e disdetta. Nessun pagamento Amazon viene elaborato da SEVA.</p>"
        ]
      ]
    },
    "en": {
      "title": "Privacy notice",
      "tag": "DATA AND RIGHTS · VERSION 1.0",
      "intro": "How data is handled in the features currently available. Updated 3 November 2026.",
      "sections": [
        [
          "Controller and contact",
          "<p>The controller for SEVA project processing is Karim Katlane. For privacy questions or rights requests email <a href=\"mailto:karimkatlane0@gmail.com?subject=SEVA%20-%20Privacy\">karimkatlane0@gmail.com</a>, including without a ChatGPT account. Signed-in users can also use <a href=\"/app?section=contact\">Contact SEVA</a>.</p>"
        ],
        [
          "Data, purposes and legal bases",
          "<div class=\"table-wrap\"><table><thead><tr><th>Data</th><th>Purpose</th><th>Basis</th></tr></thead><tbody><tr><td>Account identifier and sign-in status; email to recognize the owner</td><td>Access and workspace separation</td><td>Providing the requested service</td></tr><tr><td>Synced goals, criteria, evidence and service register</td><td>Account storage and management</td><td>Providing the requested service</td></tr><tr><td>Name, enquiry, reply and dates</td><td>Requested support, business proposal or collaboration</td><td>Requested service or precontractual steps</td></tr><tr><td>Student name, university, course and year; optional university email and student number</td><td>Voluntary self-declared student profile</td><td>Consent, withdrawable by deleting the profile</td></tr><tr><td>Stripe references, amounts and owner-only test status</td><td>Test payment and entitlement reconciliation</td><td>Legitimate interest in service testing and security</td></tr></tbody></table></div><p>Minimum data is needed only for the feature you request. Public pages can be read without submitting a profile or enquiry. SEVA does not use this data for behavioral advertising or selling contact lists.</p>"
        ],
        [
          "What stays in your browser",
          "<p>Personal requests, photos, contacts, catalog and local plans remain in account-scoped browser storage. Goals reach the server when you choose to sync. The service register, student profile and enquiries to the owner are saved online when you save them.</p><p>TXT/Markdown AI source files are read locally. The brief remains in memory and is not automatically sent to an AI provider. Links do not import webpage content. Downloaded exports are copies under your control.</p>"
        ],
        [
          "Who receives data",
          "<p>The owner reads Contact SEVA, Community and Business submissions to respond. Administrative access supports service operation; account separation is not end-to-end encryption.</p><p>ChatGPT Sites and Cloudflare infrastructure provide access, hosting and storage. Stripe processes details entered in the TEST checkout; SEVA stores references and status, not full card numbers or CVCs. Real payments are unavailable in this release.</p><p>Providers also have notices for their own services: <a href=\"https://openai.com/it-IT/policies/eu-privacy-policy/\">OpenAI</a>, <a href=\"https://www.cloudflare.com/privacypolicy/\">Cloudflare</a>, <a href=\"https://stripe.com/privacy\">Stripe</a>. Sending an AI brief through your own provider account is a separate choice.</p>"
        ],
        [
          "Retention and deletion",
          "<p>Local records remain until deleted through SEVA or browser settings. In Connessioni, local deletion removes the current account’s workspace and local sync copies, leaving other accounts on the device untouched.</p><p>Online records remain available for the requested feature while you keep them in the workspace. Delete student profiles and enquiries in their sections; remove goals and sync the change; use service-register controls for its records. There is no automatic expiry for all records. For cessation of use or full deletion, contact the controller.</p><p>Information necessary for a dispute or legal obligation may be retained only as needed for that purpose. Platform logs and technical copies follow providers’ retention cycles and notices; SEVA does not promise instant erasure of those copies.</p>"
        ],
        [
          "Infrastructure and international transfers",
          "<p>The infrastructure may process data outside the European Economic Area. OpenAI describes adequacy and standard contractual clause mechanisms; other providers publish their own safeguards. Contact the controller or the linked providers for safeguards relevant to your circumstances.</p><p>SEVA does not claim exclusive European data residency or compliance certification. It does not automatically send workspace content to a public AI model.</p>"
        ],
        [
          "Your rights",
          "<p>Where applicable, request access, correction, erasure, restriction and portability, object to legitimate-interest processing and withdraw consent without affecting prior processing. You may complain to the <a href=\"https://www.garanteprivacy.it/\">Italian data protection authority</a> or another competent authority.</p><p>Requests are handled within GDPR deadlines, normally one month, with notice of any justified extension. Proportionate information may be needed to locate the right record; do not send identity documents without a specific request and suitable channel.</p><p>SEVA does not make automated decisions producing legal or similarly significant effects and does not certify identity, creditworthiness or university enrollment.</p>"
        ],
        [
          "Cookies and updates",
          "<p>See <a href=\"/cookies?lang=en\">cookies and local storage</a>. Using SEVA is not consent to marketing. The updated notice is available and downloadable here.</p>"
        ],
        [
          "SEVA tools in ChatGPT",
          "<p>The optional SEVA tools receive numeric scenario assumptions or aggregate conversion counts supplied in the conversation. They calculate and return results without saving them in the SEVA database. They do not read private workspaces, Stripe accounts or bank data and do not execute payments. ChatGPT handles the conversation and connection under its own policies. Enter only aggregate, non-sensitive data. Site hosting may retain technical request logs.</p>"
        ],
        [
          "Amazon affiliate links",
          "<p>The <a href=\"/amazon?lang=en\">SEVA Amazon student guide</a> contains a clearly labelled advertising affiliate link. As an Amazon Associate I earn from qualifying purchases. This does not constitute an endorsement or certification by Amazon.</p><p>The link includes a public affiliate tag and may send the SEVA website origin through the browser. SEVA does not send your profile, student number or email through this link and embeds no Amazon tracking script or pixel. When you choose to open Amazon, its own privacy and cookie policies apply. Amazon manages offer eligibility, subscription, payment and cancellation. No Amazon payment is processed by SEVA.</p>"
        ]
      ]
    }
  },
  "cookies": {
    "it": {
      "title": "Cookie e memoria locale",
      "tag": "SCELTE INFORMATE · VERSIONE 1.0",
      "intro": "Cosa usa SEVA per funzionare e come gestirlo. Aggiornato il 3 novembre 2026.",
      "sections": [
        [
          "Il codice SEVA",
          "<p>La pagina pubblica SEVA non installa cookie pubblicitari, pixel di marketing o strumenti di analisi del comportamento. La lingua è indicata nell’indirizzo della pagina. Non sono caricati widget social o video incorporati.</p><p>Nel workspace, la memoria locale conserva il piano dell’account corrente, le copie utili alla sincronizzazione e le copie di confronto in caso di conflitto. Questi dati servono alla funzione richiesta e non sono usati per seguire la navigazione su altri siti.</p>"
        ],
        [
          "Accesso e servizi esterni",
          "<p>Il servizio di accesso e la piattaforma di hosting possono utilizzare cookie o meccanismi tecnici per sessione, sicurezza e disponibilità. Sono gestiti dalla piattaforma, non dal codice applicativo SEVA. Le condizioni dei fornitori sono collegate nell’<a href=\"/privacy\">informativa privacy</a>.</p><p>Quando apri Stripe, ChatGPT, Gemini o GitHub navighi su un servizio distinto, soggetto ai suoi controlli. SEVA non può impostare preferenze o eliminare cookie su quei domini.</p>"
        ],
        [
          "Come cancellare",
          "<p>Per rimuovere i dati locali dell’account corrente: entra nel workspace, apri Connessioni ed “Elimina dati locali”, dopo aver esportato ciò che vuoi conservare. Per eliminare tutti i dati del dominio, usa le impostazioni del browser. Uscire dall’account non elimina i dati locali.</p><p>La cancellazione locale non elimina record sul server, file esportati o dati conservati da altri servizi. Consulta la privacy per i controlli online e il contatto del titolare.</p>"
        ],
        [
          "Preferenze e cambiamenti",
          "<p>Non è presente un pulsante “Accetta tutto” perché il codice SEVA non attiva tracciamento opzionale. Se verranno introdotti strumenti che richiedono consenso, saranno descritti e attivati soltanto dopo una scelta specifica; rifiuto e revoca dovranno restare disponibili.</p><p>Riferimento: <a href=\"https://www.garanteprivacy.it/home/docweb/-/docweb-display/docweb/9677876\">Linee guida del Garante su cookie e strumenti di tracciamento</a>.</p>"
        ],
        [
          "Link di affiliazione Amazon",
          "<p>La <a href=\"/amazon\">guida studenti Amazon di SEVA</a> contiene un link pubblicitario di affiliazione, segnalato chiaramente. In qualità di Affiliato Amazon io ricevo un guadagno dagli acquisti idonei. Questo non costituisce un’approvazione o una certificazione Amazon.</p><p>Il link include un codice di affiliazione pubblico e il browser può comunicare l’origine del sito SEVA. SEVA non trasmette profilo, matricola o email tramite questo link e non incorpora script o pixel di tracciamento Amazon. Se scegli di aprire Amazon, si applicano le sue informative privacy e cookie. Amazon gestisce idoneità, abbonamento, pagamento e disdetta. Nessun pagamento Amazon viene elaborato da SEVA.</p>"
        ]
      ]
    },
    "en": {
      "title": "Cookies and local storage",
      "tag": "INFORMED CHOICES · VERSION 1.0",
      "intro": "What SEVA uses to work and how you can manage it. Updated 3 November 2026.",
      "sections": [
        [
          "SEVA application code",
          "<p>The SEVA public page does not install advertising cookies, marketing pixels or behavioral analytics. Language is set in the page URL. No embedded social widgets or videos are loaded.</p><p>The workspace uses account-scoped local storage for plans, sync copies and conflict comparison copies. These support the requested features and do not track browsing across other sites.</p>"
        ],
        [
          "Sign-in and other services",
          "<p>The sign-in and hosting platform may use technical cookies or mechanisms for sessions, security and availability. These are managed by the platform rather than SEVA application code. Provider notices are linked in our <a href=\"/privacy?lang=en\">privacy notice</a>.</p><p>Opening Stripe, ChatGPT, Gemini or GitHub takes you to a separate service with its own controls. SEVA cannot change preferences or erase cookies on those domains.</p>"
        ],
        [
          "Deleting data",
          "<p>To remove the current account’s local data, open Connessioni in your workspace and select Elimina dati locali after exporting anything you need. Browser settings can remove all data for the domain. Signing out does not erase local data.</p><p>Local deletion does not remove server records, exported files or data held by other services. See privacy for online controls and the controller’s contact.</p>"
        ],
        [
          "Choices and changes",
          "<p>There is no “Accept all” control because SEVA application code does not activate optional tracking. If consent-requiring tools are added, they must be explained and activated only after a specific choice, with refusal and withdrawal available.</p><p>Reference: <a href=\"https://www.garanteprivacy.it/home/docweb/-/docweb-display/docweb/9677876\">Italian authority guidelines on cookies and tracking</a>.</p>"
        ],
        [
          "Amazon affiliate links",
          "<p>The <a href=\"/amazon?lang=en\">SEVA Amazon student guide</a> contains a clearly labelled advertising affiliate link. As an Amazon Associate I earn from qualifying purchases. This does not constitute an endorsement or certification by Amazon.</p><p>The link includes a public affiliate tag and may send the SEVA website origin through the browser. SEVA does not send your profile, student number or email through this link and embeds no Amazon tracking script or pixel. When you choose to open Amazon, its own privacy and cookie policies apply. Amazon manages offer eligibility, subscription, payment and cancellation. No Amazon payment is processed by SEVA.</p>"
        ]
      ]
    }
  },
  "partners": {
    "it": {
      "title": "Costruiamo un caso utile.",
      "tag": "PARTNER · IMPRESE · COMMUNITY",
      "intro": "Da Trieste, una proposta aperta a organizzazioni e collaboratori internazionali: un problema definito, un progetto pilota, una prova del risultato.",
      "sections": [
        [
          "Invita un negozio o un creator",
          "<p>Condividi una pagina pubblica da cui provare il servizio gratuito e proporre un pilota volontario.</p><a class=\"btn\" href=\"/join\">Apri l’invito</a>"
        ],
        [
          "Tre percorsi di collaborazione",
          "<div class=\"cards\"><article><span class=\"number\">01</span><h3>Imprese e negozi</h3><p>Organizzare bisogni, cataloghi manuali e assistenza. Il punto di partenza è un processo reale da migliorare.</p></article><article><span class=\"number\">02</span><h3>Community e formazione</h3><p>Proporre percorsi di studio, accessibilità e partecipazione, con condivisione volontaria dei dati.</p></article><article><span class=\"number\">03</span><h3>Sviluppatori</h3><p>Contribuire a test, esperienza utente, documentazione e integrazioni da concordare. <a href=\"/developers\">Percorso tecnico →</a></p></article></div>"
        ],
        [
          "Il progetto pilota",
          "<ol><li>Descrivi il problema e chi ne beneficia.</li><li>Concordiamo perimetro, dati minimi e risultato misurabile.</li><li>Prima del lavoro a pagamento ricevi una proposta scritta con prezzo, tempi e responsabilità.</li><li>Il risultato viene valutato sulle prove raccolte e sui limiti osservati.</li></ol><p>La manifestazione d’interesse è gratuita e non vincolante. Non apre un abbonamento, non concede accesso a dati di terzi e non rende pubblica la tua organizzazione.</p>"
        ],
        [
          "Cosa è disponibile",
          "<p>Il workspace Base è aperto. Sono disponibili obiettivi, esportazione, registro assistenza e richieste private. L’AI si usa attraverso l’account personale del provider. Le pagine pubbliche sono in italiano e inglese; il workspace è attualmente in italiano.</p><p>Servizi Enterprise, integrazioni dedicate, SLA, assistenza gestita e distribuzione mobile richiedono una valutazione specifica. Non sono inclusi per il solo fatto di richiedere informazioni.</p>"
        ],
        [
          "Segui le tue collaborazioni",
          "<p>Crea un piano privato per un’impresa, un club, una community o un fornitore tecnologico. Ogni percorso comprende referente, proposta e risposta, accordo e risultati, con criteri ed evidenze modificabili. Se esiste già un accordo, documentane perimetro e conferma della controparte.</p><div class=\"actions\"><a class=\"btn\" href=\"/app?section=partnerships\">Crea percorso privato →</a><a class=\"btn light\" href=\"/sports\">Calcio e basket</a></div><p class=\"small\">Il piano non invia richieste e non certifica partnership. Puoi esportarlo o scegliere la sincronizzazione degli obiettivi nel tuo account.</p>"
        ],
        [
          "Parliamone",
          "<p>Indica organizzazione, paese, problema, risultato atteso e contatto professionale. Condividi inizialmente solo informazioni non riservate.</p><div class=\"actions\"><a class=\"btn\" href=\"/app?section=business\">Invia richiesta privata</a><a class=\"btn light\" href=\"mailto:karimkatlane0@gmail.com?subject=SEVA%20-%20Proposta%20di%20collaborazione\">Scrivi via email</a></div><p class=\"small\">La richiesta nel workspace viene salvata nel tuo account; l’email apre il tuo programma di posta e viene inviata solo da te. Nessun partner esterno è annunciato come acquisito.</p>"
        ]
      ]
    },
    "en": {
      "title": "Build a useful case with us.",
      "tag": "PARTNERS · BUSINESSES · COMMUNITY",
      "intro": "From Trieste, an invitation to organizations and international collaborators: define a problem, agree a pilot and evaluate the evidence.",
      "sections": [
        [
          "Invite a shop or creator",
          "<p>Share one public entry page for a free trial and a voluntary pilot proposal.</p><a class=\"btn\" href=\"/join?lang=en\">Open the invitation</a>"
        ],
        [
          "Three ways to collaborate",
          "<div class=\"cards\"><article><span class=\"number\">01</span><h3>Businesses and shops</h3><p>Organize needs, manual catalogs and service requests. Start with a real process you want to improve.</p></article><article><span class=\"number\">02</span><h3>Community and learning</h3><p>Suggest study, accessibility and participation projects with voluntary data sharing.</p></article><article><span class=\"number\">03</span><h3>Developers</h3><p>Contribute to testing, user experience, documentation and scoped integrations. <a href=\"/developers?lang=en\">Technical pathway →</a></p></article></div>"
        ],
        [
          "A focused pilot",
          "<ol><li>Describe the problem and who benefits.</li><li>Agree scope, minimum data and a measurable outcome.</li><li>Before paid work, receive a written proposal covering price, timing and responsibilities.</li><li>Evaluate results against collected evidence and observed limitations.</li></ol><p>Expressions of interest are free and non-binding. They do not create subscriptions, grant access to third-party data or make your organization public.</p>"
        ],
        [
          "Available today",
          "<p>The Basic workspace is open, with goals, export, a service register and private enquiries. AI is used through your own provider account. Public pages are in Italian and English; the workspace is currently in Italian.</p><p>Enterprise services, dedicated integrations, SLAs, managed support and mobile distribution require a separate assessment. Enquiring does not include these services.</p>"
        ],
        [
          "Track your collaborations",
          "<p>Create a private plan for a business, club, community or technology provider. Each plan covers the contact, proposal and response, agreement and outcomes, with editable criteria and evidence. If an agreement already exists, document its scope and confirmation from the other party.</p><div class=\"actions\"><a class=\"btn\" href=\"/app?section=partnerships\">Create a private plan →</a><a class=\"btn light\" href=\"/sports?lang=en\">Football and basketball</a></div><p class=\"small\">The plan does not send enquiries or certify partnerships. Export it or choose goal synchronization in your account. The workspace UI is currently in Italian.</p>"
        ],
        [
          "Start a conversation",
          "<p>Tell us your organization, country, problem, expected outcome and business contact. Begin with non-confidential information only.</p><div class=\"actions\"><a class=\"btn\" href=\"/app?section=business\">Send a private enquiry</a><a class=\"btn light\" href=\"mailto:karimkatlane0@gmail.com?subject=SEVA%20-%20Partnership%20enquiry\">Email us</a></div><p class=\"small\">Workspace enquiries are saved in your account. Email opens your mail app and is sent only by you. No external partner is announced as secured.</p>"
        ]
      ]
    }
  },
  "developers": {
    "it": {
      "title": "Verificare, prima di dichiarare.",
      "tag": "SVILUPPATORI · DEVOPS · DOCUMENTAZIONE",
      "intro": "Un punto di ingresso per contribuire a SEVA con test riproducibili, dati minimi e confini chiari.",
      "sections": [
        [
          "Il servizio pubblicato",
          "<p>Questo SEVA usa ChatGPT Sites per ospitare il sito e l’accesso, un Worker per le API e un archivio D1 per i record associati all’account. Il progetto URBAN ONE su GitHub comprende anche altre applicazioni: un suo commit non aggiorna automaticamente questo Site.</p><p><a class=\"btn light\" href=\"https://github.com/karimkatlane0-crypto/-URBAN-ONE\">Apri il repository URBAN ONE ↗</a></p><p>La disponibilità pubblica del repository non concede automaticamente una licenza su ogni componente: controlla la licenza applicabile prima di riusare codice, nomi o contenuti.</p>"
        ],
        [
          "Come contribuire",
          "<ol><li>Descrivi un problema riproducibile con risultato atteso e osservato.</li><li>Usa dati sintetici; rimuovi credenziali, identificativi personali e schermate riservate.</li><li>Proponi una modifica limitata con prova del risultato.</li><li>Se riguarda sicurezza o privacy, scrivi privatamente al titolare prima di pubblicare dettagli.</li></ol><p>Le proposte non concedono accessi di amministrazione o autorizzazioni a operare sui dati degli utenti.</p>"
        ],
        [
          "Stato verificabile",
          "<p>Il 2 novembre 2026 è stato completato un acquisto Stripe TEST Enterprise con carta: checkout pagato, evento ricevuto, accesso TEST mostrato e rinnovo disattivato. Non è una vendita reale. La verifica degli altri metodi, dei servizi commerciali e della pubblicazione mobile resta separata.</p><p>Il sito espone <a href=\"/api/status\">uno stato tecnico pubblico</a>. Le API personali richiedono accesso e contesto dell’account; non sono una API pubblica per agenti esterni.</p>"
        ],
        [
          "Per agenti e strumenti di ricerca",
          "<p>La <a href=\"/llms.txt\">scheda pubblica per strumenti AI</a> raccoglie solo collegamenti e limiti del prodotto. Non concede autorizzazioni a inviare messaggi, acquistare, leggere workspace privati o impersonare l’utente.</p><p><a href=\"mailto:karimkatlane0@gmail.com?subject=SEVA%20-%20Segnalazione%20tecnica\">Segnala un problema tecnico</a> · <a href=\"/press\">Materiali per presentare SEVA</a></p>"
        ],
        [
          "Strumenti di calcolo SEVA",
          "<p>Il sito espone tre strumenti in sola lettura: seva_growth_scenario, seva_conversion_interval e seva_payment_readiness. I primi due calcolano da ipotesi o conteggi aggregati; il terzo restituisce evidenze datate del software, non una verifica live Stripe. Nessuno crea ordini, addebita carte o invia accrediti. Il plugin iniziale è privato del titolare: non è una pubblicazione nella directory pubblica.</p>"
        ]
      ]
    },
    "en": {
      "title": "Verify before you claim.",
      "tag": "DEVELOPERS · DEVOPS · DOCUMENTATION",
      "intro": "A starting point for contributing reproducible tests, minimal data and clearly scoped changes.",
      "sections": [
        [
          "The hosted service",
          "<p>This SEVA uses ChatGPT Sites for hosting and sign-in, a Worker for APIs and D1 for account-scoped records. The URBAN ONE GitHub project also contains other applications: a commit there does not automatically update this Site.</p><p><a class=\"btn light\" href=\"https://github.com/karimkatlane0-crypto/-URBAN-ONE\">Open the URBAN ONE repository ↗</a></p><p>A public repository does not automatically license every component. Check the applicable license before reusing code, names or content.</p>"
        ],
        [
          "Contributing",
          "<ol><li>Describe a reproducible issue, expected behavior and actual behavior.</li><li>Use synthetic data; remove credentials, personal identifiers and private screenshots.</li><li>Propose a focused change with evidence of the result.</li><li>Report security and privacy details privately to the owner before publishing.</li></ol><p>A contribution does not grant administrative access or permission to act on user data.</p>"
        ],
        [
          "Verifiable status",
          "<p>On 2 November 2026, an Enterprise Stripe TEST card subscription completed: paid checkout, delivered event, visible TEST access and renewal disabled. This was not a real sale. Other payment methods, commercial fulfillment and mobile publication require separate verification.</p><p>The Site exposes <a href=\"/api/status\">public technical status</a>. Personal APIs require sign-in and account context; they are not an external public agent API.</p>"
        ],
        [
          "For AI and research tools",
          "<p>The <a href=\"/llms.txt\">public AI-tool fact sheet</a> lists links and product limits only. It does not grant permission to send messages, make purchases, read private workspaces or impersonate users.</p><p><a href=\"mailto:karimkatlane0@gmail.com?subject=SEVA%20-%20Technical%20report\">Report a technical issue</a> · <a href=\"/press?lang=en\">Materials to introduce SEVA</a></p>"
        ],
        [
          "SEVA calculation tools",
          "<p>The Site exposes three read-only tools: seva_growth_scenario, seva_conversion_interval and seva_payment_readiness. The first two calculate from supplied assumptions or aggregate counts; the third returns dated software evidence, not a live Stripe verification. No tool creates orders, charges cards or sends payouts. The initial plugin is private to the owner; this is not a public directory listing.</p>"
        ]
      ]
    }
  },
  "press": {
    "it": {
      "title": "SEVA, in parole concrete.",
      "tag": "PRESS KIT · CONDIVISIONE VOLONTARIA",
      "intro": "Testi riutilizzabili per presentare il progetto. Informazioni aggiornate al 2 novembre 2026.",
      "sections": [
        [
          "Descrizione breve",
          "<blockquote>SEVA è il workspace di Karim Katlane per trasformare un obiettivo in passi, criteri ed evidenze. Offre accesso Base gratuito, strumenti di organizzazione e un brief da usare con il proprio account AI.</blockquote><p>Link ufficiale: <a href=\"https://seva.karimkatlane0.chatgpt.site/\">seva.karimkatlane0.chatgpt.site</a></p>"
        ],
        [
          "Messaggio pronto da condividere",
          "<blockquote>Un mondo migliore. Un passo concreto. Scopri SEVA: organizza i tuoi obiettivi, documenta i risultati e prepara il prossimo passo. Base gratuito; proposte di collaborazione aperte. https://seva.karimkatlane0.chatgpt.site/</blockquote><p>Puoi scaricare questa pagina e adattare il testo al tuo canale. La condivisione resta volontaria; nessuna lista di destinatari o iscrizione marketing viene attivata.</p>"
        ],
        [
          "Scheda essenziale",
          "<ul><li>Progetto e referente: SEVA · Karim Katlane · Trieste, Italia.</li><li>Pubblico: persone, negozi, community e organizzazioni interessate a progetti pilota.</li><li>Lingue pubbliche: italiano e inglese. Workspace: italiano.</li><li>Accesso: browser, con ChatGPT per il workspace personale.</li><li>Prezzo attuale: SEVA Base gratuito. Piani commerciali non acquistabili online.</li><li>AI: brief inviato manualmente al proprio provider, costi separati.</li></ul>"
        ],
        [
          "Uso corretto dei materiali",
          "<p>È consentito riprodurre questi testi originali per presentare SEVA citando il link e senza alterarne i fatti. Non è consentito far apparire OpenAI, ChatGPT, Codex, Amazon o EY come partner o certificatori di SEVA.</p><p>La disponibilità del press kit non dimostra pubblicazione su media terzi, pubblico raggiunto, partnership concluse, fatturato o distribuzione mondiale verificata.</p><p>Per interviste o collaborazione editoriale: <a href=\"mailto:karimkatlane0@gmail.com?subject=SEVA%20-%20Stampa\">karimkatlane0@gmail.com</a>.</p>"
        ]
      ]
    },
    "en": {
      "title": "SEVA, in practical terms.",
      "tag": "PRESS KIT · VOLUNTARY SHARING",
      "intro": "Reusable materials to introduce the project. Facts updated 2 November 2026.",
      "sections": [
        [
          "Short description",
          "<blockquote>SEVA is Karim Katlane’s workspace for turning goals into steps, acceptance criteria and evidence. It offers free Basic access, organization tools and a brief to use with your own AI provider account.</blockquote><p>Official link: <a href=\"https://seva.karimkatlane0.chatgpt.site/?lang=en\">seva.karimkatlane0.chatgpt.site</a></p>"
        ],
        [
          "Ready-to-share message",
          "<blockquote>A better world. One concrete step. Discover SEVA: organize your goals, document outcomes and prepare your next step. Free Basic access; collaboration enquiries welcome. https://seva.karimkatlane0.chatgpt.site/?lang=en</blockquote><p>Download this page and adapt the text to your channel. Sharing is voluntary and does not activate mailing lists or marketing subscriptions.</p>"
        ],
        [
          "Essential facts",
          "<ul><li>Project and contact: SEVA · Karim Katlane · Trieste, Italy.</li><li>Audience: individuals, shops, communities and organizations interested in pilots.</li><li>Public languages: Italian and English. Workspace: Italian.</li><li>Access: browser, with ChatGPT sign-in for the personal workspace.</li><li>Current price: free Basic access. Paid plans cannot be purchased online.</li><li>AI: manually submit a brief to your own provider; costs are separate.</li></ul>"
        ],
        [
          "Using these materials",
          "<p>You may reproduce this original copy to introduce SEVA, with attribution to its official link and without changing the facts. Do not present OpenAI, ChatGPT, Codex, Amazon or EY as SEVA partners or certifiers.</p><p>Availability of a press kit is not evidence of third-party media coverage, audience reach, concluded partnerships, revenue or verified worldwide distribution.</p><p>For interviews or editorial collaboration: <a href=\"mailto:karimkatlane0@gmail.com?subject=SEVA%20-%20Press\">karimkatlane0@gmail.com</a>.</p>"
        ]
      ]
    }
  },
  "support": {
    "it": {
      "tag": "SEVA · ASSISTENZA",
      "title": "Ricevi assistenza per SEVA.",
      "intro": "Contatta Karim Katlane per il sito SEVA e i suoi strumenti gratuiti in ChatGPT o Codex.",
      "sections": [
        [
          "Contatta il titolare",
          "<p><a href=\"mailto:karimkatlane0@gmail.com\">karimkatlane0@gmail.com</a></p><p>Puoi scrivere senza accedere. Se usi il workspace puoi anche inviare una richiesta privata tramite Contatta SEVA. Non è un servizio di emergenza e non è promesso un tempo di risposta contrattuale.</p><p><a href=\"/app?section=contact\">Contatta SEVA nel tuo workspace</a></p>"
        ],
        [
          "Descrivi il problema",
          "<p>Indica pagina o strumento, risultato atteso, cosa è accaduto e orario approssimativo. Usa dati di esempio aggregati. Non inviare password, credenziali di pagamento, documenti di identità o dati finanziari riservati.</p>"
        ],
        [
          "Disponibilità e richieste sui dati",
          "<p><a href=\"/payments\">Disponibilità pagamenti</a> · <a href=\"/privacy\">Privacy</a> · <a href=\"/terms\">Termini</a></p><p>I tre strumenti SEVA calcolano scenari, intervalli di conversione e informazioni datate sullo stato del servizio. Non leggono account privati dei provider e non eseguono pagamenti. Il plug-in attuale è privato; l’approvazione nella directory pubblica non è attestata.</p>"
        ]
      ]
    },
    "en": {
      "tag": "SEVA · SUPPORT",
      "title": "Get help with SEVA.",
      "intro": "Contact Karim Katlane about the SEVA website and its free tools in ChatGPT or Codex.",
      "sections": [
        [
          "Contact the project owner",
          "<p><a href=\"mailto:karimkatlane0@gmail.com\">karimkatlane0@gmail.com</a></p><p>Email is available without signing in. If you use the workspace, you can also send a private request through Contact SEVA. No emergency service or contractual response time is offered.</p><p><a href=\"/app?section=contact\">Contact SEVA in your workspace</a></p>"
        ],
        [
          "Describe the issue",
          "<p>Include the page or tool, what you expected, what happened and the approximate time. Use aggregate example inputs. Do not send passwords, payment credentials, identity documents or private financial records.</p>"
        ],
        [
          "Availability and data requests",
          "<p><a href=\"/payments?lang=en\">Payment availability</a> · <a href=\"/privacy?lang=en\">Privacy</a> · <a href=\"/terms?lang=en\">Terms</a></p><p>The three SEVA tools calculate scenarios, conversion intervals and dated readiness information. They do not read private provider accounts or execute payments. The current plugin is private; public directory approval has not been established.</p>"
        ]
      ]
    }
  },
  "join": {
    "it": {
      "tag": "SEVA · SETTIMANA DEL PRIMO PASSO",
      "title": "Un obiettivo. Un prossimo passo. Inizia gratis.",
      "intro": "Dal 3 al 9 novembre 2026 prova SEVA Base gratuitamente e trasforma un obiettivo utile in un’azione con criterio e prova.",
      "sections": [
        [
          "La promozione attiva",
          "<div class=\"cards\"><article><span class=\"number\">01</span><h3>Scegli un obiettivo</h3><p>Usa un obiettivo personale, per il negozio o per la community. Mantieni il perimetro abbastanza piccolo da agire questa settimana.</p></article><article><span class=\"number\">02</span><h3>Definisci il successo</h3><p>Aggiungi un criterio di accettazione osservabile prima di iniziare.</p></article><article><span class=\"number\">03</span><h3>Registra il risultato</h3><p>Salva la prova, poi decidi se ripetere, correggere o fermarti.</p></article></div><div class=\"actions\"><a class=\"btn\" href=\"/app?section=home\">Avvia il mio obiettivo gratuito</a><button class=\"btn light\" data-copy-link=\"https://seva.karimkatlane0.chatgpt.site/join\">Copia il link della promozione</button></div><p class=\"small\">Periodo promozionale: 3–9 novembre 2026. SEVA Base è già gratuito: la promozione non aggiunge abbonamenti, sconti, premi, rinnovi automatici o iscrizioni marketing. Non è richiesta una carta.</p>"
        ],
        [
          "Scegli il primo passo",
          "<div class=\"cards\"><article><span class=\"number\">01</span><h3>Per il tuo negozio</h3><p>Descrivi un bisogno, un link pubblico al negozio e il risultato da misurare. Dopo l’accesso puoi inviare una proposta privata.</p><a class=\"btn\" href=\"/app?section=business\">Proponi un pilota negozio</a></article><article><span class=\"number\">02</span><h3>Per creator e community</h3><p>Proponi un progetto creativo o di community con una prossima azione chiara. Partecipare non pubblica il tuo nome.</p><a class=\"btn\" href=\"/app?section=community\">Proponi una collaborazione</a></article><article><span class=\"number\">03</span><h3>Prova i numeri</h3><p>Confronta un budget mensile e l’incertezza della conversione con dati aggregati di esempio. Non serve un account.</p><a class=\"btn\" href=\"/growth\">Apri il calcolatore</a></article></div>"
        ],
        [
          "Un link da condividere",
          "<blockquote>SEVA invita negozi e creator a un pilota volontario: un obiettivo, una prossima azione e una prova del risultato. L’accesso Base è gratuito. Esplora il progetto e valuta se può esserti utile.</blockquote><div class=\"actions\"><button class=\"btn\" data-copy-link=\"https://seva.karimkatlane0.chatgpt.site/join\">Copia link di invito</button><a class=\"btn light\" href=\"/campaigns\">Prepara un messaggio mirato</a></div><p>Scegli tu i destinatari e invii personalmente l’invito. Questa pagina non raccoglie contatti dal web, non invia messaggi di massa e non iscrive nessuno automaticamente.</p>"
        ],
        [
          "Amazon: la guida per studenti",
          "<p>La guida SEVA ti aiuta a valutare l’offerta studenti Amazon.it in base al tuo bisogno, al budget e alle condizioni attuali. Contiene un link pubblicitario di affiliazione. In qualità di Affiliato Amazon io ricevo un guadagno dagli acquisti idonei.</p><div class=\"actions\"><a class=\"btn\" href=\"/amazon\">Apri la guida Amazon per studenti →</a><a class=\"btn light\" href=\"/students\">Esplora SEVA Campus</a></div><p class=\"small\">Idoneità, prezzi, iscrizione ed eventuali pagamenti sono gestiti da Amazon. L’accesso gratuito a SEVA non richiede un acquisto. Nessuna certificazione universitaria o sponsorizzazione è implicata.</p>"
        ],
        [
          "Accesso e pagamenti",
          "<p>Le pagine pubbliche sono aperte. Il workspace personale richiede l’accesso con ChatGPT e mantiene separati i dati degli account. Un invito non concede accessi amministrativi o ai dati altrui.</p><p><strong>Entry · 50 € al mese per account, IVA inclusa.</strong> Il percorso in preparazione comprende salvataggio online degli obiettivi, profilo studenti e registro assistenza privato. Crediti AI e assistenza personale non sono inclusi. Il rinnovo mensile richiederà adesione esplicita e sarà gestibile dal portale Stripe.</p><p>SEVA Base resta gratuito durante la preparazione. Il piano non è ancora acquistabile; commissioni automatiche e accrediti ai venditori non sono attivi.</p><div class=\"actions\"><a class=\"btn\" href=\"/app?section=billing\">Verifica il piano nel tuo account →</a></div><p><a href=\"/payments\">Disponibilità pagamenti</a> · <a href=\"/privacy\">Privacy</a> · <a href=\"/terms\">Termini</a> · <a href=\"/support\">Assistenza</a></p>"
        ]
      ]
    },
    "en": {
      "tag": "SEVA · FIRST STEP WEEK",
      "title": "One goal. One next step. Start free.",
      "intro": "From 3 to 9 November 2026, try SEVA Basic free and turn one useful goal into an action with an acceptance criterion and evidence.",
      "sections": [
        [
          "The active promotion",
          "<div class=\"cards\"><article><span class=\"number\">01</span><h3>Choose one goal</h3><p>Use a personal, shop or community goal. Keep the scope small enough to act on this week.</p></article><article><span class=\"number\">02</span><h3>Define success</h3><p>Add one observable acceptance criterion before you begin.</p></article><article><span class=\"number\">03</span><h3>Record the outcome</h3><p>Save the evidence, then decide whether to repeat, revise or stop.</p></article></div><div class=\"actions\"><a class=\"btn\" href=\"/app?section=home\">Start my free goal</a><button class=\"btn light\" data-copy-link=\"https://seva.karimkatlane0.chatgpt.site/join?lang=en\">Copy promotion link</button></div><p class=\"small\">Promotion period: 3–9 November 2026. SEVA Basic is already free: this promotion adds no paid subscription, discount, prize, automatic renewal or marketing enrollment. No card is required.</p>"
        ],
        [
          "Choose your first step",
          "<div class=\"cards\"><article><span class=\"number\">01</span><h3>For your shop</h3><p>Describe one need, a public shop link and the result you want to measure. Send a private proposal after signing in.</p><a class=\"btn\" href=\"/app?section=business\">Propose a shop pilot</a></article><article><span class=\"number\">02</span><h3>For creators and communities</h3><p>Propose a creative or community project with a clear next action. Joining does not publish your name.</p><a class=\"btn\" href=\"/app?section=community\">Propose a collaboration</a></article><article><span class=\"number\">03</span><h3>Try the numbers</h3><p>Compare a monthly budget and conversion uncertainty using aggregate sample data. No account is required.</p><a class=\"btn\" href=\"/growth?lang=en\">Open the calculator</a></article></div>"
        ],
        [
          "A link you can share",
          "<blockquote>SEVA invites shops and creators to a voluntary pilot: one goal, one next step and evidence of the result. Basic access is free. Explore the project and decide whether it helps you.</blockquote><div class=\"actions\"><button class=\"btn\" data-copy-link=\"https://seva.karimkatlane0.chatgpt.site/join?lang=en\">Copy invitation link</button><a class=\"btn light\" href=\"/campaigns?lang=en\">Prepare a tailored message</a></div><p>You choose the recipients and send the invitation yourself. This page does not scrape contacts, send bulk messages or enroll anyone automatically.</p>"
        ],
        [
          "Amazon: the student guide",
          "<p>The SEVA guide helps you evaluate the Amazon.it student offer against your needs, budget and current conditions. It contains an advertising affiliate link. As an Amazon Associate I earn from qualifying purchases.</p><div class=\"actions\"><a class=\"btn\" href=\"/amazon?lang=en\">Open the Amazon student guide →</a><a class=\"btn light\" href=\"/students?lang=en\">Explore SEVA Campus</a></div><p class=\"small\">Amazon manages eligibility, prices, sign-up and any payments. Free access to SEVA requires no purchase. No university certification or sponsorship is implied.</p>"
        ],
        [
          "Access and payments",
          "<p>The public pages are open. Your personal workspace requires ChatGPT sign-in and keeps account data separate. An invitation grants no administrator access or access to another person’s data.</p><p><strong>Entry · €50 per month per account, VAT included.</strong> The planned service includes online goal saving, a student profile and a private service register. AI credits and personal consulting are not included. Monthly renewal will require explicit consent and will be manageable through the Stripe portal.</p><p>SEVA Basic remains free during preparation. The plan cannot yet be purchased; automatic sales commissions and seller payouts are not active.</p><div class=\"actions\"><a class=\"btn\" href=\"/app?section=billing\">Check the plan in your account →</a></div><p><a href=\"/payments?lang=en\">Payment availability</a> · <a href=\"/privacy?lang=en\">Privacy</a> · <a href=\"/terms?lang=en\">Terms</a> · <a href=\"/support?lang=en\">Support</a></p>"
        ]
      ]
    }
  }
};
