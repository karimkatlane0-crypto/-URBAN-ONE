export const ownerEmail='karimkatlane0@gmail.com';
export function requestIdentity(request){
 const id=request.headers.get('oai-authenticated-user-id');
 if(!id||id.length>200)return null;
 return {id,isOwner:request.headers.get('oai-authenticated-user-email')?.toLowerCase()===ownerEmail};
}
export async function browserIdentity(identity){
 const bytes=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(identity.id)));
 return {scope:Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join(''),isOwner:identity.isOwner};
}
export function browserSessionJSON(session){return JSON.stringify(session).replace(/[<>&]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));}
