import {test} from 'node:test';import assert from 'node:assert/strict';import {handleAI} from '../src/server.js';
const env={SEVA_AI_BILLING_MODE:'owner-test',OPENAI_API_KEY:'test-secret',OPENAI_MODEL:'gpt-4.1-mini'};
const req=(body={prompt:'Piano di prova',consent:true},headers={})=>new Request('https://seva.test/api/ai',{method:'POST',headers:{'oai-authenticated-user-id':'test-user',origin:'https://seva.test','content-type':'application/json',...headers},body:JSON.stringify(body)});
test('AI rejects cross origin before provider',async()=>assert.equal((await handleAI(req(undefined,{origin:'https://other.test'}),env)).status,403));
test('AI requires explicit submission consent',async()=>assert.equal((await handleAI(req({prompt:'abc',consent:false}),env)).status,400));
test('AI fails closed without server key',async()=>assert.equal((await handleAI(req(),{SEVA_AI_BILLING_MODE:'owner-test'})).status,503));
test('AI rejects large prompt',async()=>assert.equal((await handleAI(req({prompt:'a'.repeat(12001),consent:true}),env)).status,400));
test('AI only supports POST',async()=>assert.equal((await handleAI(new Request('https://seva.test/api/ai',{headers:{'oai-authenticated-user-id':'test-user'}}),env)).status,405));
test('AI request is bounded, nonstored, no tool execution; returns provider receipt',async()=>{let called=false;const r=await handleAI(req(),env,async(url,opt)=>{called=true;assert.equal(url,'https://api.openai.com/v1/responses');const body=JSON.parse(opt.body);assert.equal(body.store,false);assert.equal(body.max_output_tokens,900);assert.equal(body.tools,undefined);return Response.json({id:'resp_test',model:'gpt-4.1-mini',status:'completed',output:[{content:[{type:'output_text',text:'Piano reale'}]}],usage:{total_tokens:10}});});const d=await r.json();assert.equal(called,true);assert.equal(d.answer,'Piano reale');assert.equal(d.id,'resp_test');assert.ok(d.verified_at);assert.ok(!JSON.stringify(d).includes(env.OPENAI_API_KEY));});
test('quota error remains an error without fabricated reply',async()=>{const r=await handleAI(req(),env,async()=>Response.json({error:{code:'insufficient_quota',message:'internal'}},{status:429}));const d=await r.json();assert.equal(r.status,429);assert.match(d.error,/Credito/);assert.equal(d.answer,undefined);});
test('empty upstream output does not count as success',async()=>{const r=await handleAI(req(),env,async()=>Response.json({id:'resp_empty',output:[]}));assert.equal(r.status,502);});
test('upstream network errors are sanitized',async()=>{const r=await handleAI(req(),env,async()=>{throw Error('test-secret');});const d=await r.json();assert.equal(d.code,'connection_error');assert.ok(!JSON.stringify(d).includes('test-secret'));});

test('exhausted credit is actionable, not presented as a temporary rate limit',async()=>{
 const r=await handleAI(req(undefined,{'oai-authenticated-user-id':'credit-regression'}),env,async()=>Response.json({error:{code:'credit_balance_exhausted',message:'internal'}},{status:429}));
 const d=await r.json();assert.equal(r.status,429);assert.equal(d.code,'credit_balance_exhausted');assert.match(d.error,/Credito/);assert.doesNotMatch(d.error,/temporaneo/);assert.equal(d.answer,undefined);
});
test('actual rate limits remain distinct from exhausted credit',async()=>{
 const r=await handleAI(req(undefined,{'oai-authenticated-user-id':'rate-regression'}),env,async()=>Response.json({error:{code:'rate_limit_exceeded'}},{status:429}));
 const d=await r.json();assert.equal(r.status,429);assert.match(d.error,/temporaneo/);assert.equal(d.answer,undefined);
});

test('partial or receiptless upstream answers are not certified as complete',async()=>{
 for(const data of [{id:'resp_partial',status:'incomplete'},{status:'completed'},{id:'invalid',status:'completed'}]){
  const r=await handleAI(req(undefined,{'oai-authenticated-user-id':crypto.randomUUID()}),env,async()=>Response.json({...data,output:[{content:[{type:'output_text',text:'Partial answer'}]}]}));
  assert.equal(r.status,502);assert.equal((await r.json()).code,'incomplete_response');
 }
});
