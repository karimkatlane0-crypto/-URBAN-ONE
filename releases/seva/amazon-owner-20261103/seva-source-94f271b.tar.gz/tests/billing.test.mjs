import test,{mock,after} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {createHmac} from 'node:crypto';
import {applyBillingEvent,billingEntitlements,verifyBillingSignature,handleBillingWebhook} from '../src/billing.js';
import {browserIdentity} from '../src/identity.js';
import worker from '../worker/index.js';
// Freeze the fixture clock so generated checkout events cannot predate their intents.
const epoch=Date.UTC(2026,10,2,12)/1000,secret='whsec_SYNTHETIC_TEST_ONLY';
mock.timers.enable({apis:['Date'],now:epoch*1000});
after(()=>mock.timers.reset());
function fixture(){
 const sql=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sql.exec(readFileSync('drizzle/'+f,'utf8'));
 const DB={prepare(query){const s=sql.prepare(query);const bound=args=>({async first(){return s.get(...args)||null;},async all(){return {results:s.all(...args)};},async run(){return {meta:{changes:Number(s.run(...args).changes)}};}});return {...bound([]),bind(...args){return bound(args);}};},async batch(statements){sql.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const plan={id:'enterprise_monthly',label:'Enterprise TEST',mode:'test',amount:5000,currency:'eur',interval:'month',priceId:'price_test',linkId:'plink_test',url:'https://buy.stripe.com/test_synthetic'};
 const env={DB,STRIPE_WEBHOOK_SECRET_TEST:secret,SEVA_BILLING_CONFIG:JSON.stringify({testEnabled:true,testAccount:'acct_test',liveAccount:'acct_live',plans:[plan]})};
 const call=async(path,{user='alice',owner=true,method='GET',body,origin='https://seva.test',scope}={})=>{
  const sid=user?(await browserIdentity({id:user})).scope:'';
  return worker.fetch(new Request('https://seva.test'+path,{method,headers:{...(user?{'oai-authenticated-user-id':user,'oai-authenticated-user-email':owner?'karimkatlane0@gmail.com':'visitor@example.test'}:{}),'X-SEVA-Workspace':scope??sid,origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})}),env);
 };
 return {sql,DB,env,call,plan};
}
const event=(type,object,id=crypto.randomUUID(),created=epoch)=>({id:'evt_'+id,type,created,livemode:false,data:{object}});
const sub=(extra={})=>({id:'sub_test',customer:'cus_test',status:'active',items:{data:[{price:{id:'price_test'},quantity:1}]},...extra});
const invoice=(extra={})=>({id:'in_test',subscription:'sub_test',customer:'cus_test',status:'paid',paid:true,amount_paid:5000,amount_remaining:0,currency:'eur',payment_intent:'pi_test',lines:{data:[{price:{id:'price_test'},quantity:1,period:{start:epoch-20,end:epoch+3600}}]},...extra});
async function intent(f,user='alice',op=crypto.randomUUID()){
 const r=await f.call('/api/billing/checkout',{user,method:'POST',body:{plan:'enterprise_monthly',mode:'test',consent:true,operationId:op}});assert.equal(r.status,200);return r.json();
}
const checkout=token=>({id:'cs_test',mode:'subscription',status:'complete',payment_status:'paid',payment_link:'plink_test',client_reference_id:token,subscription:'sub_test',customer:'cus_test',currency:'eur',amount_subtotal:5000,created:epoch});
async function complete(f,{order=['checkout','subscription','invoice'],user='alice'}={}){
 const i=await intent(f,user),events={checkout:event('checkout.session.completed',checkout(i.reference),'checkout'),subscription:event('customer.subscription.created',sub(),'subscription'),invoice:event('invoice.paid',invoice(),'invoice')};
 for(const name of order)await applyBillingEvent(f.DB,events[name],f.env,'test');return events;
}
test('signatures reject altered bodies, stale/future timestamps and wrong secret; allow rotation',async()=>{
 const raw=JSON.stringify(event('invoice.paid',invoice())),t=String(epoch),v=createHmac('sha256',secret).update(t+'.'+raw).digest('hex'),header=`t=${t},v1=${'0'.repeat(64)},v1=${v}`;
 assert.equal((await verifyBillingSignature(raw,header,secret)).type,'invoice.paid');
 for(const [body,sig,key,now]of [[raw+' ',header,secret],[raw,header,'wrong'],[raw,header,secret,(epoch+301)*1000],[raw,header,secret,(epoch-301)*1000]])await assert.rejects(()=>verifyBillingSignature(body,sig,key,now));
});
test('anonymous, stale-session and non-owner checkout denied; LIVE cannot be selected',async()=>{
 const f=fixture();try{
  const body={plan:'enterprise_monthly',mode:'test',consent:true,operationId:crypto.randomUUID()};
  assert.equal((await f.call('/api/billing/status',{user:null})).status,401);
  assert.equal((await f.call('/api/billing/status',{scope:'other'})).status,409);
  assert.equal((await f.call('/api/billing/checkout',{owner:false,method:'POST',body})).status,403);
  assert.equal((await f.call('/api/billing/checkout',{method:'POST',body:{...body,mode:'live'}})).status,400);
  assert.equal((await f.call('/api/billing/checkout',{method:'POST',body,origin:'https://other.test'})).status,403);
  assert.equal((await f.call('/api/billing/checkout',{method:'POST',body:{...body,amount:1}})).status,400);
  const status=await (await f.call('/api/billing/status',{owner:false})).json();assert.equal(status.liveEnabled,false);assert.equal(status.testPlans,undefined);
 }finally{f.sql.close();}
});
test('checkout retry uses one opaque account-bound intent and requires consent',async()=>{
 const f=fixture();try{const op=crypto.randomUUID(),a=await intent(f,'alice',op),b=await intent(f,'alice',op);assert.equal(a.reference,b.reference);assert.ok(!a.url.includes('alice'));assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM seva_billing_intents').get().n,1);
 const r=await f.call('/api/billing/checkout',{method:'POST',body:{plan:'enterprise_monthly',mode:'test',consent:false,operationId:op}});assert.equal(r.status,400);
 }finally{f.sql.close();}
});
test('redirects and checkout completion alone never grant access',async()=>{
 const f=fixture();try{const i=await intent(f);await applyBillingEvent(f.DB,event('checkout.session.completed',checkout(i.reference)),f.env,'test');assert.deepEqual(await billingEntitlements(f.DB,'alice','test'),[]);
 const r=await f.call('/api/billing/status?checkout=success&paid=true');assert.deepEqual((await r.json()).testActive,[]);
 }finally{f.sql.close();}
});
test('all delivery orders yield one entitlement, isolated by account and mode',async()=>{
 for(const order of [['checkout','subscription','invoice'],['invoice','subscription','checkout'],['subscription','checkout','invoice'],['invoice','checkout','subscription']]){
  const f=fixture();try{await complete(f,{order});assert.equal((await billingEntitlements(f.DB,'alice','test')).length,1);assert.deepEqual(await billingEntitlements(f.DB,'bob','test'),[]);assert.deepEqual(await billingEntitlements(f.DB,'alice','live'),[]);}finally{f.sql.close();}
 }
});
test('duplicate provider delivery does not duplicate periods or receipts',async()=>{
 const f=fixture();try{const events=await complete(f);for(const e of Object.values(events)){const r=await applyBillingEvent(f.DB,e,f.env,'test');assert.equal(r.duplicate,true);}assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM seva_billing_periods').get().n,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM seva_billing_events').get().n,3);}finally{f.sql.close();}
});
test('wrong price, amount, currency, mode, link or expired checkout cannot grant access',async()=>{
 for(const change of [{payment_link:'plink_other'},{currency:'usd'},{amount_subtotal:1},{created:epoch+90000},{mode:'payment'}]){const f=fixture();try{const i=await intent(f);await applyBillingEvent(f.DB,event('checkout.session.completed',{...checkout(i.reference),...change}),f.env,'test');await applyBillingEvent(f.DB,event('invoice.paid',invoice()),f.env,'test');await applyBillingEvent(f.DB,event('customer.subscription.created',sub()),f.env,'test');assert.deepEqual(await billingEntitlements(f.DB,'alice','test'),[]);}finally{f.sql.close();}}
 for(const change of [{currency:'usd'},{amount_paid:1},{paid:false},{paid_out_of_band:true},{lines:{data:[{price:{id:'price_other'},quantity:1,period:{start:epoch-1,end:epoch+1000}}]}}]){const f=fixture();try{const i=await intent(f);await applyBillingEvent(f.DB,event('checkout.session.completed',checkout(i.reference)),f.env,'test');await applyBillingEvent(f.DB,event('customer.subscription.created',sub()),f.env,'test');await applyBillingEvent(f.DB,event('invoice.paid',invoice(change)),f.env,'test');assert.deepEqual(await billingEntitlements(f.DB,'alice','test'),[]);}finally{f.sql.close();}}
});
test('forged context and LIVE events cannot affect TEST data',async()=>{const f=fixture();try{for(const e of [{...event('invoice.paid',invoice()),livemode:true},{...event('invoice.paid',invoice()),account:'acct_intruder'}])await assert.rejects(()=>applyBillingEvent(f.DB,e,f.env,'test'));assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM seva_billing_events').get().n,0);}finally{f.sql.close();}});
test('refunds before or after payment put the matching access on hold',async()=>{
 for(const before of [true,false]){const f=fixture();try{const e=event('charge.refunded',{id:'ch_test',payment_intent:'pi_test',invoice:'in_test',amount_refunded:5000});if(before)await applyBillingEvent(f.DB,e,f.env,'test');await complete(f);if(!before)await applyBillingEvent(f.DB,e,f.env,'test');assert.deepEqual(await billingEntitlements(f.DB,'alice','test'),[]);}finally{f.sql.close();}}
});
test('canceled subscription stays canceled after delayed active event',async()=>{const f=fixture();try{await complete(f);await applyBillingEvent(f.DB,event('customer.subscription.deleted',sub({status:'canceled'}),'deleted',epoch+20),f.env,'test');await applyBillingEvent(f.DB,event('customer.subscription.updated',sub(),'delayed',epoch+10),f.env,'test');assert.deepEqual(await billingEntitlements(f.DB,'alice','test'),[]);}finally{f.sql.close();}});
test('scheduled cancellation retains paid access; failed renewal never extends it',async()=>{const f=fixture();try{await complete(f);await applyBillingEvent(f.DB,event('customer.subscription.updated',sub({cancel_at_period_end:true}),'scheduled',epoch+10),f.env,'test');assert.equal((await billingEntitlements(f.DB,'alice','test'))[0].cancel_at_period_end,1);await applyBillingEvent(f.DB,event('invoice.payment_failed',invoice({id:'in_failed',status:'open',paid:false,amount_paid:0})),f.env,'test');assert.deepEqual(await billingEntitlements(f.DB,'alice','test',(epoch+3601)*1000),[]);}finally{f.sql.close();}});
test('paid renewal extends only its own period; old refund does not revoke a new invoice',async()=>{const f=fixture();try{await complete(f);await applyBillingEvent(f.DB,event('invoice.paid',invoice({id:'in_renewal',payment_intent:'pi_new',lines:{data:[{price:{id:'price_test'},quantity:1,period:{start:epoch+3600,end:epoch+7200}}]}})),f.env,'test');await applyBillingEvent(f.DB,event('charge.refunded',{id:'ch_old',invoice:'in_test',payment_intent:'pi_test',amount_refunded:5000}),f.env,'test');assert.equal((await billingEntitlements(f.DB,'alice','test',(epoch+3601)*1000)).length,1);}finally{f.sql.close();}});
test('a link replay cannot transfer a subscription to another account',async()=>{const f=fixture();try{await complete(f);const i=await intent(f,'bob');await applyBillingEvent(f.DB,event('checkout.session.completed',{...checkout(i.reference),id:'cs_other'}),f.env,'test');assert.equal((await billingEntitlements(f.DB,'alice','test')).length,1);assert.deepEqual(await billingEntitlements(f.DB,'bob','test'),[]);}finally{f.sql.close();}});
test('database failure rolls back payment state and returns a retriable webhook response',async()=>{const f=fixture();try{const i=await intent(f),e=event('checkout.session.completed',checkout(i.reference));f.sql.exec("CREATE TRIGGER reject_receipt BEFORE INSERT ON seva_billing_events BEGIN SELECT RAISE(ABORT,'synthetic failure'); END");await assert.rejects(()=>applyBillingEvent(f.DB,e,f.env,'test'));assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM seva_billing_subscriptions').get().n,0);assert.equal(f.sql.prepare('SELECT session_id FROM seva_billing_intents').get().session_id,null);const raw=JSON.stringify(e),sig=createHmac('sha256',secret).update(epoch+'.'+raw).digest('hex');const r=await handleBillingWebhook(new Request('https://seva.test/api/billing/webhook/test',{method:'POST',headers:{'stripe-signature':`t=${epoch},v1=${sig}`},body:raw}),f.env,'test');assert.equal(r.status,503);}finally{f.sql.close();}});
