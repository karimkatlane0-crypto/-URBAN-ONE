import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker/index.js';

const request=path=>new Request('https://seva.test'+path,{headers:{'oai-authenticated-user-id':'PRIVATE-OWNER','oai-authenticated-user-email':'private@example.test'}});
const DB={prepare(){throw Error('Affiliate guide must not access private records');}};
test('affiliate page uses one fixed HTTPS Amazon destination without reflecting identity or query parameters',async()=>{
 for(const lang of ['it','en']){
  const response=await worker.fetch(request('/amazon?lang='+lang+'&tag=attacker-21&email=private@example.test'),{DB});
  assert.equal(response.status,200);const body=await response.text();
  const links=[...body.matchAll(/<a[^>]+data-affiliate="[^"]+"[^>]*>/g)].map(m=>m[0]);assert.equal(links.length,1);
  assert.match(links[0],/href="https:\/\/www.amazon.it\/joinstudent\?tag=seva0a9-21"/);
  assert.match(links[0],/rel="sponsored nofollow noopener"/);
  assert.match(links[0],/referrerpolicy="strict-origin-when-cross-origin"/);
  assert.ok(body.indexOf('In qualità di Affiliato Amazon')<body.indexOf('data-affiliate='));
  for(const privateValue of ['PRIVATE-OWNER','private@example.test','attacker-21','SEVA_SESSION'])assert.ok(!body.includes(privateValue));
  assert.ok(!/<(?:iframe|img)[^>]+amazon/i.test(body));
  assert.equal(body,await (await worker.fetch(new Request('https://seva.test/amazon?lang='+lang),{DB})).text());
 }
});
test('offline text and RSS promote the SEVA guide without distributing special affiliate links',async()=>{
 for(const lang of ['it','en']){
  const response=await worker.fetch(request('/amazon?lang='+lang+'&format=txt'),{DB});
  const txt=await response.text();assert.match(txt,/https:\/\/seva.karimkatlane0.chatgpt.site\/amazon/);assert.ok(!txt.includes('tag=seva0a9-21'));assert.match(txt,/Affiliato Amazon/);
  const rss=await (await worker.fetch(request('/alerts.xml?lang='+lang),{DB})).text();assert.ok(rss.includes('/amazon'));assert.ok(!rss.includes('tag='));
 }
});
test('guide has no mutation endpoint and leaves private profile access protected',async()=>{
 for(const method of ['POST','PUT','DELETE'])assert.equal((await worker.fetch(new Request('https://seva.test/amazon',{method}),{DB})).status,405);
 const head=await worker.fetch(new Request('https://seva.test/amazon',{method:'HEAD'}),{DB});assert.equal(head.status,200);assert.equal(await head.text(),'');
 assert.equal((await worker.fetch(new Request('https://seva.test/api/student'),{DB})).status,401);
 assert.equal((await worker.fetch(new Request('https://seva.test/app?section=students'),{DB})).status,302);
});
test('student pages and sitemap expose the localized guide and legal notices explain the affiliate link',async()=>{
 for(const lang of ['it','en']){
  const body=await (await worker.fetch(request('/students?lang='+lang),{DB})).text();assert.ok(body.includes('href="/amazon'+(lang==='en'?'?lang=en':'')+'"'));
  for(const page of ['privacy','cookies','terms'])assert.match(await (await worker.fetch(request('/'+page+'?lang='+lang),{DB})).text(),/Amazon/);
 }
 const xml=await (await worker.fetch(request('/sitemap.xml'),{DB})).text();assert.ok(xml.includes('/amazon?lang=en</loc><lastmod>2026-11-03'));
});
