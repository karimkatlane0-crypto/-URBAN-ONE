import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createContext,runInContext} from 'node:vm';
import {importAISource,AI_SOURCE_BYTES} from '../src/ai-sources.js';
const source=(text,name='source.txt')=>({name,text,size:new TextEncoder().encode(text).length});

test('text import preserves the existing goal and source text with provenance',()=>{
 const result=importAISource(source('Obiettivo: verificare il servizio.','note.md'),'Il mio piano');
 assert.equal(result.linkOnly,false);
 assert.match(result.brief,/^Il mio piano\n\n/);
 assert.ok(result.brief.endsWith('File: note.md\nObiettivo: verificare il servizio.'));
});
test('Gemini share files are references, never claimed to contain the conversation',()=>{
 const result=importAISource(source('\uFEFFhttps://gemini.google.com/share/705af63a174d\n'));
 assert.equal(result.linkOnly,true);
 assert.match(result.brief,/contenuto non acquisito/);
 assert.equal(importAISource(source('https://example.com\nTesto fornito')).linkOnly,false);
});
test('invalid and oversized files are rejected without truncation',()=>{
 for(const f of [source(''),source('abc','source.pdf'),source('a\u0000b'),source('a\uFFFDb'),source('a'.repeat(65537))])assert.throws(()=>importAISource(f));
 assert.throws(()=>importAISource(source('Aggiunta'),'a'.repeat(12000)),/nessun contenuto è stato tagliato/);
});
test('active markup and unsupported URL schemes stay plain reference text',()=>{
 const text='<script>alert(1)</script>\njavascript:alert(1)';
 const result=importAISource(source(text));
 assert.equal(result.linkOnly,false);assert.ok(result.brief.endsWith(text));
 assert.equal(importAISource(source('https://user:secret@example.com')).linkOnly,false);
});

const ui=await readFile(new URL('../src/contact-ui.js',import.meta.url),'utf8');
function harness(){
 let resolveText;
 const file={name:'example.txt',size:4,text:()=>new Promise(resolve=>{resolveText=resolve;})};
 const elements={'#personalBrief':{value:'Piano iniziale',isConnected:true},'#personalBriefStatus':{textContent:'',isConnected:true},'#personalBriefFile':{files:[file]},'#copyPersonalBrief':{},'#downloadPersonalBrief':{}};
 const context={$:selector=>elements[selector],pendingAIPrompt:'Piano iniziale',importAISource,AI_SOURCE_BYTES,navigator:{},download(){}};
 createContext(context);runInContext(ui,context);runInContext('bindPersonalAI()',context);
 return {elements,context,import:()=>elements['#personalBriefFile'].onchange(),finish:()=>resolveText('Nota')};
}
test('file reading preserves edits made while it is pending',async()=>{
 const h=harness(),pending=h.import();h.elements['#personalBrief'].value='Piano aggiornato';h.finish();await pending;
 assert.match(h.context.pendingAIPrompt,/^Piano aggiornato/);assert.match(h.context.pendingAIPrompt,/Nota$/);
});
test('file reading cannot change the next screen after navigating away',async()=>{
 const h=harness(),pending=h.import();h.elements['#personalBrief'].isConnected=false;h.context.pendingAIPrompt='Un altro compito';h.finish();await pending;
 assert.equal(h.context.pendingAIPrompt,'Un altro compito');
});
