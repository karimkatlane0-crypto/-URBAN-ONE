import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync,mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {handleService} from '../src/service-server.js';
import {validateTickets,starterPlan} from '../src/service.js';
const directory=mkdtempSync(join(tmpdir(),'seva-service-'));
let sql=new DatabaseSync(join(directory,'service.sqlite'));
for(const file of readdirSync('drizzle').filter(n=>n.endsWith('.sql')).sort())sql.exec(readFileSync('drizzle/'+file,'utf8'));
test.after(()=>{sql.close();rmSync(directory,{recursive:true});});
const DB={prepare(query){const s=sql.prepare(query);return {bind(...args){return {async first(){return s.get(...args)||null;},async run(){return {meta:{changes:Number(s.run(...args).changes)}};}};}};}};
const ticket=()=>({id:crypto.randomUUID(),title:'Problema pilota',description:'Il pulsante non risponde',category:'Servizio',status:'Aperta',resolution:'',createdAt:new Date().toISOString()});
const payload=(tickets,revision=0,operationId=crypto.randomUUID())=>({tickets,revision,operationId,consent:true});
const call=(owner,body,headers={})=>handleService(new Request('https://seva.test/api/service',{method:body?'POST':'GET',headers:{...(owner?{'oai-authenticated-user-id':owner}:{}),origin:'https://seva.test','content-type':'application/json',...headers},...(body?{body:JSON.stringify(body)}:{})}),{DB});
test('service requires identity, origin and consent and rejects forged owner',async()=>{
 assert.equal((await call(null)).status,401);
 for(const data of [{...payload([]),consent:false},{...payload([]),ownerId:'someone-else'}])assert.equal((await call('auth',data)).status,400);
 assert.equal((await call('auth',payload([]),{origin:'https://other.test'})).status,403);
 assert.equal((await call('auth',payload([]),{'content-type':'text/plain'})).status,415);
});
test('service persists across reopened SQLite and isolates accounts, including deletion',async()=>{
 const t=ticket();assert.equal((await call('alice',payload([t]))).status,200);
 sql.close();sql=new DatabaseSync(join(directory,'service.sqlite'));
 assert.deepEqual((await (await call('alice')).json()).tickets,[t]);
 assert.deepEqual((await (await call('bob')).json()).tickets,[]);
 assert.equal((await call('bob',payload([]))).status,200);
 assert.deepEqual((await (await call('alice')).json()).tickets,[t]);
 assert.equal((await call('alice',payload([],1))).status,200);
 assert.deepEqual((await (await call('alice')).json()).tickets,[]);
});
test('a request cannot be resolved without a documented solution',async()=>{
 const t={...ticket(),status:'Risolta'};assert.throws(()=>validateTickets([t]));
 assert.equal((await call('resolve',payload([t]))).status,400);
 t.resolution='Pulsante verificato il 2 novembre: salvataggio riuscito';
 assert.equal((await call('resolve',payload([t]))).status,200);
});
test('retry is idempotent, changed retry and stale revisions cannot overwrite',async()=>{
 const t=ticket(),body=payload([t],0,'retry-operation');
 assert.equal((await call('retry',body)).status,200);
 assert.equal((await (await call('retry',body)).json()).revision,1);
 assert.equal((await call('retry',{...body,tickets:[]})).status,409);
 assert.equal((await call('retry',payload([],0))).status,409);
 assert.deepEqual((await (await call('retry')).json()).tickets,[t]);
});
test('competing initial writes have one winner',async()=>{
 const results=await Promise.all([call('race',payload([ticket()])),call('race',payload([ticket()]))]);
 assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
});
test('invalid, duplicate and excessive tickets do not persist',async()=>{
 const t=ticket();
 for(const tickets of [[t,t],[{...t,contact:'unrequested'}],[{...t,title:''}],Array.from({length:201},ticket)])assert.equal((await call('invalid',payload(tickets))).status,400);
 assert.deepEqual((await (await call('invalid')).json()).tickets,[]);
});
test('starter plans are editable copies with concrete acceptance criteria',()=>{
 for(const kind of ['persona','negozio','servizio']){const p=starterPlan(kind);assert.equal(p.steps.length,4);assert.ok(p.criteria);for(const [title,criteria] of p.steps){assert.ok(title);assert.ok(criteria);}p.title='changed';assert.notEqual(starterPlan(kind).title,'changed');}
 assert.throws(()=>starterPlan('missing'));
});
