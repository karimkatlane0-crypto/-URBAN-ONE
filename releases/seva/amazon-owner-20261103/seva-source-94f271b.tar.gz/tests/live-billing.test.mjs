import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handleLiveBilling,liveBillingPreparation,normalizeLiveBillingEvent,ENTRY_TERMS_VERSION} from '../src/live-billing.js';
import {applyBillingEvent,billingEntitlements,paidCloudWriteGuard} from '../src/billing.js';
import worker from '../worker/index.js';

function fixture(overrides={}){
 const sql=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sql.exec(readFileSync('drizzle/'+f,'utf8'));
 const DB={prepare(query){const s=sql.prepare(query);const bound=args=>({async first(){return s.get(...args)||null;},async all(){return {results:s.all(...args)};},async run(){return {meta:{changes:Number(s.run(...args).changes)}};}});return {...bound([]),bind(...args){return bound(args);}};},async batch(statements){sql.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const config={accountId:'acct_1UQI83RzfcoKq6cn',priceId:'price_fixture',productId:'prod_fixture',amount:5000,currency:'eur',interval:'month',portalConfiguration:'bpc_fixture',enabled:true,taxVerified:true,fulfillmentVerified:true,termsPublished:ENTRY_TERMS_VERSION,...overrides};
 const env={DB,SEVA_LIVE_BILLING_CONFIG:JSON.stringify(config),STRIPE_RESTRICTED_KEY_LIVE:'rk_live_SYNTHETIC_NOT_A_REAL_KEY',STRIPE_WEBHOOK_SECRET_LIVE:'whsec_SYNTHETIC'};
 const calls=[],sessions=new Map();let sequence=0,fail=false;
 const fetcher=async(url,opts={})=>{
  calls.push({url,opts});const path=new URL(url).pathname,body=new URLSearchParams(opts.body||''),key=opts.headers?.['Idempotency-Key'];
  if(fail)return Response.json({error:{message:'sensitive provider error'}},{status:401});
  let result;
  if(path==='/v1/account')result={id:config.accountId,charges_enabled:true,payouts_enabled:true};
  else if(path==='/v1/prices/price_fixture')result={id:'price_fixture',active:true,livemode:true,product:'prod_fixture',unit_amount:5000,currency:'eur',type:'recurring',recurring:{interval:'month',interval_count:1,usage_type:'licensed'},tax_behavior:'inclusive'};
  else if(path==='/v1/products/prod_fixture')result={id:'prod_fixture',active:true,livemode:true,tax_code:'txcd_FIXTURE'};
  else if(path==='/v1/tax/settings')result={status:'active'};
  else if(path==='/v1/tax/registrations')result={data:[{status:'active'}]};
  else if(path==='/v1/billing_portal/configurations/bpc_fixture')result={active:true,livemode:true,features:{subscription_cancel:{enabled:true,mode:'at_period_end'}}};
  else if(path==='/v1/checkout/sessions'&&opts.method==='POST'){
   if(!sessions.has(key))sessions.set(key,{id:'cs_live_fixture'+(++sequence),mode:'subscription',status:'open',livemode:true,currency:'eur',amount_total:5000,client_reference_id:body.get('client_reference_id'),expires_at:Number(body.get('expires_at')),url:'https://checkout.stripe.com/c/pay/cs_live_fixture'+sequence});result=sessions.get(key);
  }else if(path.startsWith('/v1/checkout/sessions/'))result=[...sessions.values()].find(s=>path.endsWith(s.id));
  else if(path==='/v1/billing_portal/sessions')result={url:'https://billing.stripe.com/p/session/fixture'};
  else throw Error('Unexpected fixture path '+path);
  return Response.json(result);
 };
 const request=(body,origin='https://seva.test',path='/api/billing/live-checkout')=>new Request('https://seva.test'+path,{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
 const body=()=>({operationId:crypto.randomUUID(),consent:true,termsVersion:ENTRY_TERMS_VERSION});
 const call=(b=body(),user='alice',origin)=>handleLiveBilling(request(b,origin),env,user?{id:user,isOwner:false}:null,fetcher);
 return {sql,DB,env,config,fetcher,calls,sessions,request,body,call,setFailure:()=>{fail=true;}};
}
test('missing prerequisites, forged input and foreign origins never contact Stripe',async()=>{
 const f=fixture();try{
  for(const [body,status]of [[null,400],[[],400],[{...f.body(),amount:1},400],[{...f.body(),customer:'cus_other'},400],[{...f.body(),consent:false},400],[{...f.body(),termsVersion:'old'},400]])assert.equal((await f.call(body)).status,status);
  assert.equal((await f.call(f.body(),null)).status,401);assert.equal((await f.call(f.body(),'alice','https://other.test')).status,403);
  for(const key of ['STRIPE_RESTRICTED_KEY_LIVE','STRIPE_WEBHOOK_SECRET_LIVE','SEVA_LIVE_BILLING_CONFIG']){const value=f.env[key];delete f.env[key];assert.equal(liveBillingPreparation(f.env).ready,false);assert.equal((await f.call()).status,503);f.env[key]=value;}
  assert.equal(f.calls.length,0);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM seva_billing_intents').get().n,0);
 }finally{f.sql.close();}
});
test('simultaneous requests create one fixed account-bound Checkout with dynamic methods',async()=>{
 const f=fixture();try{
  const results=await Promise.all([f.call(),f.call(),f.call()]);for(const r of results)assert.equal(r.status,200);assert.equal(f.sessions.size,1);assert.equal(f.sql.prepare('SELECT COUNT(*) n FROM seva_billing_intents').get().n,1);
  const c=f.calls.find(c=>c.opts.method==='POST'),b=new URLSearchParams(c.opts.body);assert.equal(b.get('line_items[0][price]'),'price_fixture');assert.equal(b.get('line_items[0][quantity]'),'1');assert.equal(b.get('mode'),'subscription');assert.equal(b.get('automatic_tax[enabled]'),'true');assert.equal(b.has('payment_method_types'),false);assert.equal(b.has('customer_email'),false);assert.ok(!c.opts.body.includes('alice'));assert.match(b.get('integration_identifier'),/^seva_entry_[a-z]{8}$/);
  const retry=await f.call();assert.equal(retry.status,200);assert.equal(f.sessions.size,1);
  await f.call(f.body(),'bob');assert.equal(f.sessions.size,2);
  const pendingTax=async(url,opts)=>{const response=await f.fetcher(url,opts);if(new URL(url).pathname==='/v1/checkout/sessions'&&opts.method==='POST'){const v=await response.json();return Response.json({...v,amount_total:null,amount_subtotal:5000,automatic_tax:{enabled:true,status:'requires_location_inputs'}});}return response;};
  assert.equal((await handleLiveBilling(f.request(f.body()),f.env,{id:'carol'},pendingTax)).status,200);
 }finally{f.sql.close();}
});
test('provider account, inclusive price and tax failures prevent session creation',async()=>{
 for(const kind of ['account','price','tax','portal']){
  const f=fixture();try{const fake=async(url,o)=>{
   if(kind==='account'&&url.endsWith('/v1/account'))return Response.json({id:'acct_wrong',charges_enabled:true,payouts_enabled:true});
   if(kind==='price'&&url.endsWith('/prices/price_fixture'))return Response.json({id:'price_fixture',active:true,unit_amount:1});
   if(kind==='tax'&&url.includes('/tax/registrations'))return Response.json({data:[]});
   if(kind==='portal'&&url.includes('/billing_portal/configurations'))return Response.json({active:true,livemode:true,features:{subscription_cancel:{enabled:false}}});
   return f.fetcher(url,o);
  };assert.equal((await handleLiveBilling(f.request(f.body()),f.env,{id:'alice'},fake)).status,503);assert.equal(f.sessions.size,0);}finally{f.sql.close();}
 }
});
test('completed session and provider failures cannot create a second charge opportunity',async()=>{
 const f=fixture();try{await f.call();f.sessions.values().next().value.status='complete';assert.equal((await f.call()).status,409);assert.equal(f.sessions.size,1);const intent=f.sql.prepare('SELECT * FROM seva_billing_intents').get();
 f.sql.prepare("INSERT INTO seva_billing_subscriptions(id,mode,owner_id,status,canceled) VALUES('sub_ended','live','alice','canceled',1)").run();
 f.sql.prepare("UPDATE seva_billing_intents SET subscription_id='sub_ended' WHERE token=?").run(intent.token);
 assert.equal((await f.call()).status,200);assert.equal(f.sessions.size,2);
 f.setFailure();const r=await f.call();assert.equal(r.status,503);assert.ok(!(await r.text()).includes('sensitive provider error'));}finally{f.sql.close();}
});
test('a paid invoice and exact signed-session binding are required for LIVE entitlement',async()=>{
 const f=fixture();try{
  await f.call();const intent=f.sql.prepare('SELECT * FROM seva_billing_intents').get(),now=intent.created_at;
  const event=(type,object)=>({id:'evt_'+crypto.randomUUID(),livemode:true,created:now,type,data:{object}});
  const checkout={id:intent.session_id,mode:'subscription',status:'complete',payment_status:'paid',client_reference_id:intent.token,subscription:'sub_live',customer:'cus_live',currency:'eur',amount_total:5000,created:now};
  await applyBillingEvent(f.DB,event('customer.subscription.created',{id:'sub_live',customer:'cus_live',status:'active',items:{data:[{price:{id:'price_fixture'},quantity:1}]}}),f.env,'live');
  await applyBillingEvent(f.DB,event('invoice.paid',{id:'in_live',parent:{subscription_details:{subscription:'sub_live'}},status:'paid',paid:true,amount_paid:5000,amount_remaining:0,currency:'eur',payment_intent:'pi_live',lines:{data:[{pricing:{price_details:{price:'price_fixture'}},quantity:1,period:{start:now,end:now+3600}}]}}),f.env,'live');
  for(const change of [{id:'cs_live_other'},{payment_status:'unpaid'},{amount_total:1},{payment_link:'plink_other'}]){await applyBillingEvent(f.DB,event('checkout.session.completed',{...checkout,...change}),f.env,'live');assert.deepEqual(await billingEntitlements(f.DB,'alice','live'),[]);}
  await applyBillingEvent(f.DB,event('checkout.session.completed',checkout),f.env,'live');assert.equal((await billingEntitlements(f.DB,'alice','live')).length,1);assert.deepEqual(await billingEntitlements(f.DB,'bob','live'),[]);
  await applyBillingEvent(f.DB,event('radar.early_fraud_warning.created',{id:'issfr_fixture',payment_intent:'pi_live'}),f.env,'live');assert.deepEqual(await billingEntitlements(f.DB,'alice','live'),[]);
 }finally{f.sql.close();}
});
test('portal binds the stored customer and remains available when new sales are disabled',async()=>{
 const f=fixture({enabled:false});try{
  f.sql.prepare("INSERT INTO seva_billing_subscriptions(id,mode,owner_id,customer_id) VALUES('sub_a','live','alice','cus_alice')").run();
  const request=f.request({operationId:crypto.randomUUID()},undefined,'/api/billing/portal');
  const result=await handleLiveBilling(request,f.env,{id:'alice'},f.fetcher);assert.equal(result.status,200);const call=f.calls.find(c=>c.url.endsWith('/billing_portal/sessions'));assert.equal(new URLSearchParams(call.opts.body).get('customer'),'cus_alice');
  assert.equal((await handleLiveBilling(f.request({operationId:crypto.randomUUID()},undefined,'/api/billing/portal'),f.env,{id:'bob'},f.fetcher)).status,404);
 }finally{f.sql.close();}
});
test('cloud write gate preserves reading and deletion without granting unpaid writes',async()=>{
 const f=fixture();try{for(const method of ['GET','HEAD','DELETE'])assert.equal(await paidCloudWriteGuard(new Request('https://seva.test/api/goals',{method}),f.env,{id:'alice'}),null);
 assert.equal((await paidCloudWriteGuard(new Request('https://seva.test/api/goals',{method:'PUT'}),f.env,{id:'alice'})).status,402);
 assert.equal(await paidCloudWriteGuard(new Request('https://seva.test/api/goals',{method:'PUT'}),{}, {id:'alice'}),null);
 }finally{f.sql.close();}
});
test('risk resolution follows all invoice payment pages and invoice payment is verified',async()=>{
 const f=fixture();try{
  let pages=0;const fake=async(url,o)=>{
   if(url.includes('/invoice_payments?invoice='))return Response.json({data:[{livemode:true,status:'paid',invoice:'in_paid',amount_paid:5000,currency:'eur',payment:{type:'payment_intent',payment_intent:'pi_fixture'}}],has_more:false});
   if(url.includes('/invoice_payments?'))return Response.json({data:[{id:'inpay_'+(++pages),livemode:true,status:'paid',invoice:'in_'+pages,payment:{payment_intent:'pi_fixture'}}],has_more:pages===1});
   if(url.includes('/charges/'))return Response.json({livemode:true,payment_intent:'pi_fixture'});return f.fetcher(url,o);
  };
  const risk=await normalizeLiveBillingEvent({type:'radar.early_fraud_warning.created',data:{object:{id:'issfr_fixture',charge:'ch_fixture'}}},f.env,fake);assert.deepEqual(risk.data.object.seva_invoice_ids,['in_1','in_2']);
  const paid=await normalizeLiveBillingEvent({type:'invoice.paid',data:{object:{id:'in_paid',status:'paid'}}},f.env,fake);assert.equal(paid.data.object.paid,true);assert.equal(paid.data.object.payment_intent,'pi_fixture');
 }finally{f.sql.close();}
});
test('public routes cannot bypass signed-in workspace checks or reveal readiness details',async()=>{
 const f=fixture();try{
  assert.equal((await worker.fetch(f.request(f.body()),f.env)).status,401);
  assert.equal((await worker.fetch(new Request('https://seva.test/api/billing/live-checkout',{method:'POST',headers:{'oai-authenticated-user-id':'alice'},body:'{}'}),f.env)).status,409);
 }finally{f.sql.close();}
});
