import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {Script} from 'node:vm';
import worker from '../worker/index.js';
import {requestIdentity,browserIdentity,browserSessionJSON} from '../src/identity.js';
const sql=new DatabaseSync(':memory:');
for(const file of readdirSync('drizzle').filter(n=>n.endsWith('.sql')).sort())sql.exec(readFileSync('drizzle/'+file,'utf8'));
test.after(()=>sql.close());
const DB={prepare(query){const s=sql.prepare(query);const bound=args=>({async first(){return s.get(...args)||null;},async all(){return {results:s.all(...args)};},async run(){return {meta:{changes:Number(s.run(...args).changes)}};}});return {...bound([]),bind(...args){return bound(args);}};}};
async function call(path,{user='alice',email='alice@example.test',method='GET',body,scope,origin='https://seva.test'}={}){
 const namespace=user?(await browserIdentity({id:user,isOwner:false})).scope:'';
 return worker.fetch(new Request('https://seva.test'+path,{method,headers:{...(user?{'oai-authenticated-user-id':user,'oai-authenticated-user-email':email}:{}),'X-SEVA-Workspace':scope??namespace,origin,'content-type':'application/json'},...(body?{body:JSON.stringify(body)}:{})}),{DB,OPENAI_API_KEY:'unused-owner-secret',SEVA_AI_BILLING_MODE:'owner-test'});
}
const draft=(message='A synthetic request')=>({id:crypto.randomUUID(),category:'Community',name:'Synthetic tester',message,consent:true});
test('anonymous visitors see landing, never workspace or private release',async()=>{
 const landing=await call('/',{user:null});assert.equal(landing.status,200);const text=await landing.text();assert.match(text,/OMNIBUS OMNIA/);assert.ok(!text.includes('seva.workspace.v1'));assert.ok(!text.includes('unused-owner-secret'));assert.ok(!text.includes('client_secret'));
 const script=text.match(/<script>([\s\S]*?)<\/script>/)?.[1];assert.ok(script);assert.doesNotThrow(()=>new Script(script));
 const app=await call('/app',{user:null});assert.equal(app.status,302);assert.equal(app.headers.get('Location'),'/signin-with-chatgpt?return_to=%2Fapp');
 const community=await call('/app?section=community',{user:null});assert.equal(community.headers.get('Location'),'/signin-with-chatgpt?return_to=%2Fapp%3Fsection%3Dcommunity');
 const invalid=await call('/app?section=https://attacker.test',{user:null});assert.equal(invalid.headers.get('Location'),'/signin-with-chatgpt?return_to=%2Fapp');
 assert.equal((await call('/api/release',{user:null})).status,403);
 for(const path of ['/api/goals','/api/student','/api/service','/api/inquiries'])assert.equal((await call(path,{user:null})).status,401);
});
test('public AI cannot consume owner credit even with an owner-test environment',async()=>{
 assert.equal((await call('/api/ai',{user:null,method:'POST',body:{prompt:'test',consent:true}})).status,401);
 const r=await call('/api/ai',{method:'POST',body:{prompt:'test',consent:true}});assert.equal(r.status,409);assert.equal((await r.json()).code,'personal_ai_account_required');
});
test('workspace scopes differ and stale identity headers block personal data',async()=>{
 const a=await browserIdentity({id:'alice',isOwner:false}),b=await browserIdentity({id:'bob',isOwner:false});assert.notEqual(a.scope,b.scope);
 assert.equal((await call('/api/goals',{user:'bob',scope:a.scope})).status,409);
 assert.equal((await call('/api/service',{user:'bob',scope:''})).status,409);
 const html=await (await call('/app')).text();assert.ok(html.includes(a.scope));assert.ok(!html.includes('/*SESSION_DATA*/null'));assert.ok(html.includes('isOwner":false'));assert.doesNotThrow(()=>new Script(html.match(/<script type="module">([\s\S]*?)<\/script>/)[1]));
 assert.equal(requestIdentity(new Request('https://seva.test',{headers:{'oai-authenticated-user-email':'karimkatlane0@gmail.com'}})),null);
 assert.ok(!browserSessionJSON({scope:'</script><script>',isOwner:false}).includes('<'));
});
test('inquiries deliver privately to the owner and responses return only to the sender',async()=>{
 const body=draft();assert.equal((await call('/api/inquiries',{method:'POST',body})).status,201);
 assert.equal((await call('/api/inquiries',{method:'POST',body})).status,200);
 const own=await (await call('/api/inquiries')).json();assert.equal(own.items.length,1);assert.equal(own.items[0].id,body.id);
 assert.deepEqual((await (await call('/api/inquiries',{user:'bob'})).json()).items,[]);
 assert.equal((await call('/api/inquiries',{user:'bob',method:'PATCH',body:{id:body.id,revision:1,response:'forged',status:'Risposta disponibile'}})).status,403);
 const owner={user:'owner-site-id',email:'karimkatlane0@gmail.com'};const inbox=await (await call('/api/inquiries',owner)).json();assert.equal(inbox.isOwner,true);assert.equal(inbox.items[0].id,body.id);
 assert.equal((await call('/api/inquiries',{...owner,method:'PATCH',body:{id:body.id,revision:1,response:'Synthetic reply',status:'Risposta disponibile'}})).status,200);
 assert.equal((await (await call('/api/inquiries')).json()).items[0].response,'Synthetic reply');
 assert.deepEqual((await (await call('/api/inquiries',{user:'bob'})).json()).items,[]);
 assert.equal((await call('/api/inquiries',{user:'bob',method:'DELETE',body:{id:body.id,revision:2}})).status,409);
 assert.equal((await call('/api/inquiries',{method:'DELETE',body:{id:body.id,revision:1}})).status,409);
 assert.equal((await call('/api/inquiries',{method:'DELETE',body:{id:body.id,revision:2}})).status,200);
});
test('inquiries reject wrong origin, missing consent, extra owner fields and conflicting retries',async()=>{
 const body=draft();
 assert.equal((await call('/api/inquiries',{method:'POST',body,origin:'https://attacker.test'})).status,403);
 assert.equal((await call('/api/inquiries',{method:'POST',body:{...body,consent:false}})).status,400);
 assert.equal((await call('/api/inquiries',{method:'POST',body:{...body,owner_id:'bob'}})).status,400);
 assert.equal((await call('/api/inquiries',{method:'POST',body})).status,201);
 assert.equal((await call('/api/inquiries',{method:'POST',body:{...body,message:'changed'}})).status,409);
 assert.equal((await call('/api/inquiries',{user:'bob',method:'POST',body})).status,409);
});
test('legacy local data is scoped to authenticated owner and personal storage keys differ',async()=>{
 const html=await (await call('/app')).text();
 assert.match(html,/seva\.workspace\.v2\.'\+window\.SEVA_SESSION\.scope/);
 assert.match(html,/if\(window\.SEVA_SESSION\.isOwner&&!localStorage\.getItem\(KEY\)\)/);
 assert.match(html,/seva\.goal-relay\.v2\.'\+window\.SEVA_SESSION\.scope/);
 const owner=await (await call('/app',{user:'owner',email:'karimkatlane0@gmail.com'})).text();assert.ok(owner.includes('isOwner":true'));
});
