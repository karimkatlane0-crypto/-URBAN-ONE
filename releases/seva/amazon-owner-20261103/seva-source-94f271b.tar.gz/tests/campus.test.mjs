import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker/index.js';

test('public student feed never accesses private profiles or reflects identity and arbitrary query data',async()=>{
 const DB={prepare(){throw Error('Public RSS must not read private records');}};
 for(const lang of ['it','en']){
  const request=new Request('https://seva.test/alerts.xml?lang='+lang+'&studentNumber=PRIVATE-123&email=private@example.test',{headers:{'oai-authenticated-user-id':'private-user-id','oai-authenticated-user-email':'private@example.test'}});
  const response=await worker.fetch(request,{DB});assert.equal(response.status,200);
  assert.match(response.headers.get('Content-Type'),/application\/rss\+xml/);
  const body=await response.text();
  assert.ok(body.startsWith('<?xml version="1.0" encoding="UTF-8"?>'));
  assert.ok(body.includes('<language>'+lang+'</language>'));
  assert.ok(body.includes('<guid isPermaLink="false">'));
  assert.ok(!body.includes('PRIVATE-123'));assert.ok(!body.includes('private@example.test'));assert.ok(!body.includes('private-user-id'));
  const anonymous=await (await worker.fetch(new Request('https://seva.test/alerts.xml?lang='+lang),{DB})).text();assert.equal(body,anonymous);
 }
});
test('RSS uses a stable language fallback and GET/HEAD only',async()=>{
 const call=(path,method='GET')=>worker.fetch(new Request('https://seva.test'+path,{method}),{});
 const normal=await (await call('/alerts.xml')).text();
 assert.equal(await (await call('/alerts.xml?lang=%22%3E%3Cscript%3E')).text(),normal);
 const head=await call('/alerts.xml','HEAD');assert.equal(head.status,200);assert.equal(await head.text(),'');assert.match(head.headers.get('Content-Type'),/application\/rss\+xml/);
 for(const method of ['POST','PUT','DELETE']){const r=await call('/alerts.xml',method);assert.equal(r.status,405);assert.equal(r.headers.get('Allow'),'GET, HEAD');}
});
test('student entry preserves sign-in boundary, feed discovery and factual availability in both languages',async()=>{
 const entry=await worker.fetch(new Request('https://seva.test/app?section=students'),{});
 assert.equal(entry.status,302);assert.equal(entry.headers.get('Location'),'/signin-with-chatgpt?return_to=%2Fapp%3Fsection%3Dstudents');
 assert.equal((await worker.fetch(new Request('https://seva.test/api/student'),{})).status,401);
 for(const lang of ['it','en']){
  const response=await worker.fetch(new Request('https://seva.test/students?lang='+lang),{});const page=await response.text();
  assert.ok(page.includes('href="/app?section=students"'));assert.ok(page.includes('type="application/rss+xml"'));
  assert.ok(page.includes(lang==='en'?'SPID sign-in is not active':'Accesso SPID non attivo'));assert.ok(!page.includes('<form'));
  const txt=await (await worker.fetch(new Request('https://seva.test/broadcast?lang='+lang+'&format=txt'),{})).text();
  assert.ok(txt.includes('https://www.ox.ac.uk/research/collaborate-with-us'));assert.ok(txt.includes('https://www.cam.ac.uk/business-and-enterprise/contact-us/contact-business-team'));
 }
});
