import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker/index.js';
import {clearLocalWorkspace} from '../src/local-privacy.js';

test('local erasure removes current account copies without deleting other accounts or settings',()=>{
 const a='a'.repeat(64),b='b'.repeat(64),data=new Map([
  ['seva.workspace.v2.'+a,'private A'],['seva.goal-relay.v2.'+a,'sync A'],['seva.goal-relay.conflict-backup.'+a,'backup A'],
  ['seva.workspace.v2.'+b,'private B'],['seva.goal-relay.v2.'+b,'sync B'],['seva.workspace.v1','owner legacy'],['other-app','keep']
 ]);
 clearLocalWorkspace({removeItem:k=>data.delete(k)},{scope:a,isOwner:false});
 assert.equal(data.size,4);assert.equal(data.get('seva.workspace.v2.'+b),'private B');assert.equal(data.get('seva.goal-relay.v2.'+b),'sync B');assert.equal(data.get('seva.workspace.v1'),'owner legacy');assert.equal(data.get('other-app'),'keep');
});
test('owner erasure prevents deleted legacy records from being imported again',()=>{
 const scope='c'.repeat(64),data=new Map([['seva.workspace.v1','old'],['seva.workspace.v2.'+scope,'new']]);
 clearLocalWorkspace({removeItem:k=>data.delete(k)},{scope,isOwner:true});
 assert.equal(data.size,0);
});
test('invalid local erasure session performs no deletions',()=>{
 let calls=0;const storage={removeItem:()=>calls++};
 for(const session of [null,{scope:''},{scope:'a'.repeat(63)},{scope:'../another-account',isOwner:true}])assert.throws(()=>clearLocalWorkspace(storage,session));
 assert.equal(calls,0);
});
test('public legal and partner documents render both languages without granting workspace access',async()=>{
 for(const path of ['/amazon','/join','/support','/growth','/network','/payments','/sports','/creators','/campaigns','/students','/alerts','/broadcast','/terms','/privacy','/cookies','/partners','/developers','/press']){
  for(const lang of ['it','en']){
   const r=await worker.fetch(new Request('https://seva.test'+path+'?lang='+lang),{});assert.equal(r.status,200);
   const text=await r.text();assert.ok(text.includes('<html lang="'+lang+'">'));assert.ok(text.includes('karimkatlane0@gmail.com'));assert.ok(!text.includes('SEVA_SESSION'));
   assert.match(r.headers.get('Content-Security-Policy'),/connect-src 'self'/);
  }
 }
 const injected=await (await worker.fetch(new Request('https://seva.test/privacy?lang=%3Cscript%3E'),{})).text();assert.ok(injected.includes('<html lang="it">'));assert.ok(!injected.includes('<html lang="<script>'));
 assert.equal((await worker.fetch(new Request('https://seva.test/privacy',{method:'POST'}),{})).status,405);
 assert.equal((await worker.fetch(new Request('https://seva.test/app'),{})).status,302);
 assert.equal((await worker.fetch(new Request('https://seva.test/api/inquiries'),{})).status,401);
});
test('public downloads contain readable notice and full links; sitemap excludes private paths',async()=>{
 const r=await worker.fetch(new Request('https://seva.test/privacy?lang=en&format=txt'),{});
 assert.match(r.headers.get('Content-Type'),/text\/plain/);assert.match(r.headers.get('Content-Disposition'),/attachment/);
 const txt=await r.text();assert.ok(txt.startsWith('Privacy notice'));assert.ok(txt.includes('https://seva.karimkatlane0.chatgpt.site/app?section=contact'));assert.ok(!txt.includes('<table>'));
 const xml=await (await worker.fetch(new Request('https://seva.test/sitemap.xml'),{})).text();assert.equal((xml.match(/<url>/g)||[]).length,38);assert.ok(!xml.includes('/app'));assert.ok(!xml.includes('/api/'));assert.ok(xml.includes('/terms?lang=en'));
 const facts=await (await worker.fetch(new Request('https://seva.test/llms.txt'),{})).text();assert.ok(facts.includes('commercial LIVE sales unavailable'));
});
test('the first-step promotion is public, bilingual and does not imply a paid offer',async()=>{
 const it=await (await worker.fetch(new Request('https://seva.test/join'),{})).text();
 assert.match(it,/SETTIMANA DEL PRIMO PASSO/);assert.match(it,/3 al 9 novembre 2026/);assert.match(it,/Non è richiesta una carta/);
 const en=await (await worker.fetch(new Request('https://seva.test/join?lang=en'),{})).text();
 assert.match(en,/FIRST STEP WEEK/);assert.match(en,/3 to 9 November 2026/);assert.match(en,/No card is required/);
 for(const html of [it,en]){assert.match(html,/\/app\?section=home/);assert.ok(!html.includes('Buy now'));assert.ok(!html.includes('Acquista ora'));}
});
