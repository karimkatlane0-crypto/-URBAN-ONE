import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import worker from '../worker/index.js';
const owner={'oai-authenticated-user-id':'synthetic-owner','oai-authenticated-user-email':'karimkatlane0@gmail.com'};
const other={'oai-authenticated-user-id':'synthetic-reader','oai-authenticated-user-email':'reader@example.test'};
const DB={prepare(){throw Error('Amazon setup must not read private records');}};
const request=(path,headers={},method='GET')=>new Request('https://seva.test'+path,{headers,method});

test('Amazon setup requires the owner and preserves only the supported language at sign-in',async()=>{
 for(const lang of ['it','en']){
  const r=await worker.fetch(request('/amazon/setup?lang='+lang+'&return_to=https://evil.test&tag=evil'),{DB});
  assert.equal(r.status,302);assert.equal(r.headers.get('Cache-Control'),'no-store');
  const target=new URL(r.headers.get('Location'),'https://seva.test');
  assert.equal(target.pathname,'/signin-with-chatgpt');
  assert.equal(target.searchParams.get('return_to'),'/amazon/setup'+(lang==='en'?'?lang=en':''));
 }
 const denied=await worker.fetch(request('/amazon/setup',other),{DB});
 assert.equal(denied.status,403);assert.ok(!(await denied.text()).includes('amazon-site'));
 const fakeOwner=await worker.fetch(request('/amazon/setup',{'oai-authenticated-user-email':owner['oai-authenticated-user-email']}),{DB});
 assert.equal(fakeOwner.status,302);
});

test('owner setup is read-only, uncached and never reflects credentials or query input',async()=>{
 for(const lang of ['it','en']){
  const r=await worker.fetch(request('/amazon/setup?lang='+lang+'&site=PRIVATE-VALUE&tag=evil',owner),{DB});
  assert.equal(r.status,200);assert.equal(r.headers.get('Cache-Control'),'no-store');
  assert.match(r.headers.get('X-Robots-Tag'),/noindex/);assert.equal(r.headers.get('Referrer-Policy'),'no-referrer');
  const html=await r.text();assert.ok(html.includes('lang="'+lang+'"'));
  assert.ok(html.includes('value="https://seva.karimkatlane0.chatgpt.site"'));
  for(const value of ['PRIVATE-VALUE','synthetic-owner','karimkatlane0@gmail.com','tag=evil','sk_live_','whsec_'])assert.ok(!html.includes(value));
  assert.ok(!/<form|type="password"|<iframe/i.test(html));
  assert.match(html,lang==='en'?/Missing data does not mean zero sales/:/Dati mancanti non significano zero vendite/);
  assert.match(html,lang==='en'?/Account settings not verified/:/Impostazioni del conto non verificate/);
  for(const m of html.matchAll(/href="(https:[^"]+)"/g))assert.ok(['programma-affiliazione.amazon.it'].includes(new URL(m[1]).hostname));
 }
 for(const method of ['POST','PUT','DELETE'])assert.equal((await worker.fetch(request('/amazon/setup',owner,method),{DB})).status,405);
 const head=await worker.fetch(request('/amazon/setup',owner,'HEAD'),{DB});assert.equal(head.status,200);assert.equal(await head.text(),'');
});

test('copy-site control copies the canonical site and offers selectable text if clipboard is unavailable',async()=>{
 for(const lang of ['it','en'])for(const fail of [false,true]){
  const html=await (await worker.fetch(request('/amazon/setup?lang='+lang,owner),{DB})).text();
  const script=html.match(/<script>([\s\S]+?)<\/script>/)[1];
  let copied=null,focused=false,selected=false;
  const elements={'copy-site':{},'amazon-site':{value:'https://seva.karimkatlane0.chatgpt.site',focus(){focused=true;},select(){selected=true;}},'copy-status':{textContent:''}};
  vm.runInNewContext(script,{document:{getElementById:id=>elements[id]},navigator:{clipboard:{async writeText(value){if(fail)throw Error('denied');copied=value;}}}});
  await elements['copy-site'].onclick();
  assert.ok(elements['copy-status'].textContent.length>0);
  if(fail){assert.ok(focused&&selected);assert.equal(copied,null);}else assert.equal(copied,elements['amazon-site'].value);
 }
});

test('private setup stays out of public discovery and the existing student affiliate destination is unchanged',async()=>{
 for(const path of ['/sitemap.xml','/llms.txt','/amazon','/amazon?lang=en','/alerts.xml']){
  const html=await (await worker.fetch(request(path),{DB})).text();assert.ok(!html.includes('/amazon/setup'));
  if(path.startsWith('/amazon'))assert.match(html,/https:\/\/www.amazon.it\/joinstudent\?tag=seva0a9-21/);
 }
});
