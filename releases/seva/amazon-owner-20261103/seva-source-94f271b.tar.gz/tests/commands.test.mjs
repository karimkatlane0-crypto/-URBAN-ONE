import test from 'node:test';
import assert from 'node:assert/strict';
import {COMMAND_COUNT,commandAt,findCommands,commandPrompt} from '../src/commands.js';
import worker from '../worker/index.js';
import {Script} from 'node:vm';

test('the command library contains 10000 unique bounded combinations, not executed jobs',()=>{
 const ids=new Set(),specs=new Set();
 for(let i=0;i<COMMAND_COUNT;i++){
  const c=commandAt(i);ids.add(c.id);specs.add([c.domain,c.action,c.method,c.format].join(':'));
  assert.ok(commandPrompt(i,'Contesto di prova').length<12000);
 }
 assert.equal(ids.size,10000);assert.equal(specs.size,10000);
 assert.equal(commandAt(0).id,'SEVA-C00001');assert.equal(commandAt(9999).id,'SEVA-C10000');
 assert.throws(()=>commandAt(10000));assert.throws(()=>commandPrompt(0,'x'.repeat(6001)));
});
test('command search, accent folding, domain filters and pagination preserve counts',()=>{
 assert.equal(findCommands({domain:'3'}).total,1000);
 assert.equal(findCommands({query:'profondita'}).total,1000);
 const page=findCommands({offset:9990});assert.equal(page.items.length,10);assert.equal(page.nextOffset,null);
 assert.equal(findCommands({query:'SEVA-C10000'}).items[0].index,9999);
 assert.equal(findCommands({query:'no-such-fixture'}).total,0);
 assert.throws(()=>findCommands({limit:100}));assert.throws(()=>findCommands({offset:-1}));
});
test('the delivered CSV implementation preserves formula prefixes while neutralizing them',async()=>{
 const response=await worker.fetch(new Request('https://seva.test/app',{headers:{'oai-authenticated-user-id':'csv-test'}}));
 const html=await response.text();
  const script=html.match(/<script type="module">([\s\S]*?)<\/script>/)?.[1];
  assert.ok(script);assert.doesNotThrow(()=>new Script(script));
 const line=html.split('\n').find(line=>line.startsWith('function csv(rows)'));
 assert.ok(line,'CSV function must be present in delivered script');
 const deliveredCSV=Function(line+'; return csv;')();
 assert.equal(deliveredCSV([['=1+1','+2','@name','-3','a"b']]),'"\'=1+1","\'+2","\'@name","\'-3","a""b"');
 assert.equal(deliveredCSV([['\t=1+1']]),'\"\'\t=1+1\"');
 assert.ok(!html.includes('/*APP*/'));
 assert.ok(html.includes('SEVA-C'));
});
