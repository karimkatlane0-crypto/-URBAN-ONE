import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createContext,runInContext} from 'node:vm';
import {task,validateGoals,goalCanonical,mergeGoalTrees,setStatus,flatten} from '../src/model.js';
const source=await readFile(new URL('../src/goal-sync-ui.js',import.meta.url),'utf8');

function harness(){
 const goal={...task('Goal'),criteria:'before'},fields={title:{value:goal.title},criteria:{value:goal.criteria},evidence:{value:''},status:{value:goal.status}};
 const labels=Object.values(fields).map(input=>({tagName:'LABEL',querySelector(){return input;}}));
 const card={dataset:{task:goal.id},querySelector(){return {children:labels};}};
 const storage=new Map(),elements={'#syncGoals':{disabled:false},'#goalSyncStatus':{textContent:''}};
 let remote={ownerId:'fixture-owner',revision:0,goals:[],updatedAt:null},accept,posted;
 const postStarted=new Promise(resolve=>{posted=resolve;});
 const context={window:{SEVA_SESSION:{scope:'test-scope'}},console,crypto,structuredClone,AbortSignal,Response,setTimeout,clearTimeout,validateGoals,goalCanonical,mergeGoalTrees,flatten,
  page:'goals',state:{goals:[goal]},navigator:{onLine:true},renderCount:0,saveCount:0,
  localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,value)=>storage.set(key,value)},
  $:selector=>elements[selector],document:{querySelectorAll:()=>context.page==='goals'?[card]:[]},
  E:value=>String(value),modal(){throw Error('Unexpected conflict');},download(){},
  capture(){const node=context.state.goals[0];node.title=fields.title.value.trim();node.criteria=fields.criteria.value;node.evidence=fields.evidence.value;setStatus(node,fields.status.value);return node;},
  save(){context.saveCount++;return true;},
  render(){context.renderCount++;fields.criteria.value=context.state.goals[0]?.criteria||'';},
  async sevaFetch(path,options={}){
   if(options.method!=='POST')return Response.json(remote);
   const body=JSON.parse(options.body);context.sent=body;
   remote={ownerId:'fixture-owner',revision:remote.revision+1,goals:body.goals,updatedAt:'2026-10-31T00:00:00Z'};
   posted();return new Promise(resolve=>{accept=()=>resolve(Response.json(remote));});
  }
 };
 createContext(context);runInContext(source,context);
 return {context,fields,postStarted,accept:()=>accept(),sync:()=>runInContext('goalSyncConsent=true; synchronizeGoals()',context),meta:()=>runInContext('goalSyncMeta',context),status:()=>elements['#goalSyncStatus'].textContent};
}

test('a late cloud acknowledgement preserves editor text changed while the request is in flight',async()=>{
 const h=harness(),pending=h.sync();await h.postStarted;
 h.fields.criteria.value='typed during the request';h.accept();await pending;
 assert.equal(h.context.sent.goals[0].criteria,'before');
 assert.equal(h.fields.criteria.value,'typed during the request');
 assert.equal(h.context.renderCount,0);assert.equal(h.meta(),null);
 assert.match(h.status(),/campi|modificat/i);
});
test('explicit goal sync includes current valid editor values before sending the snapshot',async()=>{
 const h=harness();h.fields.criteria.value='edited before sync';
 const pending=h.sync();await h.postStarted;h.accept();await pending;
 assert.equal(h.context.sent.goals[0].criteria,'edited before sync');
 assert.equal(h.meta().revision,1);assert.equal(h.context.state.goals[0].criteria,'edited before sync');
});
test('navigation during a pending sync does not redraw a different page or advance its local base',async()=>{
 const h=harness(),pending=h.sync();await h.postStarted;
 h.context.page='commands';h.accept();await pending;
 assert.equal(h.context.renderCount,0);assert.equal(h.meta(),null);
});
