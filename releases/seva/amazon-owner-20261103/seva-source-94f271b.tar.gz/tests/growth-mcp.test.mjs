import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker/index.js';
import {growthScenario,conversionInterval} from '../src/growth.js';
import {NETWORK_CANDIDATES} from '../src/network.js';
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
const request=(payload,options={})=>new Request('https://seva.test/mcp',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),...options});
const rpc=async(method,params={})=>{const res=await worker.fetch(request({jsonrpc:'2.0',id:1,method,params}),{DB:{prepare(){throw Error('MCP must not access account data');}}});assert.equal(res.status,200);return res.json();};

test('monthly subscriptions add their own revenue and costs without counting merchant GMV or shared costs twice',()=>{
 const s=growthScenario({subscriptionVatRate:0});assert.equal(s.period,'one-month');near(s.subscriptionGrossRevenue,5000);near(s.subscriptionNetRevenue,5000);
 near(s.subscriptionProcessingFees,100);near(s.subscriptionVariableCosts,200);near(s.subscriptionContribution,4700);
 near(s.totalRevenue,5228);near(s.salesOnlyEconomicMargin,-292.4);near(s.cashMargin,4707.6);near(s.economicMargin,4407.6);
 assert.equal(s.breakEvenSubscribers,7);near(s.sellerProceedsBeforeOtherCosts,2052);
 const seller=growthScenario({feePayer:'seller',subscriptionVatRate:0});near(seller.subscriptionProcessingFees,100);near(seller.economicMargin,4455.6);
 const zero=growthScenario({monthlySubscribers:0});near(zero.subscriptionContribution,0);near(zero.economicMargin,zero.salesOnlyEconomicMargin);
});
test('subscription refunds preserve processing costs and an impossible subscription margin has no invented break-even',()=>{
 const s=growthScenario({subscriptionRefundRate:10,subscriptionVatRate:0});near(s.subscriptionGrossRevenue,5000);near(s.subscriptionNetRevenue,4500);near(s.subscriptionProcessingFees,100);near(s.economicMargin,3907.6);
 const allRefunds=growthScenario({subscriptionRefundRate:100});near(allRefunds.subscriptionNetRevenue,0);near(allRefunds.subscriptionProcessingFees,100);assert.equal(allRefunds.breakEvenSubscribers,null);
 const subscriptionOnly=growthScenario({visits:0,subscriptionVatRate:0});near(subscriptionOnly.totalRevenue,5000);near(subscriptionOnly.economicMargin,4320);assert.equal(subscriptionOnly.breakEvenSubscribers,9);
});

test('scenario separates merchant GMV, platform commission, creator share and real work cost',()=>{
 const s=growthScenario({monthlySubscribers:0});near(s.signups,800);near(s.activeUsers,320);near(s.buyers,32);near(s.orders,48);
 near(s.grossVolume,2400);near(s.netVolume,2280);near(s.platformRevenue,228);near(s.creatorShare,68.4);
 near(s.processingFees,48);near(s.cashMargin,7.6);near(s.economicMargin,-292.4);
 near(s.sellerProceedsBeforeOtherCosts,2052);assert.equal(s.breakEvenOrders,209);assert.equal(s.breakEvenVisits,43542);
 assert.equal(s.targetVisits,312500000);assert.equal(s.kind,'illustrative-scenario');
 const seller=growthScenario({feePayer:'seller',monthlySubscribers:0});near(seller.economicMargin,s.economicMargin+48);near(seller.sellerProceedsBeforeOtherCosts,2004);
});
test('empty funnel and negative unit economics never invent a CAC or achievable break-even',()=>{
 const zero=growthScenario({visits:0,signupRate:0,monthlySubscribers:0});assert.equal(zero.cacCash,null);assert.equal(zero.cacWithWork,null);assert.equal(zero.breakEvenVisits,null);assert.equal(zero.targetVisits,null);near(zero.economicMargin,-380);
 const loss=growthScenario({takeRate:0,creatorRate:0});assert.equal(loss.breakEvenOrders,null);assert.equal(loss.breakEvenVisits,null);
 const allRefund=growthScenario({refundRate:100});near(allRefund.platformRevenue,0);near(allRefund.processingFees,48);assert.equal(allRefund.breakEvenOrders,null);
});
test('invalid financial input and unknown/prototype fields are rejected',()=>{
 for(const input of [null,[],{visits:1.5},{targetActiveUsers:.5},{monthlySubscribers:1.5},{subscriptionRefundRate:101},{subscriptionVatRate:101},{subscriptionVatRate:-1},{subscriptionPrice:-1},{signupRate:101},{aov:-1},{aov:Infinity},{aov:'50'},{ordersPerBuyer:0},{creatorRate:11},{feePayer:'unknown'},{secret:'x'},JSON.parse('{"__proto__":{"aov":0}}')])assert.throws(()=>growthScenario(input));
});
test('Wilson interval preserves uncertainty at zero and full observed conversions',()=>{
 const s=conversionInterval({trials:100,successes:5});near(s.rate,.05);near(s.lower95,.021543679154367966);near(s.upper95,.11175046923191914);
 const zero=conversionInterval({trials:100,successes:0});near(zero.lower95,0);near(zero.upper95,.03699349820698568);
 const all=conversionInterval({trials:100,successes:100});near(all.lower95,.9630065017930143);near(all.upper95,1);
 assert.equal(conversionInterval({trials:0,successes:0}).rate,null);
 for(const input of [{trials:1,successes:2},{trials:-1,successes:0},{trials:1.5,successes:1},{trials:100,successes:1,email:'x'}])assert.throws(()=>conversionInterval(input));
});
test('MCP discovery and three read-only tools work without any account database access',async()=>{
 assert.deepEqual((await rpc('server/discover')).result.supportedVersions,['2026-07-28']);
 const {tools}= (await rpc('tools/list')).result;assert.equal(tools.length,3);assert.ok(tools.every(t=>t.annotations.readOnlyHint&&!t.annotations.destructiveHint));
 const scenario=(await rpc('tools/call',{name:'seva_growth_scenario',arguments:{visits:10000}})).result;
 assert.equal(scenario.isError,false);near(scenario.structuredContent.economicMargin,3505.960655737705);near(scenario.structuredContent.subscriptionGrossRevenue,5000);
 const stats=(await rpc('tools/call',{name:'seva_conversion_interval',arguments:{trials:0,successes:0}})).result;assert.equal(stats.structuredContent.rate,null);
 const readiness=(await rpc('tools/call',{name:'seva_payment_readiness'})).result;
 assert.equal(readiness.isError,false);const status=readiness.structuredContent;assert.equal(status.liveCheckoutEnabled,false);assert.equal(status.sellerRoutingEnabled,false);
 assert.ok(!JSON.stringify(status).includes('acct_'));assert.ok(!JSON.stringify(status).includes('sk_'));
});
test('MCP refuses writes, unknown calls and private input fields',async()=>{
 assert.equal((await rpc('tools/call',{name:'charge_customer'})).error.code,-32602);
 assert.equal((await rpc('unknown')).error.code,-32601);
 for(const [name,args] of [['seva_payment_readiness',{account:'x'}],['seva_growth_scenario',{email:'x'}],['seva_conversion_interval',{trials:10,successes:11}],['seva_growth_scenario',[]]]){
  assert.equal((await rpc('tools/call',{name,arguments:args})).result.isError,true);
 }
});
test('MCP enforces request bounds, JSON and same-origin browser calls',async()=>{
 assert.equal((await worker.fetch(new Request('https://seva.test/mcp'),{})).status,405);
 assert.equal((await worker.fetch(request({}, {headers:{'Content-Type':'text/plain'}}),{})).status,415);
 assert.equal((await worker.fetch(request({}, {headers:{'Content-Type':'application/json',Origin:'https://attacker.test'}}),{})).status,403);
 assert.equal((await worker.fetch(request({value:'x'.repeat(24000)}),{})).status,413);
 const malformed=await (await worker.fetch(request({}, {body:'{bad'}),{})).json();assert.equal(malformed.error.code,-32700);
 const batch=await (await worker.fetch(request([]),{})).json();assert.equal(batch.error.code,-32600);
});
test('public candidate links are verified-source presets, never acquired agreements',async()=>{
 assert.equal(NETWORK_CANDIDATES.length,7);
 for(const c of NETWORK_CANDIDATES){assert.ok(c.url.startsWith('https://'));assert.ok((c.name+' · proposta SEVA').length<=100);assert.ok(c.objective.length<=300);}
 const html=await (await worker.fetch(new Request('https://seva.test/network'),{})).text();assert.ok(html.includes('candidate=mei'));assert.ok(html.includes('ISCRIZIONI CHIUSE')||html.includes('chiuse'));
 const valid=await worker.fetch(new Request('https://seva.test/app?section=partnerships&candidate=mei'),{});assert.ok(valid.headers.get('Location').includes('candidate%3Dmei'));
 const invalid=await worker.fetch(new Request('https://seva.test/app?section=partnerships&candidate=unknown'),{});assert.ok(!invalid.headers.get('Location').includes('candidate'));
});

test('inclusive VAT reduces revenue without adding to the customer price or reducing processing fees',()=>{
 const s=growthScenario();
 near(s.subscriptionGrossRevenue,5000);near(s.subscriptionAfterRefunds,5000);
 // Independent division: gross 500000 cents / 122 percent × 100 = 409836.0655737705 net cents.
 near(s.subscriptionNetRevenue,4098.360655737705);near(s.subscriptionVat,901.639344262295);
 near(s.subscriptionNetRevenue+s.subscriptionVat,s.subscriptionAfterRefunds);
 near(s.subscriptionProcessingFees,100);near(s.subscriptionContribution,3798.360655737705);
 near(s.totalRevenue,4326.360655737705);near(s.economicMargin,3505.960655737705);assert.equal(s.breakEvenSubscribers,8);
 const refunded=growthScenario({subscriptionRefundRate:10});near(refunded.subscriptionAfterRefunds,4500);near(refunded.subscriptionNetRevenue,3688.524590163934);near(refunded.subscriptionVat,811.475409836066);near(refunded.subscriptionProcessingFees,100);
 const all=growthScenario({subscriptionRefundRate:100});near(all.subscriptionVat,0);near(all.subscriptionNetRevenue,0);near(all.subscriptionProcessingFees,100);
 const zero=growthScenario({monthlySubscribers:0});near(zero.subscriptionVat,0);near(zero.subscriptionContribution,0);
 const different=growthScenario({monthlySubscribers:1,subscriptionVatRate:20});near(different.subscriptionNetRevenue,41.66666666666667);near(different.subscriptionVat,8.33333333333333);
});
