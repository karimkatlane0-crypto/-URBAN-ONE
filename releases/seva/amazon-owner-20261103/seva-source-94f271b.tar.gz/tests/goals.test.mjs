import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFile,readdir} from 'node:fs/promises';
import {handleGoals} from '../src/goals.js';
import {task,addChild,validateGoals,mergeGoalTrees,walkGoalTrees} from '../src/model.js';

const sqlite=new DatabaseSync(':memory:');
for(const name of (await readdir(new URL('../drizzle/',import.meta.url))).filter(n=>n.endsWith('.sql')).sort())sqlite.exec(await readFile(new URL('../drizzle/'+name,import.meta.url),'utf8'));
test.after(()=>sqlite.close());
const db={prepare(sql){const statement=sqlite.prepare(sql);return {bind(...args){return {async first(){return statement.get(...args)||null;},async run(){return {meta:{changes:Number(statement.run(...args).changes)}};}};}};}};
const call=(owner,method='GET',body,headers={})=>handleGoals(new Request('https://seva.test/api/goals',{method,headers:{...(owner?{'oai-authenticated-user-id':owner}:{}),origin:'https://seva.test','content-type':'application/json',...headers},...(body===undefined?{}:{body:JSON.stringify(body)})}),{DB:db});
const update=(goals,revision=0,operationId=crypto.randomUUID())=>({goals,revision,operationId,consent:true});

test('goal HTTP requires signed-in identity, same origin and explicit selected-data consent',async()=>{
 assert.equal((await call(null)).status,401);
 assert.equal((await call('auth','DELETE')).status,405);
 assert.equal((await call('auth','POST',update([]),{origin:'https://untrusted.test'})).status,403);
 assert.equal((await call('auth','POST',{...update([]),consent:false})).status,400);
 assert.equal((await call('auth','POST',{...update([]),ownerId:'other'})).status,400);
 assert.equal((await call('auth','POST',update([]),{'content-type':'text/plain'})).status,415);
});
test('five-level goals persist in SQL, are account isolated and require the current revision',async()=>{
 const a=task('Obiettivo');let child=a;for(let i=0;i<4;i++)child=addChild(child,'Livello '+(i+1));
 const first=await call('alice','POST',update([a]));assert.equal(first.status,200);assert.match(first.headers.get('cache-control'),/no-store/);
 const saved=await first.json();assert.equal(saved.revision,1);assert.deepEqual(saved.goals,[a]);
 assert.deepEqual((await (await call('bob')).json()).goals,[]);
 assert.equal((await call('alice','POST',update([],0))).status,409);
 assert.equal((await call('alice','POST',update([],1))).status,200);
 assert.deepEqual((await (await call('alice')).json()).goals,[]);
});
test('operation retries are idempotent and changed content cannot reuse an acknowledgement',async()=>{
 const node=task('Retry'),body=update([node],0,'same-operation');
 assert.equal((await call('retry','POST',body)).status,200);
 const reordered=Object.fromEntries(Object.entries(node).reverse());
 const retry=await call('retry','POST',{...body,goals:[reordered]});assert.equal(retry.status,200);assert.equal((await retry.json()).revision,1);
 const changed=await call('retry','POST',{...body,goals:[{...node,title:'Different'}]});
 assert.equal(changed.status,409);assert.equal((await changed.json()).code,'operation_conflict');
 assert.equal((await (await call('retry')).json()).goals[0].title,'Retry');
});
test('concurrent first saves cannot both acknowledge revision one',async()=>{
 const responses=await Promise.all([call('concurrent','POST',update([task('first')])),call('concurrent','POST',update([task('second')]))]);
 assert.deepEqual(responses.map(r=>r.status).sort(),[200,409]);
 assert.equal((await (await call('concurrent')).json()).revision,1);
});
test('forged verification, unrelated data and oversized UTF-8 payloads fail without writing',async()=>{
 const node=task('Draft');
 for(const changed of [{...node,status:'Verificato'},{...node,photo:'not-allowed'},{...node,depth:9}])assert.equal((await call('invalid','POST',update([changed]))).status,400);
 const large=Array.from({length:80},(_,i)=>({...task('Row '+i),criteria:'é'.repeat(4000)}));
 assert.equal((await call('invalid','POST',update(large))).status,413);
 assert.equal((await (await call('invalid')).json()).revision,0);
});
test('database failures are sanitized even when an SDK supplies a status property',async()=>{
 const response=await handleGoals(new Request('https://seva.test/api/goals',{headers:{'oai-authenticated-user-id':'owner'}}),{DB:{prepare(){throw Object.assign(Error('private SQL or credential'),{status:400});}}});
 assert.equal(response.status,503);assert.ok(!(await response.text()).includes('private SQL'));
});
test('goal merging keeps independent edits and deletions and asks about edit-versus-delete',()=>{
 const a=task('A'),b=task('B'),base=[a,b],local=structuredClone(base),remote=structuredClone(base);
 local[0].title='Local A';remote[1].title='Remote B';
 const merged=mergeGoalTrees(base,local,remote);assert.equal(merged.conflicts.length,0);assert.deepEqual(merged.goals.map(n=>n.title),['Local A','Remote B']);
 assert.equal(mergeGoalTrees(base,[b],base).goals.length,1);
 assert.equal(mergeGoalTrees(base,[b],[{...a,title:'Remote edit'},b]).conflicts.length,1);
 assert.equal(base[0].title,'A');
});
test('goal walking supports breadth, depth and reverse order without accepting invalid trees',()=>{
 const a=task('A'),b=task('B');addChild(a,'Child A');addChild(b,'Child B');
 assert.deepEqual(walkGoalTrees([a,b],{strategy:'breadth'}).map(n=>n.title),['A','B','Child A','Child B']);
 assert.deepEqual(walkGoalTrees([a,b]).map(n=>n.title),['A','Child A','B','Child B']);
 assert.deepEqual(walkGoalTrees([a,b],{direction:'backward'}).map(n=>n.title),['Child B','B','Child A','A']);
 assert.throws(()=>validateGoals([a,a]));assert.throws(()=>walkGoalTrees([a],{strategy:'unknown'}));
});
