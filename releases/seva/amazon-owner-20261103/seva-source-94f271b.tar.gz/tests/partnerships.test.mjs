import test from 'node:test';
import assert from 'node:assert/strict';
import {createPartnershipPlan,partnershipSectors} from '../src/partnerships.js';
import {flatten,validateGoals,setStatus,walkGoalTrees} from '../src/model.js';
import worker from '../worker/index.js';
const input={organization:'Synthetic sports group',sector:'football',objective:'Evaluate one voluntary community pilot'};

test('collaboration plans remain unverified and require evidence through every stage',()=>{
 for(const sector of Object.keys(partnershipSectors)){
  const root=createPartnershipPlan({...input,sector}),nodes=flatten([root]);
  assert.equal(nodes.length,13);assert.equal(root.children.length,4);assert.equal(new Set(nodes.map(n=>n.id)).size,13);
  assert.ok(nodes.every(n=>n.status==='Da fare'&&n.evidence===''&&n.criteria.length>0));
  assert.equal(validateGoals([root])[0],root);assert.throws(()=>setStatus(root,'Verificato'));
  root.evidence='Synthetic test evidence';assert.throws(()=>setStatus(root,'Verificato'));
  assert.equal(walkGoalTrees([root],{strategy:'breadth'}).length,13);
  assert.equal(walkGoalTrees([root],{direction:'backward'}).at(-1).id,root.id);
 }
});
test('invalid collaboration input cannot create a plan or alter an existing one',()=>{
 const before=createPartnershipPlan(input),snapshot=JSON.stringify(before);
 for(const bad of [{organization:''},{organization:'a'.repeat(101)},{objective:'a'.repeat(301)},{objective:'line\nbreak'},{sector:'constructor'},{sector:'__proto__'},{sector:'nba-approved'},{organization:null}])assert.throws(()=>createPartnershipPlan({...input,...bad}));
 assert.equal(JSON.stringify(before),snapshot);
 const next=createPartnershipPlan(input);assert.notEqual(next.id,before.id);
 next.children[0].criteria='changed';assert.notEqual(next.children[0].criteria,before.children[0].criteria);
});
test('sports guide is public and bilingual without workspace reflection or a send endpoint',async()=>{
 const DB={prepare(){throw Error('Public guide must not access private data');}};
 for(const lang of ['it','en']){
  const r=await worker.fetch(new Request('https://seva.test/sports?lang='+lang+'&organization=PRIVATE-MARKER'),{DB});
  assert.equal(r.status,200);const html=await r.text();
  assert.ok(html.includes('<html lang="'+lang+'">'));assert.ok(html.includes('https://contact.nba.com/'));assert.ok(html.includes('https://www.legaseriea.it/lega-serie-a/sedi-e-contatti'));
  assert.ok(!html.includes('PRIVATE-MARKER'));assert.ok(!html.includes('SEVA_SESSION'));
 }
 assert.equal((await worker.fetch(new Request('https://seva.test/sports',{method:'POST'}),{DB})).status,405);
 assert.equal((await worker.fetch(new Request('https://seva.test/api/partnerships/send',{method:'POST'}),{DB})).status,404);
});
test('collaboration workspace requires sign-in and preserves the intended section',async()=>{
 const r=await worker.fetch(new Request('https://seva.test/app?section=partnerships'));
 assert.equal(r.status,302);assert.equal(r.headers.get('location'),'/signin-with-chatgpt?return_to=%2Fapp%3Fsection%3Dpartnerships');
 assert.equal((await worker.fetch(new Request('https://seva.test/api/goals'))).status,401);
});
