import test from 'node:test';
import assert from 'node:assert/strict';
import {Script} from 'node:vm';
import {buildCampaign,CAMPAIGN_SCRIPT} from '../src/campaigns.js';
import worker from '../worker/index.js';
const draft={name:'Synthetic project',objective:'Test one study action',url:'https://example.com/project',audience:'campus',language:'en'};

test('launch drafts retain the chosen audience, nested criteria and unmeasured status in both languages',()=>{
 for(const language of ['it','en'])for(const audience of ['music','art','campus','shop','football','basketball']){
  const result=buildCampaign({...draft,language,audience});
  assert.equal(result.language,language);assert.ok(result.text.includes(draft.objective));assert.ok(result.text.includes(draft.url));
  assert.match(result.text,/G\.1\.1\.1 ·/);assert.ok(result.text.includes(language==='en'?'Week 4':'Settimana 4'));
  assert.ok(result.text.includes(language==='en'?'not measured, not zero':'non misurato, non zero'));
  assert.ok(result.text.includes(language==='en'?'Nothing sent or published':'Nessun invio o pubblicazione'));
 }
 const literal=buildCampaign({...draft,name:'<img src=x onerror=alert(1)>'});assert.ok(literal.text.includes('<img src=x onerror=alert(1)>'));
 assert.doesNotThrow(()=>new Script(CAMPAIGN_SCRIPT));
});
test('launch drafts reject unsafe links, credential parameters and malformed or excessive fields',()=>{
 for(const url of ['javascript:alert(1)','http://example.com','https://user:password@example.com','https://localhost/','https://127.0.0.1/','https://example.com/?access_token=private','https://example.com/?session=private'])assert.throws(()=>buildCampaign({...draft,url}));
 for(const change of [{name:''},{name:'a'.repeat(81)},{objective:'a'.repeat(161)},{name:'line\nbreak'},{audience:'constructor'},{audience:'unknown'},{url:null}])assert.throws(()=>buildCampaign({...draft,...change}));
 assert.ok(buildCampaign({...draft,url:'https://example.com/?lang=en'}).text.includes('?lang=en'));
});
test('public planner does not read a workspace or reflect query content and cannot send a campaign',async()=>{
 const DB={prepare(){throw Error('Planner must not access the database');}};
 const query='/campaigns?name=PRIVATE-MARKER&url=javascript%3Aalert(1)&lang=en';
 const response=await worker.fetch(new Request('https://seva.test'+query),{DB});assert.equal(response.status,200);
 const html=await response.text();assert.ok(!html.includes('PRIVATE-MARKER'));assert.ok(html.includes('id="campaignForm"'));assert.ok(html.includes('output.textContent=result.text'));
 for(const match of html.matchAll(/<script>([\s\S]*?)<\/script>/g))assert.doesNotThrow(()=>new Script(match[1]));
 assert.equal((await worker.fetch(new Request('https://seva.test/campaigns',{method:'POST'}),{DB})).status,405);
 assert.equal((await worker.fetch(new Request('https://seva.test/api/campaigns/send',{method:'POST'}),{DB})).status,404);
 assert.equal((await worker.fetch(new Request('https://seva.test/api/inquiries'),{DB})).status,401);
});
