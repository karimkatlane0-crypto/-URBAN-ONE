import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "URBAN ONE — AI Science Computer",
  description: "Ricerca scientifica e confronto tra provider AI con accesso protetto.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="it">
      <body className="antialiased">{children}</body>
    </html>
  );
}
