import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {handleScienceApi} from '@/lib/science.mjs';
export const dynamic = 'force-dynamic';
const headers = {'cache-control':'no-store','x-content-type-options':'nosniff'};
async function run(request: Request) {
 const path = new URL(request.url).pathname;
 const user = await getChatGPTUser();
 const owner = Boolean(user?.userId && user.email.toLowerCase() === 'karimkatlane0@gmail.com');
 const runtime = env as unknown as Record<string,string>;
 if (request.method === 'POST' && !owner) return Response.json({error:'OWNER_SIGNIN_REQUIRED'},{status:401,headers});
 let body = {};
 if (request.method === 'POST') {
  if (!(request.headers.get('content-type') || '').startsWith('application/json')) return Response.json({error:'INVALID_REQUEST'},{status:400,headers});
  const reader = request.body?.getReader();
  if (!reader) return Response.json({error:'INVALID_REQUEST'},{status:400,headers});
  let size = 0; const chunks: Uint8Array[] = [];
  for (;;) {const chunk = await reader.read();if(chunk.done) break;size += chunk.value.byteLength;if(size>65536){await reader.cancel();return Response.json({error:'PAYLOAD_TOO_LARGE'},{status:413,headers});}chunks.push(chunk.value);}
  const bytes = new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.byteLength;}
  try {body = JSON.parse(new TextDecoder().decode(bytes));} catch {return Response.json({error:'INVALID_JSON'},{status:400,headers});}
 }
 try {
  const result = await handleScienceApi({method:request.method,path,body,env:runtime,headers:{authorization:owner?'Bearer '+runtime.SCIENCE_API_TOKEN:''}});
  if (request.method === 'GET') result.body.accessConfigured = owner && result.body.accessConfigured === true;
  return Response.json(result.body,{status:result.status,headers});
 } catch {return Response.json({error:'INTERNAL_SERVER_ERROR'},{status:500,headers});}
}
export const GET = run;
export const POST = run;
