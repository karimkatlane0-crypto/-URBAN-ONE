# URBAN ONE — AI Science Computer (hosted)

Public interface; inference requires Sites sign-in with the owner account. Owner authorization is checked server-side for every run. Provider secrets are configured in Sites runtime, never embedded in source. OpenAI is the initially configured provider; Claude, Gemini and xAI remain unavailable until configured and verified.

The server adapter wraps the shared research handler from `karimkatlane0-crypto/-URBAN-ONE/services/api/science.mjs`. Rate/concurrency limits are per isolate; no commercial multi-tenant quota or payment system is claimed. No arbitrary code execution or scientific validation is implied.

Source repository: https://github.com/karimkatlane0-crypto/-URBAN-ONE

Build with the supplied Sites helper. Do not publish `.env*`, `.dev.vars*`, credentials or local runtime state.
