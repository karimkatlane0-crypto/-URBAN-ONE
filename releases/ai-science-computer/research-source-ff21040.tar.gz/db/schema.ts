import {sqliteTable, text, integer} from 'drizzle-orm/sqlite-core';
export const checkoutIntents = sqliteTable('science_checkout_intents', {
 token: text('token').primaryKey(), userId: text('user_id').notNull(), createdAt: integer('created_at').notNull(), expiresAt: integer('expires_at').notNull(), sessionId: text('session_id'), subscriptionId: text('subscription_id'),
});
export const subscriptions = sqliteTable('science_subscriptions', {
 id: text('id').primaryKey(), userId: text('user_id'), customerId: text('customer_id'), status: text('status').notNull().default('pending'), eligible: integer('eligible').notNull().default(0), paidStart: integer('paid_start').notNull().default(0), paidThrough: integer('paid_through').notNull().default(0), updatedAt: integer('updated_at').notNull().default(0), canceled: integer('canceled').notNull().default(0),
});
export const billingEvents = sqliteTable('science_billing_events', {id:text('id').primaryKey(),type:text('type').notNull(),createdAt:integer('created_at').notNull()});
export const usage = sqliteTable('science_usage', {key:text('key').primaryKey(),used:integer('used').notNull().default(0)});
export const paidPeriods = sqliteTable('science_paid_periods', {key:text('key').primaryKey(),subscriptionId:text('subscription_id').notNull(),start:integer('start').notNull(),end:integer('end').notNull()});
