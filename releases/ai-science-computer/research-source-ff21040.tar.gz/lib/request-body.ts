export async function readBody(request:Request,limit=65536){
 const reader=request.body?.getReader();if(!reader)throw Error('INVALID_REQUEST');
 let size=0;const chunks:Uint8Array[]=[];
 for(;;){const chunk=await reader.read();if(chunk.done)break;size+=chunk.value.byteLength;if(size>limit){await reader.cancel();throw Error('PAYLOAD_TOO_LARGE');}chunks.push(chunk.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.byteLength;}
 return bytes;
}
