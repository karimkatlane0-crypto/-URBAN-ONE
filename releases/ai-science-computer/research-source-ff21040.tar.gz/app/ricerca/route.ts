import {researchHTML} from '@/lib/research-page';
export const dynamic='force-dynamic';
export function GET(){return new Response(researchHTML,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'same-origin'}});}
