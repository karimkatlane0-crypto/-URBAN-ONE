import {scienceHTML} from '@/lib/science-page';
export const dynamic = 'force-dynamic';
export function GET() {return new Response(scienceHTML, {headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'same-origin'}});}
