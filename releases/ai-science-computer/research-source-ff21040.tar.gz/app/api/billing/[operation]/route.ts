import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {beginCheckout,billingReady,getEntitlement,verifyStripeEvent,applyStripeEvent} from '@/lib/billing.mjs';
import {readBody} from '@/lib/request-body';
export const dynamic='force-dynamic';
const headers={'cache-control':'no-store','x-content-type-options':'nosniff'};
async function handle(request:Request){
 const runtime=env as unknown as Record<string,any>;
 const path=new URL(request.url).pathname;
 try {
  if(path==='/api/billing/webhook' && request.method==='POST'){
   if(!runtime.DB||!runtime.STRIPE_WEBHOOK_SECRET)return Response.json({error:'WEBHOOK_NOT_READY'},{status:503,headers});
   const raw=await readBody(request,1048576);
   let event;try{event=verifyStripeEvent(Buffer.from(raw),request.headers.get('stripe-signature'),runtime.STRIPE_WEBHOOK_SECRET);}catch{return Response.json({error:'SIGNATURE_INVALID'},{status:400,headers});}
   const result=await applyStripeEvent(runtime.DB,event,runtime);return Response.json(result,{headers});
  }
  const user=await getChatGPTUser();
  if(path==='/api/billing/status' && request.method==='GET'){
   const entitlement=await getEntitlement(runtime.DB,user);const {usageKey,...publicState}=entitlement;
   return Response.json({...publicState,checkoutReady:billingReady(runtime),portalUrl:runtime.SCIENCE_PORTAL_URL||null},{headers});
  }
  if(path==='/api/billing/checkout' && request.method==='POST'){
   if(!request.headers.get('content-type')?.startsWith('application/json'))return Response.json({error:'INVALID_REQUEST'},{status:400,headers});
   const body=JSON.parse(new TextDecoder().decode(await readBody(request)));
   const result=await beginCheckout(runtime.DB,user,runtime,body.termsVersion);return Response.json(result,{status:result.status,headers});
  }
  return Response.json({error:'NOT_FOUND'},{status:404,headers});
 }catch(error){const code=error instanceof Error?error.message:'';return Response.json({error:code==='PAYLOAD_TOO_LARGE'?code:'BILLING_UNAVAILABLE'},{status:code==='PAYLOAD_TOO_LARGE'?413:503,headers});}
}
export const GET=handle;export const POST=handle;
