import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {handleScienceApi} from '@/lib/science.mjs';
import {getEntitlement,reserveAnalysis,releaseAnalysis,isOwner} from '@/lib/billing.mjs';
export const dynamic = 'force-dynamic';
const headers = {'cache-control':'no-store','x-content-type-options':'nosniff'};
async function run(request: Request) {
 const path = new URL(request.url).pathname;
 const user = await getChatGPTUser();
 const owner = isOwner(user);
 const runtime = env as unknown as Record<string,string>;
 const db = (env as unknown as {DB?:any}).DB;
 const entitlement = await getEntitlement(db,user);
 if(request.method === 'POST' && !entitlement.allowed) return Response.json({error:user?'SUBSCRIPTION_REQUIRED':'SIGNIN_REQUIRED'},{status:user?402:401,headers});
 let body = {};
 if (request.method === 'POST') {
  if (!(request.headers.get('content-type') || '').startsWith('application/json')) return Response.json({error:'INVALID_REQUEST'},{status:400,headers});
  const reader = request.body?.getReader();
  if (!reader) return Response.json({error:'INVALID_REQUEST'},{status:400,headers});
  let size = 0; const chunks: Uint8Array[] = [];
  for (;;) {const chunk = await reader.read();if(chunk.done) break;size += chunk.value.byteLength;if(size>65536){await reader.cancel();return Response.json({error:'PAYLOAD_TOO_LARGE'},{status:413,headers});}chunks.push(chunk.value);}
  const bytes = new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.byteLength;}
  try {body = JSON.parse(new TextDecoder().decode(bytes));} catch {return Response.json({error:'INVALID_JSON'},{status:400,headers});}
 }
 let reserved = false;
 try {
  if(request.method==='POST' && !owner){const claim=await reserveAnalysis(db,entitlement.usageKey);if(!claim)return Response.json({error:'QUOTA_EXHAUSTED'},{status:429,headers});reserved=true;}
  const result = await handleScienceApi({method:request.method,path,body,env:runtime,headers:{authorization:entitlement.allowed?'Bearer '+runtime.SCIENCE_API_TOKEN:''}});
  if (request.method === 'GET') result.body.accessConfigured = entitlement.allowed && result.body.accessConfigured === true;
  if(reserved && (result.status!==200 || !result.body.results?.some((r:any)=>r.state==='completed'))){await releaseAnalysis(db,entitlement.usageKey);reserved=false;}
  return Response.json(result.body,{status:result.status,headers});
 } catch {if(reserved)await releaseAnalysis(db,entitlement.usageKey);return Response.json({error:'INTERNAL_SERVER_ERROR'},{status:500,headers});}
}
export const GET = run;
export const POST = run;
