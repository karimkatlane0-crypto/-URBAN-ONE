import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "URBAN ONE — AI per B&B e piccoli hotel",
  description: "Bozze per ospiti, offerte, traduzioni e scenari di costo per B&B, con accesso protetto.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="it">
      <body className="antialiased">{children}</body>
    </html>
  );
}
