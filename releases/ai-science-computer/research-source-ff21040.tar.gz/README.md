# URBAN ONE — AI Science Computer (hosted)

Public interface; inference requires Sites sign-in with the owner account. Owner authorization is checked server-side for every run. Provider secrets are configured in Sites runtime, never embedded in source. OpenAI is the initially configured provider; Claude, Gemini and xAI remain unavailable until configured and verified.

The server adapter wraps the shared research handler from `karimkatlane0-crypto/-URBAN-ONE/services/api/science.mjs`. Rate/concurrency limits are per isolate; no commercial multi-tenant quota or payment system is claimed. No arbitrary code execution or scientific validation is implied.

Source repository: https://github.com/karimkatlane0-crypto/-URBAN-ONE

Build with the supplied Sites helper. Do not publish `.env*`, `.dev.vars*`, credentials or local runtime state.

## AI Science Pro — paid access

Plan: EUR 29 per month, 50 completed analyses per paid billing period, no paid overages. The owner retains access. Customers sign in with ChatGPT before starting checkout, accept the dated terms and are assigned a random server-generated checkout reference. Stripe owns payment collection and the billing portal; the application never receives card data or holds a Stripe API key.

The signed webhook handler verifies exact request bytes, timestamp tolerance, live/account context and the configured Payment Link and Price IDs. Subscription snapshots, paid invoice periods, checkout ownership and event receipts persist in D1. Events can arrive in any order. A redirect never grants access. Subscription cancellation, failed renewal and expired paid periods restrict access. Usage is atomically reserved in D1 and refunded when no provider completes a response. A renewal paid before its start preserves the currently paid period and opens a fresh 50-analysis allowance only when the next period begins.

Runtime settings: `STRIPE_WEBHOOK_SECRET` (secret), `STRIPE_ACCOUNT_ID`, `STRIPE_LIVEMODE`, `SCIENCE_PRICE_ID`, `SCIENCE_PAYMENT_LINK_ID`, `SCIENCE_PAYMENT_LINK_URL`, `SCIENCE_PORTAL_URL`, `SCIENCE_BILLING_ENABLED`. Keep all credentials outside source and archives. Stripe account: Katlane Karim; commercial identity is separate from EY or AI provider partnership claims.

Routes: `/api/billing/status`, `/api/billing/checkout`, `/api/billing/webhook`. Public operating terms and privacy pages: `/terms.html`, `/privacy.html`. Support: karimkatlane0@gmail.com.

Validation: `node --test tests/billing.test.mjs` uses actual SQLite SQL through a D1-compatible adapter, including signatures, consent, reference ownership, payment state, six webhook ordering permutations, duplicate events, cancellation, quota exhaustion, early renewal and configuration failure. This is not evidence of a real customer payment or a completed sandbox checkout. Full production customer checkout → webhook → access remains an external evidence gate until a real signed Stripe event is delivered for an actual authorized subscription. No real customer was charged during implementation.

Tax: Stripe Tax settings are active but the connected account has no active tax registrations. Automatic tax calculation is therefore disabled; no tax collection or tax compliance is claimed. Confirm the applicable fiscal treatment with the merchant's advisor before expanding commercial sales. Do not create registrations or select a legal tax classification without confirmation. Refunds and disputes require merchant handling in Stripe and corresponding access review; they are not automatically reconciled by this initial subscription gate.

## Hospitality first-sale focus

The public landing now focuses on B&B and small hotel operators with four prompt templates: guest reply drafts, stay offer drafts, translation and revenue/cost scenarios from user-supplied data. Templates prepare a request only; paid access and explicit provider consent remain required for inference. No outbound messages, reservation actions, PMS/OTA connection or new pricing is introduced. Existing general research examples remain available.

## Second vertical: real-estate work

The public `/immobiliare` route adds editable templates for listing drafts, responses to property inquiries, cost comparisons and visit checklists. It uses authorized user-supplied data only. The existing EUR29 plan and its 50 analyses are shared across hospitality and real-estate pages through the same entitlement and quota backend. It does not alter KKUBERA, introduce brokerage/visit payments, verify property documents or connect to listing inventories. Sign-in returns to the selected vertical.

## Third vertical: research and development

The `/ricerca` route adds four guided requests for testable hypotheses, draft experimental plans, static code review and analysis of supplied source excerpts. It explicitly distinguishes inference assistance from actual HPC, executed code/experiments and autonomous paper retrieval. All three verticals share the existing EUR29 plan and 50-analysis entitlement; no billing or provider configuration is changed.
